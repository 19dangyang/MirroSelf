/**
 * 匹配池客户端（M4）。
 *
 * ⚠️ **全项目唯一允许出现 fetch 的文件。**
 * `npm run check` 只在这里放行网络调用，并额外限制：路径必须以 /api/v1/ 开头、
 * 服务器地址只能来自用户设置。这份白名单是"零联网"承诺被放开后唯一的技术边界。
 *
 * 出站的内容只有三样：
 *   1. 一张量化过的兴趣名片（用户亲手预览过）
 *   2. 一个匿名 token 与公钥
 *   3. 用对方公钥加密过的联系卡（服务端读不懂）
 * 作品 ID、标题、观看时间、UP 主列表一律不出门。
 */

const API_PREFIX = '/api/v1/';
const POW_SALT = 'mirroself-pow-v1';
const POW_BITS = 12;

// ---------------------------------------------------------------- 编码

export function b64u(bytes) {
  const arr = new Uint8Array(bytes);
  let s = '';
  for (const b of arr) s += String.fromCharCode(b);
  return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function fromB64u(str) {
  const s = String(str).replace(/-/g, '+').replace(/_/g, '/');
  const pad = s.length % 4 === 0 ? '' : '='.repeat(4 - (s.length % 4));
  const bin = atob(s + pad);
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i += 1) out[i] = bin.charCodeAt(i);
  return out;
}

const enc = new TextEncoder();
const dec = new TextDecoder();

// ---------------------------------------------------------------- 密钥

/** 生成一次性池身份：ECDH P-256。公钥随名片上传，私钥只留在本机。 */
export async function generatePoolKeys() {
  const pair = await crypto.subtle.generateKey({ name: 'ECDH', namedCurve: 'P-256' }, true, ['deriveKey']);
  const raw = await crypto.subtle.exportKey('raw', pair.publicKey);
  const jwk = await crypto.subtle.exportKey('jwk', pair.privateKey);
  return { pubB64: b64u(raw), privJwk: jwk };
}

export async function importPrivateKey(jwk) {
  return crypto.subtle.importKey('jwk', jwk, { name: 'ECDH', namedCurve: 'P-256' }, false, ['deriveKey']);
}

async function deriveSharedKey(privateKey, peerPubB64) {
  const peer = await crypto.subtle.importKey('raw', fromB64u(peerPubB64), { name: 'ECDH', namedCurve: 'P-256' }, false, []);
  return crypto.subtle.deriveKey({ name: 'ECDH', public: peer }, privateKey, { name: 'AES-GCM', length: 256 }, false, [
    'encrypt',
    'decrypt',
  ]);
}

/**
 * 用「我的私钥 + 对方公钥」加密联系卡。
 * 双方算出的共享密钥相同，所以对方也能解开 —— 而服务端两头都没有。
 */
export async function encryptContact(privateKey, peerPubB64, contact) {
  const key = await deriveSharedKey(privateKey, peerPubB64);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(JSON.stringify(contact)));
  return b64u(iv) + '.' + b64u(cipher);
}

export async function decryptContact(privateKey, peerPubB64, blob) {
  const [ivPart, dataPart] = String(blob || '').split('.');
  if (!ivPart || !dataPart) throw new Error('联系卡格式不对');
  const key = await deriveSharedKey(privateKey, peerPubB64);
  const plain = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: fromB64u(ivPart) },
    key,
    fromB64u(dataPart),
  );
  return JSON.parse(dec.decode(plain));
}

// ---------------------------------------------------------------- 工作量证明

async function digestHex(nonce) {
  const buf = await crypto.subtle.digest('SHA-256', enc.encode(`${POW_SALT}:${nonce}`));
  return new Uint8Array(buf);
}

export function leadingZeroBits(bytes) {
  let bits = 0;
  for (const byte of bytes) {
    if (byte === 0) {
      bits += 8;
      continue;
    }
    let b = byte;
    let z = 0;
    while ((b & 0x80) === 0) {
      z += 1;
      b = (b << 1) & 0xff;
    }
    bits += z;
    break;
  }
  return bits;
}

/** 找一个前导零位数达标的 nonce。建号只需做一次。 */
export async function solvePow(bits = POW_BITS, limit = 500000) {
  for (let i = 0; i < limit; i += 1) {
    const nonce = 'p' + i.toString(36);
    if (leadingZeroBits(await digestHex(nonce)) >= bits) return nonce;
  }
  throw new Error('工作量证明求解失败');
}

// ---------------------------------------------------------------- 网络

function endpoint(server, path) {
  if (!server || typeof server !== 'string') throw new Error('没有配置服务器地址');
  if (!path.startsWith(API_PREFIX)) throw new Error('只允许访问 /api/v1/*');
  const base = server.replace(/\/+$/, '');
  if (!/^https?:\/\//.test(base)) throw new Error('服务器地址必须是 http(s) 开头');
  return base + path;
}

async function call(server, path, { method = 'POST', body, query } = {}) {
  const url = new URL(endpoint(server, path));
  if (query) for (const [k, v] of Object.entries(query)) url.searchParams.set(k, v);
  const init = { method, headers: {} };
  if (body !== undefined) {
    init.headers['content-type'] = 'application/json';
    init.body = JSON.stringify(body);
  }
  const res = await fetch(url.toString(), init);
  let data = null;
  try {
    data = await res.json();
  } catch {
    data = null;
  }
  if (!res.ok) {
    const error = (data && data.error) || `http-${res.status}`;
    throw new Error(error);
  }
  return data;
}

export async function health(server) {
  return call(server, API_PREFIX + 'health', { method: 'GET' });
}

export async function join(server, { card, pubB64, pow }) {
  const nonce = pow || (await solvePow());
  return call(server, API_PREFIX + 'join', { body: { card, pubkey: pubB64, pow: nonce } });
}

export async function candidates(server, token) {
  return call(server, API_PREFIX + 'candidates', { body: { token } });
}

/**
 * 服务器端匹配：只回几个公钥 + 分档 + 共同点数量，不下发名片。
 * 响应里没有对方的分区/标签/昵称，所以即使被截获也拿不到兴趣内容。
 */
export async function match(server, token, limit) {
  return call(server, API_PREFIX + 'match', { body: { token, limit } });
}

export async function interest(server, { token, to, privateKey, peerPubB64, contact }) {
  const blob = await encryptContact(privateKey, peerPubB64, contact);
  return call(server, API_PREFIX + 'interest', { body: { token, to, blob } });
}

export async function inbox(server, token) {
  return call(server, API_PREFIX + 'inbox', { method: 'GET', query: { token } });
}

export async function block(server, token, target) {
  return call(server, API_PREFIX + 'block', { body: { token, target } });
}

export async function leave(server, token) {
  return call(server, API_PREFIX + 'leave', { body: { token } });
}

// ---------------------------------------------------------------- 便捷封装

/**
 * 一次完整的"入池"：生成密钥、解 PoW、上传名片。
 * @returns {{token: string, pubB64: string, privJwk: object}}
 */
export async function joinWithKeys(server, card, bits = POW_BITS) {
  const keys = await generatePoolKeys();
  const pow = await solvePow(bits);
  const res = await join(server, { card, pubB64: keys.pubB64, pow });
  return { token: res.token, pubB64: keys.pubB64, privJwk: keys.privJwk };
}

/** 拉候选并把对方公钥带上，方便后续加密。 */
export async function fetchCandidates(server, token) {
  const res = await candidates(server, token);
  return (res.items || []).map((item) => ({
    token: item.token,
    card: item.card,
    pubkey: item.pubkey,
  }));
}

/** 收件箱里已互相同意的条目，用本机私钥解出对方的联系卡。 */
export async function openInbox(server, token, privJwk, peerPubkeyOf) {
  const res = await inbox(server, token);
  const privateKey = await importPrivateKey(privJwk);
  const items = [];
  for (const item of res.items || []) {
    let contact = null;
    if (item.mutual && item.blob) {
      const peerPub = peerPubkeyOf(item.from);
      if (peerPub) {
        try {
          contact = await decryptContact(privateKey, peerPub, item.blob);
        } catch {
          contact = null;
        }
      }
    }
    items.push({ ...item, contact });
  }
  return { items, sent: res.sent || [] };
}
