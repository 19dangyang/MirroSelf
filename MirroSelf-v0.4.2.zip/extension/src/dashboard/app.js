/**
 * 仪表盘应用：状态、动作、渲染。
 *
 * 数据流：IndexedDB → buildProfile() → views() → innerHTML。
 * 没有虚拟 DOM，也没有框架 —— 这个页面的规模不值得引入构建链。
 */

import { buildProfile, emptyProfile, assessProfile } from '../core/profile.js';
import { buildCard, encodeCard, decodeCard } from '../core/card.js';
import { rankCards, scoreCards, band, explainPair } from '../core/score.js';
import { joinWithKeys, match, interest as sendInterest, block as blockPeer, leave as leavePool, openInbox, importPrivateKey } from '../pool/client.js';
import { clusters, hygiene, recommendUps } from '../core/recommend.js';
import {
  getAll,
  countAll,
  putCards,
  deleteCard as deleteCardRecord,
  getMeta,
  clearAllData,
  dropDatabase,
  exportAll,
  importAll,
  STORE,
} from '../storage/db.js';
import { getSettings, updateSettings } from '../storage/settings.js';
import { OBSERVED_PATHS } from '../core/constants.js';
import {
  tabsHtml,
  overviewView,
  collectView,
  profileView,
  cleanView,
  cardsView,
  poolView,
  privacyView,
} from './views.js';

const VIEWS = {
  overview: overviewView,
  collect: collectView,
  profile: profileView,
  clean: cleanView,
  cards: cardsView,
  pool: poolView,
  privacy: privacyView,
};

const state = {
  tab: 'overview',
  items: [],
  interactions: [],
  cards: [],
  counts: {},
  profile: emptyProfile(),
  myCard: null,
  myCardText: '',
  rankedCards: [],
  settings: { collectEnabled: true, nickname: '', highlightTags: [] },
  stats: null,
  lastIngest: null,
  derived: null,
  selfCheck: null,
  probeSnapshot: null,
  diagSnapshot: null,
  poolCandidates: [],
  poolInbox: { items: [], sent: [] },
  busy: false,
};

const viewEl = document.getElementById('view');
const tabsEl = document.getElementById('tabs');
const toastEl = document.getElementById('toast');

/** 任何进 innerHTML 的字符串都必须走这里。 */
const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

// ---------------------------------------------------------------- 数据

async function refresh() {
  const [items, interactions, cards, counts] = await Promise.all([
    getAll(STORE.items),
    getAll(STORE.interactions),
    getAll(STORE.cards),
    countAll(),
  ]);
  state.items = items;
  state.interactions = interactions;
  state.cards = cards;
  state.counts = counts;
  state.profile = buildProfile({ items, interactions });
  state.settings = await getSettings();
  state.stats = await getMeta('ingestStats', null);
  state.lastIngest = await getMeta('lastIngest', null);
  state.derived = null;
  recomputeRanking();
}

function recomputeRanking() {
  if (state.myCard && state.cards.length) {
    state.rankedCards = rankCards(
      state.myCard,
      state.cards.map((r) => ({ ...r, card: r.card })),
    );
  } else {
    state.rankedCards = [];
  }
}

function ensureDerived() {
  if (state.derived) return;
  if (!state.profile || !(state.profile.itemCount > 0)) {
    state.derived = null;
    return;
  }
  const data = { items: state.items, interactions: state.interactions };
  state.derived = {
    hygiene: hygiene(data),
    clusters: clusters(data, { k: 5 }),
    ups: recommendUps(data, { limit: 8 }),
  };
}

// ---------------------------------------------------------------- 渲染

function render() {
  if (state.tab === 'clean') ensureDerived();
  if (state.tab === 'cards') recomputeRanking();
  tabsEl.innerHTML = tabsHtml(state.tab);
  const view = VIEWS[state.tab] || overviewView;
  viewEl.innerHTML = view(state);
}

function toast(message, kind = 'ok') {
  toastEl.textContent = message;
  toastEl.className = `toast ${kind}`;
  toastEl.hidden = false;
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => {
    toastEl.hidden = true;
  }, 2600);
}

function download(filename, text, mime = 'text/plain;charset=utf-8') {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

// ---------------------------------------------------------------- 动作

async function act(action, el) {
  switch (action) {
    case 'tab':
      state.tab = el.dataset.tab || 'overview';
      render();
      return;

    case 'refresh':
      await refresh();
      render();
      toast('已刷新');
      return;

    case 'generate-card': {
      if (!(state.profile?.itemCount > 0)) {
        toast('还没有数据，无法生成名片', 'warn');
        return;
      }
      const nickname = viewEl.querySelector('[data-field="nickname"]')?.value?.trim() || '';
      const highlightRaw = viewEl.querySelector('[data-field="highlight"]')?.value || '';
      const highlightTags = highlightRaw
        .split(/[,，\s]+/)
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 8);
      await updateSettings({ nickname, highlightTags });
      state.settings = await getSettings();
      state.myCard = buildCard(state.profile, { nickname, highlightTags, seed: Date.now() });
      state.myCardText = encodeCard(state.myCard);
      recomputeRanking();
      render();
      toast('名片已生成，先自己看一眼内容');
      return;
    }

    case 'copy-card': {
      const text = state.myCardText || viewEl.querySelector('[data-role="card-text"]')?.value || '';
      if (!text) {
        toast('先生成名片', 'warn');
        return;
      }
      try {
        await navigator.clipboard.writeText(text);
        toast('已复制到剪贴板');
      } catch {
        const ta = viewEl.querySelector('[data-role="card-text"]');
        if (ta) {
          ta.select();
          document.execCommand('copy');
          toast('已复制');
        } else {
          toast('复制失败，请手动选择文本', 'warn');
        }
      }
      return;
    }

    case 'download-card': {
      if (!state.myCardText) {
        toast('先生成名片', 'warn');
        return;
      }
      download('mirror-card.txt', state.myCardText);
      toast('已保存');
      return;
    }

    case 'import-card': {
      const ta = viewEl.querySelector('[data-role="import-text"]');
      const text = ta?.value || '';
      await importCardText(text);
      return;
    }

    case 'delete-card': {
      const id = el.dataset.id;
      if (!id) return;
      await deleteCardRecord(id);
      await refresh();
      render();
      toast('已删除名片');
      return;
    }

    case 'export-backup': {
      const payload = await exportAll();
      download(`mirror-backup-${new Date().toISOString().slice(0, 10)}.json`, JSON.stringify(payload, null, 1), 'application/json');
      toast('备份已导出');
      return;
    }

    case 'clear-data': {
      if (!confirm('确定清空全部数据吗？此操作不可撤销。')) return;
      await clearAllData();
      state.myCard = null;
      state.myCardText = '';
      await refresh();
      render();
      toast('已清空');
      return;
    }

    case 'drop-db': {
      if (!confirm('确定删除整个数据库吗？连库带结构一起删掉。')) return;
      await dropDatabase();
      state.myCard = null;
      state.myCardText = '';
      await refresh();
      render();
      toast('数据库已删除');
      return;
    }

    case 'self-check': {
      await runSelfCheck();
      return;
    }

    case 'harvest-dom': {
      if (!chrome?.tabs?.query) {
        toast('当前环境不支持标签页操作', 'warn');
        return;
      }
      const favTabs = await chrome.tabs.query({ url: ['https://space.bilibili.com/*'] });
      const tab = favTabs[0];
      if (!tab) {
        toast('请先打开你的收藏夹页，再回来点这个按钮', 'warn');
        return;
      }
      try {
        const r = await chrome.tabs.sendMessage(tab.id, { type: 'mirror:harvest' });
        if (r && r.ok) {
          await refresh();
          render();
          toast(`已从收藏夹页按"收藏"记账 ${r.count} 条`);
        } else {
          toast('这个页面上没扫到视频链接 —— 先往下滚一屏让它渲染出来', 'warn');
        }
      } catch {
        toast('该标签页没有响应：按 F5 刷新它，再点一次', 'warn');
      }
      return;
    }

    case 'copy-diag': {
      if (!state.diagSnapshot) await runSelfCheck();
      const text = JSON.stringify(state.diagSnapshot, null, 2);
      try {
        await navigator.clipboard.writeText(text);
        toast('诊断信息已复制到剪贴板，粘贴给我就行');
      } catch {
        download('mirroself-diag.json', text, 'application/json');
        toast('剪贴板不可用，已下载为 json 文件', 'warn');
      }
      return;
    }

    case 'clear-drops': {
      try {
        await chrome.runtime.sendMessage({ type: 'mirror:clear-drops' });
      } catch {
        /* ignore */
      }
      toast('已清空丢弃记录');
      return;
    }

    case 'toggle-collector': {
      const id = el.dataset.id;
      if (!id) return;
      const next = !!el.checked;
      await updateSettings({ collectors: { [id]: next } });
      state.settings = await getSettings();
      render();
      toast(next ? '已开启' : '已关闭', next ? 'ok' : 'warn');
      return;
    }

    case 'pool-join': {
      const server = (viewEl.querySelector('[data-field="pool-server"]')?.value || '').trim();
      const contact = (viewEl.querySelector('[data-field="pool-contact"]')?.value || '').trim();
      if (!/^https?:\/\//.test(server)) {
        toast('先填一个 http(s) 开头的服务端地址', 'warn');
        return;
      }
      if (!(state.profile?.itemCount > 0)) {
        toast('还没有数据，先攒一点再入池', 'warn');
        return;
      }
      const usability = assessProfile(state.profile);
      if (!usability.usable) {
        toast('画像太薄，入池也没法比对：' + usability.reason, 'warn');
        return;
      }

      const card = buildCard(state.profile, {
        nickname: state.settings.nickname || '',
        highlightTags: state.settings.highlightTags || [],
        seed: Date.now(),
      });

      state.busy = true;
      render();
      try {
        // 换服务器时先把旧的在旧池里删掉，别留尸
        const old = state.settings.pool || {};
        if (old.token && old.server && old.server !== server) {
          try {
            await leavePool(old.server, old.token);
          } catch {
            /* 旧池联系不上就算了 */
          }
        }

        const joined = await joinWithKeys(server, card);
        await updateSettings({
          pool: {
            server,
            contact,
            token: joined.token,
            pubB64: joined.pubB64,
            privJwk: joined.privJwk,
            joinedAt: Date.now(),
            card,
          },
        });
        state.settings = await getSettings();
        state.poolCandidates = [];
        state.poolInbox = { items: [], sent: [] };
        toast('已入池。服务端只拿到名片和公钥');
      } catch (err) {
        toast('入池失败：' + (err?.message || err), 'warn');
      } finally {
        state.busy = false;
        render();
      }
      return;
    }

    case 'pool-leave': {
      const pool = state.settings.pool || {};
      if (!pool.token) return;
      try {
        await leavePool(pool.server, pool.token);
      } catch (err) {
        toast('服务端没删掉（可能已过期）：' + (err?.message || err), 'warn');
      }
      await updateSettings({ pool: { server: pool.server, contact: pool.contact, token: '', pubB64: '', privJwk: null, joinedAt: 0, card: null } });
      state.settings = await getSettings();
      state.poolCandidates = [];
      state.poolInbox = { items: [], sent: [] };
      render();
      toast('已退出，服务端记录已删除');
      return;
    }

    case 'pool-refresh': {
      const pool = state.settings.pool || {};
      if (!pool.token) {
        toast('先入池', 'warn');
        return;
      }
      state.busy = true;
      render();
      try {
        // 服务器替我们排序，只回几个公钥 —— 不下发名片，省带宽也少泄露
        const res = await match(pool.server, pool.token, 20);
        const peers = { ...(pool.peers || {}) };
        state.poolCandidates = (res.matches || []).map((m) => {
          peers[m.token] = m.pubkey;
          return {
            token: m.token,
            pubkey: m.pubkey,
            band: { level: m.band, label: m.bandLabel },
            score: m.score,
            shared: m.shared || { partitions: 0, tags: 0 },
          };
        });
        await updateSettings({ pool: { peers } });
        state.settings = await getSettings();

        if (pool.privJwk) {
          const box = await openInbox(pool.server, pool.token, pool.privJwk, (from) => peers[from] || '');
          state.poolInbox = box;
        }
        toast(`服务器匹配到 ${state.poolCandidates.length} 个同频的人`);
      } catch (err) {
        toast('刷新失败：' + (err?.message || err), 'warn');
      } finally {
        state.busy = false;
        render();
      }
      return;
    }

    case 'pool-interest': {
      const pool = state.settings.pool || {};
      const to = el.dataset.to;
      const pub = el.dataset.pub;
      if (!pool.token || !to || !pub) return;
      if (!pool.contact) {
        toast('先在上面的输入框填一个愿意公开的联系方式', 'warn');
        return;
      }
      try {
        const key = await importPrivateKey(pool.privJwk);
        await sendInterest(pool.server, {
          token: pool.token,
          to,
          privateKey: key,
          peerPubB64: pub,
          contact: { contact: pool.contact },
        });
        toast('已发送，等对方也点「想认识」');
      } catch (err) {
        toast('发送失败：' + (err?.message || err), 'warn');
      }
      return;
    }

    case 'pool-block': {
      const pool = state.settings.pool || {};
      const to = el.dataset.to;
      if (!pool.token || !to) return;
      try {
        await blockPeer(pool.server, pool.token, to);
        toast('已屏蔽');
      } catch (err) {
        toast('屏蔽失败：' + (err?.message || err), 'warn');
      }
      return;
    }

    case 'toggle-collect': {
      const next = !!el.checked;
      await updateSettings({ collectEnabled: next });
      state.settings = await getSettings();
      render();
      toast(next ? '采集已开启' : '采集已暂停', next ? 'ok' : 'warn');
      return;
    }

    case 'import-backup': {
      const file = el.files && el.files[0];
      if (!file) return;
      const text = await file.text();
      try {
        const payload = JSON.parse(text);
        const result = await importAll(payload);
        await refresh();
        render();
        toast(`导入完成：作品 ${result.items} · 行为 ${result.interactions} · 名片 ${result.cards}`);
      } catch (err) {
        toast('备份导入失败：' + (err?.message || err), 'warn');
      }
      el.value = '';
      return;
    }

    case 'import-card-file': {
      const file = el.files && el.files[0];
      if (!file) return;
      const text = await file.text();
      await importCardText(text);
      el.value = '';
      return;
    }

    default:
      return;
  }
}

// ---------------------------------------------------------------- 自检

function reasonLabel(reason) {
  return { origin: '来源不在白名单', parse: '解析失败', size: '体积超限', empty: '认得接口但没数据' }[reason] || reason;
}

function dropHint(drop) {
  if (drop.reason === 'origin') return '这条响应来自不受支持的域名，或该标签页没有站点权限';
  if (drop.reason === 'size') return '单条响应超过 400KB，已截断丢弃';
  if (drop.reason === 'empty') {
    if (/history\/report/.test(String(drop.url || ''))) return '这是观看心跳上报，本来就没有列表数据，正常忽略即可';
    // 历史接口是按 business 分批拉的：live / pgc / article 三个批次里
    // 本来就没有稿件记录，全部被过滤是预期行为，不是故障。
    if (drop.source === 'history' && Number(drop.ignored) > 0) {
      return `这一批是直播/番剧/专栏（ignored: ${drop.ignored}），本来就不进画像，正常跳过`;
    }
    if (drop.source === 'history' && Number(drop.skippedProgress) > 0) {
      return `这一批全部因观看进度不足 30% 被跳过（${drop.skippedProgress} 条）`;
    }
    return '接口返回成功但内容为空，通常是页面还没加载出列表，或该页面不是你的个人页';
  }
  const err = String(drop.error || '');
  if (err === 'page-state-missing') {
    const d = drop.diag || {};
    const kind = d.kind === 'favlist' ? '收藏夹页' : '视频页';
    const listish = Array.isArray(d.listishKeys) && d.listishKeys.length ? `，疑似列表字段：${d.listishKeys.join(', ')}` : '';
    const keys = Array.isArray(d.keys) && d.keys.length ? `，页面状态键：${d.keys.slice(0, 8).join(', ')}` : '，页面里没有 __INITIAL_STATE__';
    return `${kind}里没找到可用的内联状态${keys}${listish} —— 把这一行发给我就能定位`;
  }
  if (/code:-101/.test(err)) return '账号未登录，页面本身也没拿到数据';
  if (/code:(-352|-412)/.test(err)) return '触发了平台风控（-352/-412），稍后重试或降低浏览频率';
  if (/code:/.test(err)) return '接口返回了业务错误码，通常意味着该页面没有加载到你的数据';
  if (/json/.test(err)) return '响应不是合法 JSON（可能被登录页拦截）';
  return '解析器不认识这个响应，可能是接口变了';
}

async function runSelfCheck() {
  const results = [];
  const push = (ok, label, detail, hint) => results.push({ ok, label, detail, hint });

  try {
    const m = chrome.runtime.getManifest();
    push(true, '扩展已加载', `${m.name} v${m.version}`);
  } catch {
    push(false, '扩展已加载', '拿不到 manifest，当前可能不是扩展环境');
  }

  const originPatterns = ['https://www.bilibili.com/*', 'https://space.bilibili.com/*'];
  if (!chrome?.permissions?.contains) {
    push(false, '站点权限', '当前环境不支持权限查询', '请确认是在扩展页面里打开本页');
  } else {
    try {
      const has = await chrome.permissions.contains({ origins: originPatterns });
      push(
        !!has,
        '站点权限',
        has ? 'www + space 均已授权' : '缺少站点权限',
        has ? '' : '打开扩展详情页，确认"网站访问权限"允许访问 bilibili.com',
      );
    } catch (err) {
      push(false, '站点权限', '检查失败：' + (err?.message || err));
    }
  }

  let ping = null;
  const t0 = performance.now();
  try {
    ping = await chrome.runtime.sendMessage({ type: 'mirror:ping' });
  } catch {
    /* ignore */
  }
  push(
    !!ping?.ok,
    '后台 service worker',
    ping?.ok ? `响应 ${Math.round(performance.now() - t0)}ms` : '无响应',
    ping?.ok ? '' : '去扩展管理页点「重新加载」，然后刷新 B 站页面',
  );

  let diag = null;
  try {
    diag = await chrome.runtime.sendMessage({ type: 'mirror:diag' });
  } catch {
    /* ignore */
  }
  if (diag?.ok) {
    const s = diag.stats || {};
    push(
      true,
      '入库统计',
      `收到 ${s.received || 0} 条响应 · 接受 ${s.accepted || 0} · 来源丢弃 ${s.droppedByOrigin || 0} · 解析丢弃 ${s.droppedByParse || 0} · 体积丢弃 ${s.droppedBySize || 0} · 空结果 ${s.droppedByEmpty || 0}`,
    );
    const items = diag.counts?.items || 0;
    push(items > 0, '本机数据', `${items} 作品 / ${diag.counts?.interactions || 0} 行为`, items > 0 ? '' : '还没有数据，按下面几项继续排查');
  } else {
    push(false, '入库统计', '拿不到后台数据');
  }

  let tabs = [];
  if (chrome?.tabs?.query) {
    try {
      tabs = await chrome.tabs.query({ url: originPatterns });
    } catch {
      /* ignore */
    }
  }

  if (tabs.length === 0) {
    push(false, 'B 站标签页', '没有已打开的 B 站页面', '先打开历史记录页，再回来点自检');
  } else {
    const alive = [];
    for (const t of tabs.slice(0, 6)) {
      try {
        const r = await chrome.tabs.sendMessage(t.id, { type: 'mirror:probe' });
        if (r && r.ok) alive.push({ tab: t, probe: r });
      } catch {
        /* 没有内容脚本 */
      }
    }
    state.probeSnapshot = {
      tabs: tabs.map((t) => String(t.url || '')),
      alive: alive.map((a) => ({ url: String(a.tab.url || ''), ...a.probe })),
      missing: tabs.length - alive.length,
    };
    push(
      alive.length > 0,
      `B 站标签页 ×${tabs.length}`,
      alive.length > 0 ? `${alive.length} 个已注入内容脚本` : '一个都没注入',
      alive.length > 0 ? '' : '按 F5 刷新这些 B 站页面 —— 内容脚本只在页面加载时注入，扩展是之后才装上的',
    );
    if (alive.length > 0 && alive.length < tabs.length) {
      push(
        false,
        `其中 ${tabs.length - alive.length} 个标签页未注入`,
        '这些页面是在扩展加载/重载之前打开的',
        '逐个按 F5 刷新，或者关掉重开一个标签页',
      );
    }
    for (const a of alive.slice(0, 4)) {
      const u = String(a.tab.url || '').replace(/^https?:\/\//, '').slice(0, 52);
      const wired = !!a.probe.sawInject;
      push(
        !!a.probe.enabled && wired,
        '· ' + u,
        a.probe.enabled
          ? `采集开启 · 观察器${wired ? '已连接' : '未连接'} · 已转发 ${a.probe.forwarded || 0} 条`
          : '采集已暂停（上方开关）',
        !wired
          ? '页面主世界的观察器没对上话：多半是浏览器版本低于 111（不支持 MAIN world 内容脚本）'
          : a.probe.forwarded
            ? ''
            : '已连接但还没转发过 —— 在该页面滚动或刷新，让页面自己去请求数据',
      );

      // 目击名单：这个页面到底请求了哪些 B 站接口。采不到数据时，这里是唯一的线索。
      const sights = Array.isArray(a.probe.sightings) ? a.probe.sightings : [];
      if (sights.length) {
        const known = new Set(OBSERVED_PATHS.filter((p) => p.startsWith('/')));
        const api = sights.filter(([p]) => typeof p === 'string' && p.startsWith('/x/')).slice(0, 10);

        // 关键区分：白名单内但没转发 = 通道/过滤出了问题；不在白名单 = 接口可能变了。
        const inList = api.filter(([p]) => known.has(p));
        const notInList = api.filter(([p]) => !known.has(p));

        if (inList.length && !a.probe.forwarded) {
          push(
            false,
            '· 白名单内却没转发',
            inList.map(([p, c]) => `${p} ×${c}`).join('   '),
            '观察器看见了这些接口，却没有一条被转发 —— 说明卡在过滤或消息通道，而不是路径',
          );
        }
        if (notInList.length) {
          push(
            true,
            `· 未采集的接口（${notInList.length} 个，多为广告/配置/搜索联想）`,
            notInList.map(([p, c]) => `${p} ×${c}`).join('   '),
            '只有当你在这个页面上确认"应该出现收藏/历史列表却没出现"时，才需要把它加进白名单',
          );
        }

        // 到了内容脚本却被拒收的响应 —— 这一类最隐蔽：接口在白名单里、页面也在请求，
        // 就是没进库。v0.2.4 之前这里只有计数，没有原因。
        const rejects = Array.isArray(a.probe.recentRejects) ? a.probe.recentRejects : [];
        if (rejects.length) {
          push(
            false,
            '· 被拒收的响应',
            rejects
              .slice(0, 3)
              .map((r) => `${r.url}（${r.reason}）`)
              .join('   '),
            '这些响应已经送到了内容脚本，但没通过粗筛 —— 把这一行发我',
          );
        }
      }
    }
  }

  if (diag?.drops?.length) {
    for (const d of diag.drops.slice(0, 4)) {
      push(false, `丢弃记录：${reasonLabel(d.reason)}`, String(d.url || d.tabUrl || '').slice(0, 72), dropHint(d));
    }
  }

  state.selfCheck = results;
  state.diagSnapshot = {
    at: new Date().toISOString(),
    version: (() => {
      try {
        return chrome.runtime.getManifest().version;
      } catch {
        return 'unknown';
      }
    })(),
    counts: diag?.counts || null,
    stats: diag?.stats || null,
    drops: diag?.drops || null,
    lastIngest: diag?.lastIngest || null,
    tabs: state.probeSnapshot || null,
  };
  render();
  const bad = results.filter((r) => !r.ok).length;
  toast(bad === 0 ? '自检通过，链路正常' : `自检发现 ${bad} 个问题，看下面的提示`, bad === 0 ? 'ok' : 'warn');
}

async function importCardText(text) {  const raw = String(text || '').trim();
  if (!raw) {
    toast('先粘贴对方的名片文本', 'warn');
    return;
  }
  const lines = raw
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l.length > 20);

  // 也支持整段没有换行的情况
  if (lines.length === 0) lines.push(raw.replace(/\s+/g, ''));

  const records = [];
  const failures = [];
  for (const line of lines) {
    try {
      const card = decodeCard(line);
      records.push({ cardId: card.id, card, nickname: card.n || '', importedAt: Date.now() });
    } catch (err) {
      failures.push(err?.message || String(err));
    }
  }

  if (records.length === 0) {
    toast('导入失败：' + (failures[0] || '无法解析'), 'warn');
    return;
  }

  await putCards(records);
  await refresh();
  render();
  toast(`已导入 ${records.length} 张名片${failures.length ? `，${failures.length} 张失败` : ''}`);
}

// ---------------------------------------------------------------- 事件

document.addEventListener('click', (event) => {
  const el = event.target.closest('[data-action]');
  if (!el) return;
  const action = el.dataset.action;
  if (action === 'import-backup' || action === 'import-card-file') return; // 由 change 处理
  if (el.tagName === 'INPUT') return; // 复选框统一走 change
  event.preventDefault();
  act(action, el).catch((err) => {
    console.error(err);
    toast('出错了：' + (err?.message || err), 'warn');
  });
});

document.addEventListener('change', (event) => {
  const el = event.target;
  if (!el || !el.dataset || !el.dataset.action) return;
  const action = el.dataset.action;
  act(action, el).catch((err) => {
    console.error(err);
    toast('出错了：' + (err?.message || err), 'warn');
  });
});

// 切回这个标签页时自动刷新（比如刚在 B 站逛完）
document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible') {
    refresh()
      .then(render)
      .catch(() => {});
  }
});

// ---------------------------------------------------------------- 启动

(async function init() {
  const params = new URLSearchParams(location.search);
  if (params.get('tab')) state.tab = params.get('tab');
  if (params.get('welcome')) {
    setTimeout(() => toast('欢迎：先去"采集"页看看怎么攒数据'), 400);
  }
  await refresh();
  render();
  // 支持 ?selfcheck=1 直接跑一次读写自检（方便你截图反馈给我）
  if (params.get('selfcheck')) await runSelfCheck();
})().catch((err) => {
  viewEl.innerHTML = `<div class="empty"><h3>初始化失败</h3><p>${esc(err?.message || err)}</p></div>`;
});
