/**
 * 视图层：纯函数，输入 state，输出 HTML 字符串。
 * 不直接碰 DOM，方便将来换框架或做快照测试。
 */

import { describeProfile } from '../core/profile.js';
import { describeCard } from '../core/card.js';
import { band } from '../core/score.js';
import { COLLECTORS } from '../core/constants.js';

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const pct = (x) => Math.round((Number(x) || 0) * 100) + '%';

export const TABS = [
  { id: 'overview', label: '概览' },
  { id: 'collect', label: '采集' },
  { id: 'profile', label: '画像' },
  { id: 'clean', label: '整理' },
  { id: 'cards', label: '名片' },
  { id: 'pool', label: '匹配池' },
  { id: 'privacy', label: '隐私' },
];

export function tabsHtml(active) {
  return TABS.map(
    (t) => `<button class="tab${t.id === active ? ' is-active' : ''}" data-action="tab" data-tab="${t.id}">${t.label}</button>`,
  ).join('');
}

function statCard(label, value, hint = '') {
  return `<div class="stat"><div class="stat-value">${esc(value)}</div><div class="stat-label">${esc(label)}</div>${
    hint ? `<div class="stat-hint">${esc(hint)}</div>` : ''
  }</div>`;
}

function emptyState(title, desc, actionHtml = '') {
  return `<div class="empty"><h3>${esc(title)}</h3><p>${esc(desc)}</p>${actionHtml}</div>`;
}

function bar(share, label, right) {
  const width = Math.max(2, Math.round(share * 100));
  return `<div class="bar-row">
    <div class="bar-label" title="${esc(label)}">${esc(label)}</div>
    <div class="bar-track"><div class="bar-fill" style="width:${width}%"></div></div>
    <div class="bar-right">${esc(right)}</div>
  </div>`;
}

// ---------------------------------------------------------------- 概览

export function overviewView(state) {
  const { counts, profile, settings, lastIngest } = state;
  const hasData = (counts.items || 0) > 0;

  const header = `<section class="hero">
    <h1>${hasData ? '你的兴趣镜像' : '先给自己攒一点数据'}</h1>
    <p>${esc(describeProfile(profile))}</p>
  </section>`;

  const stats = `<div class="stats">
    ${statCard('作品', counts.items || 0, '含分区/标签的作品')}
    ${statCard('行为', counts.interactions || 0, '收藏 / 点赞 / 历史')}
    ${statCard('名片', counts.cards || 0, '已导入的他人名片')}
    ${statCard('可信度', pct(profile?.confidence || 0), '数据量与覆盖度')}
  </div>${
    profile?.implicitWatches
      ? `<p class="muted small">其中 <b>${profile.implicitWatches}</b> 条作品只有元数据、没有行为记录，
         已按"打开过那个视频页"计入画像（权重按观看的一半算）。</p>`
      : ''
  }`;

  if (!hasData) {
    return (
      header +
      stats +
      emptyState(
        '还没有采集任何数据',
        '打开 B 站，正常浏览你的历史记录与收藏夹，插件会在后台静静地记下你自己看过的内容。',
        `<button class="btn primary" data-action="tab" data-tab="collect">去看采集指引 →</button>`,
      ) +
      complianceBanner()
    );
  }

  const coverage = `<section class="panel">
    <h2>数据完整度</h2>
    <p class="muted">分区来自视频详情页；标签来自详情页的 Tags。打开更多视频页，画像会更准。</p>
    ${bar(profile?.coverage?.category || 0, '分区样本', `${profile?.metadata?.category || 0} / ${profile?.metadata?.target || 100} 条`)}
    ${bar(profile?.coverage?.tags || 0, '标签样本', `${profile?.metadata?.tags || 0} / ${profile?.metadata?.target || 100} 条`)}
    ${bar(profile?.concentration || 0, '兴趣集中度', pct(profile?.concentration || 0))}
    <p class="muted small">样本量按 100 条为"充足"。没有分区/标签的条目（例如收藏夹里的）不参与向量计算，也不拉低这个比例。</p>
  </section>`;

  const recent = lastIngest?.at
    ? `<section class="panel"><h2>最近一次采集</h2>
        <p class="muted">${esc(new Date(lastIngest.at).toLocaleString())} · 来源 ${esc(lastIngest.source)} ·
        ${lastIngest.items || 0} 条作品 · ${lastIngest.interactions || 0} 条行为${
          lastIngest.skippedProgress ? ` · <b class="warn">按观看进度跳过 ${lastIngest.skippedProgress} 条</b>` : ''
        }</p></section>`
    : '';

  const next = `<section class="panel">
    <h2>下一步</h2>
    <div class="actions">
      <button class="btn" data-action="tab" data-tab="profile">看兴趣画像</button>
      <button class="btn" data-action="tab" data-tab="clean">整理收藏夹</button>
      <button class="btn primary" data-action="tab" data-tab="cards">生成兴趣名片</button>
    </div>
    <p class="muted small">采集开关：${settings.collectEnabled ? '<b class="ok">已开启</b>' : '<b class="warn">已暂停</b>'} · 所有数据仅存于本机</p>
  </section>`;

  return header + stats + coverage + recent + next + complianceBanner();
}

// ---------------------------------------------------------------- 采集

export function collectView(state) {
  const s = state.stats || {};
  const bySource = s.bySource || {};
  const rows = Object.entries(bySource)
    .map(([k, v]) => `<tr><td>${esc(sourceLabel(k))}</td><td class="num">${esc(v)}</td></tr>`)
    .join('');

  const steps = `<section class="panel">
    <h2>怎么攒数据（三个来源，都是你自己看过的）</h2>
    <ol class="steps">
      <li>
        <b>历史记录</b>：打开
        <a href="https://www.bilibili.com/account/history" target="_blank" rel="noopener">bilibili.com/account/history</a>，
        往下滚几屏就行。它会带来"看过什么"。
        <span class="muted small">只保留观看进度 ≥ 30% 的条目 —— 划一下就走的不算兴趣证据。</span>
      </li>
      <li>
        <b>收藏夹</b>：点右上角头像 → 收藏 → 打开任意一个收藏夹，往下翻。它会带来"你主动收藏了什么"。
      </li>
      <li>
        <b>视频页</b>：随便点开 3~5 个你感兴趣的视频。视频页会带回精确的分区和标签，这是"分区相似"的关键。
      </li>
    </ol>
    <p class="muted small">插件只读取这些页面自己已经请求回来的内容，不会替你发请求、不会翻页、不会访问别人的主页。</p>
  </section>`;

  const toggle = `<section class="panel">
    <h2>采集开关</h2>
    <label class="switch">
      <input type="checkbox" data-action="toggle-collect" ${state.settings.collectEnabled ? 'checked' : ''}>
      <span>${state.settings.collectEnabled ? '正在采集' : '已暂停'}</span>
    </label>
    <p class="muted small">暂停后页面不再上报任何内容，已采集的数据保留。</p>
  </section>`;

  const table = `<section class="panel">
    <h2>采集统计</h2>
    <table class="table">
      <thead><tr><th>来源</th><th class="num">入库条数</th></tr></thead>
      <tbody>${rows || '<tr><td colspan="2" class="muted">还没有记录</td></tr>'}</tbody>
    </table>
    <p class="muted small">
      收到 ${s.received || 0} 条响应 · 接受 ${s.accepted || 0} · 非本站来源丢弃 ${s.droppedByOrigin || 0} ·
      解析失败 ${s.droppedByParse || 0} · 空结果 ${s.droppedByEmpty || 0}<br>
      按观看进度跳过 <b>${s.skippedProgress || 0}</b> 条 · 跳过非稿件（直播/番剧/专栏）<b>${s.skippedIgnored || 0}</b> 条
    </p>
  </section>`;

  return `<section class="hero"><h1>采集</h1><p>你自己浏览，插件在旁边记账。</p></section>` + steps + toggle + collectorSwitches(state) + table + selfCheckPanel(state) + complianceBanner();
}

function collectorSwitches(state) {
  const map = (state.settings && state.settings.collectors) || {};
  const rows = COLLECTORS.map(
    (c) => `<label class="collector-row">
      <input type="checkbox" data-action="toggle-collector" data-id="${esc(c.id)}" ${map[c.id] !== false ? 'checked' : ''}>
      <span class="collector-name">${esc(c.label)}</span>
      <span class="collector-desc">${esc(c.desc)}</span>
    </label>`,
  ).join('');
  return `<section class="panel">
    <h2>采集器开关</h2>
    <p class="muted small">每个数据源可以单独关掉。总开关关掉时，这里全部失效。</p>
    <div class="collectors">${rows}</div>
  </section>`;
}

function selfCheckPanel(state) {
  return `<section class="panel">
    <h2>读写自检</h2>
    <p class="muted small">采集不到数据时先点这里。它会依次检查：站点权限 → 后台 → B 站标签页 → 内容脚本 → 最近的丢弃原因。</p>
    <div class="actions">
      <button class="btn primary" data-action="self-check">运行自检</button>
      <button class="btn" data-action="harvest-dom">采集当前收藏夹页可见列表</button>
      <button class="btn" data-action="copy-diag">复制诊断信息</button>
      <button class="btn" data-action="clear-drops">清空丢弃记录</button>
    </div>
    <p class="muted small">「采集可见列表」只把页面上已经渲染出来的视频按**收藏**记账，不产生条目 —— 收藏夹卡片本身没有分区和标签，凭空造条目只会把覆盖率稀释掉。</p>
    <div id="selfcheck">${state.selfCheck ? renderSelfCheck(state.selfCheck) : ''}</div>
  </section>`;
}

function renderSelfCheck(results) {
  const rows = results
    .map((r) => {
      const mark = r.ok ? '<b class="ok">✓</b>' : '<b class="warn">✗</b>';
      return `<div class="check-row">
        <span class="check-mark">${mark}</span>
        <span class="check-label">${esc(r.label)}</span>
        <span class="check-detail">${esc(r.detail || '')}</span>
        ${r.hint ? `<div class="check-hint">→ ${esc(r.hint)}</div>` : ''}
      </div>`;
    })
    .join('');
  return `<div class="checks">${rows}</div>${selfCheckSummary(results)}`;
}

function selfCheckSummary(results) {
  const bad = results.filter((r) => !r.ok);
  if (bad.length === 0) return '<p class="muted small ok">全部正常。</p>';
  return `<p class="muted small warn">有 ${bad.length} 项需要处理，按上面的 → 提示操作即可。</p>`;
}

function sourceLabel(k) {
  return (
    {
      'fav-resource-list': '收藏夹',
      history: '历史记录',
      view: '视频详情',
      'view-detail': '视频详情（含标签）',
    }[k] || k
  );
}

// ---------------------------------------------------------------- 画像

export function profileView(state) {
  const p = state.profile;
  if (!p || !(p.itemCount > 0)) {
    return `<section class="hero"><h1>兴趣画像</h1></section>` + emptyState('画像还是空的', '先去采集页攒一些数据。', `<button class="btn primary" data-action="tab" data-tab="collect">去采集</button>`);
  }

  const partitions = p.topPartitions.slice(0, 10).map((x) => bar(x.share, x.name, pct(x.share))).join('');
  const tags = p.topTags
    .slice(0, 24)
    .map((t) => {
      const w = p.topTags[0]?.weight > 0 ? t.weight / p.topTags[0].weight : 0;
      return `<span class="chip" style="opacity:${(0.45 + w * 0.55).toFixed(2)}">#${esc(t.name)}</span>`;
    })
    .join('');
  const ups = p.topUps.length
    ? `<table class="table"><thead><tr><th>UP 主</th><th class="num">权重</th></tr></thead><tbody>${p.topUps
        .slice(0, 8)
        .map((u) => `<tr><td>${esc(u.name)}</td><td class="num">${pct(u.share)}</td></tr>`)
        .join('')}</tbody></table>`
    : '<p class="muted">UP 主信息还没采到。</p>';

  const peak = Math.max(...(p.timeHist || [0]));
  const hours = (p.timeHist || [])
    .map((v, i) => {
      const h = peak > 0 ? Math.round((v / peak) * 100) : 0;
      return `<div class="hour" title="${i}:00 — ${pct(v)}"><div class="hour-fill" style="height:${Math.max(2, h)}%"></div><span>${i % 6 === 0 ? i : ''}</span></div>`;
    })
    .join('');

  const concentrationNote =
    p.concentration > 0.35
      ? '高度聚焦：你的兴趣非常集中，名片会很容易匹配到同类人。'
      : p.concentration > 0.18
        ? '比较均衡：你有几条并行的兴趣线。'
        : '非常分散：兴趣面很宽，相似度分数会被"稀释"，这在正常范围内。';

  return `<section class="hero"><h1>兴趣画像</h1><p>${esc(describeProfile(p))}</p></section>
  <section class="panel"><h2>分区分布</h2>${partitions || '<p class="muted">没有分区信息</p>'}
    <p class="muted small">${esc(concentrationNote)}</p></section>
  <section class="panel"><h2>高频标签</h2><div class="chips">${tags || '<p class="muted">没有标签信息，多打开几个视频页试试</p>'}</div></section>
  <section class="panel"><h2>常看的 UP 主</h2>${ups}<p class="muted small">这部分只在本机使用，不会写进名片。</p></section>
  <section class="panel"><h2>活跃时段</h2><div class="hours">${hours}</div></section>`;
}

// ---------------------------------------------------------------- 整理

export function cleanView(state) {
  const d = state.derived;
  if (!state.profile || !(state.profile.itemCount > 0) || !d) {
    return `<section class="hero"><h1>整理</h1></section>` + emptyState('还没有可整理的内容', '先采集一些收藏和历史。', `<button class="btn primary" data-action="tab" data-tab="collect">去采集</button>`);
  }

  const h = d.hygiene;
  const dup = h.duplicates.length
    ? `<ul class="list">${h.duplicates
        .slice(0, 8)
        .map((x) => `<li><b>${esc(x.title)}</b><span class="muted"> · ${x.items.length} 条</span></li>`)
        .join('')}</ul>`
    : '<p class="muted">没有发现重复收藏。</p>';

  const oneShot = h.oneShot.length
    ? `<ul class="list">${h.oneShot
        .slice(0, 8)
        .map((x) => `<li>${esc(x.title)}<span class="muted"> · ${esc(x.upName)}</span></li>`)
        .join('')}</ul>`
    : '<p class="muted">没有这类作品。</p>';

  const tail = h.tail.length
    ? `<ul class="list">${h.tail
        .slice(0, 8)
        .map((x) => `<li>${esc(x.title)}<span class="muted"> · 相似度 ${pct(x.sim)}</span></li>`)
        .join('')}</ul>`
    : '<p class="muted">你的收藏很聚焦，没有明显长尾。</p>';

  const clustersHtml = d.clusters.clusters.length
    ? d.clusters.clusters
        .map(
          (c) => `<div class="cluster">
            <div class="cluster-head"><b>${esc(c.label)}</b><span class="pill">${c.size} 条</span></div>
            <div class="chips small">${c.tags.map((t) => `<span class="chip">#${esc(t)}</span>`).join('')}</div>
            <ul class="list">${c.sample.map((s) => `<li>${esc(s.title)}<span class="muted"> · ${esc(s.upName)}</span></li>`).join('')}</ul>
          </div>`,
        )
        .join('')
    : '<p class="muted">数据太少，还没形成簇。</p>';

  const ups = d.ups.length
    ? `<table class="table"><thead><tr><th>UP 主</th><th class="num">看过</th><th class="num">亲和度</th></tr></thead><tbody>${d.ups
        .map((u) => `<tr><td>${esc(u.name)}</td><td class="num">${u.count}</td><td class="num">${pct(u.affinity)}</td></tr>`)
        .join('')}</tbody></table>
        <p class="muted small">亲和度 = 这位 UP 的作品与你整体兴趣的接近程度。看过次数少但亲和度高，说明你其实很吃这一口。</p>`
    : '<p class="muted">还没有足够数据。</p>';

  return `<section class="hero"><h1>整理</h1><p>只给建议，不动你的数据。</p></section>
  <div class="grid-2">
    <section class="panel"><h2>重复收藏 <span class="pill">${h.duplicates.length}</span></h2>${dup}</section>
    <section class="panel"><h2>只看了就收 <span class="pill">${h.oneShotCount}</span></h2>${oneShot}</section>
  </div>
  <section class="panel"><h2>离你主线最远的长尾 <span class="pill">${h.tailCount}</span></h2>${tail}</section>
  <section class="panel"><h2>兴趣簇</h2><p class="muted small">聚类结果就是名片标签的来源 —— 它决定别人在名片里看到你的哪几个关键词。</p>${clustersHtml}</section>
  <section class="panel"><h2>值得多看几眼的 UP 主</h2>${ups}</section>`;
}

// ---------------------------------------------------------------- 名片

export function cardsView(state) {
  const p = state.profile;
  const my = state.myCard;
  const ready = p && p.itemCount > 0;

  const builder = ready
    ? `<section class="panel">
        <h2>生成我的名片</h2>
        <div class="form">
          <label>昵称（可空）<input type="text" data-field="nickname" maxlength="32" value="${esc(state.settings.nickname || '')}" placeholder="比如：装机党"></label>
          <label>亮点标签（可空，最多 8 个，逗号分隔）
            <input type="text" data-field="highlight" maxlength="120" value="${esc((state.settings.highlightTags || []).join(','))}" placeholder="${esc((p.topTags || []).slice(0, 3).map((t) => t.name).join(','))}">
          </label>
          <div class="actions"><button class="btn primary" data-action="generate-card">生成 / 刷新</button></div>
        </div>
      </section>`
    : `<section class="panel"><h2>生成我的名片</h2><p class="muted">先采集一些数据才能生成名片。</p></section>`;

  const preview = my
    ? `<section class="panel">
        <h2>名片预览</h2>
        <p class="muted small">下面就是这张名片里<b>全部</b>的内容，没有别的字段。确认无误再导出。</p>
        <table class="table">
          <tbody>
            <tr><td>昵称</td><td>${esc(my.n || '（空）')}</td></tr>
            <tr><td>分区分布</td><td>${esc(Object.entries(my.p).map(([k, v]) => `${k}(${v})`).join('，') || '（空）')}</td></tr>
            <tr><td>标签分布</td><td>${esc(Object.entries(my.g).map(([k, v]) => `${k}(${v})`).join('，') || '（空）')}</td></tr>
            <tr><td>亮点标签</td><td>${esc((my.hl || []).join('，') || '（空）')}</td></tr>
            <tr><td>收藏量级</td><td>${esc(my.c)}</td></tr>
            <tr><td>信号质量</td><td>${esc(my.q)}%（决定这张卡能不能参与比较）</td></tr>
          </tbody>
        </table>
        <p class="muted small">不含：作品 ID、观看时间、UP 主列表、任何账号或主页信息、任何指纹。</p>
        <label>复制发给朋友<textarea class="mono" readonly rows="4" data-role="card-text">${esc(state.myCardText || '')}</textarea></label>
        <div class="actions">
          <button class="btn primary" data-action="copy-card">复制名片</button>
          <button class="btn" data-action="download-card">保存为文本</button>
        </div>
      </section>`
    : '';

  const receive = `<section class="panel">
    <h2>导入对方的名片</h2>
    <p class="muted small">把对方发来的 <code>MS1.</code> 开头的一段文本粘进来，或选择 .txt 文件。解析与比对全部在本机完成。</p>
    <textarea class="mono" rows="3" data-role="import-text" placeholder="MS1....（可一次粘贴多张，每行一张）"></textarea>
    <div class="actions">
      <button class="btn primary" data-action="import-card">导入并比对</button>
      <label class="btn file">选择文件<input type="file" data-action="import-card-file" accept=".txt,.json,text/plain" hidden></label>
    </div>
  </section>`;

  const list = `<section class="panel">
    <h2>名片夹 <span class="pill">${state.cards.length}</span></h2>
    ${renderCardList(state)}
  </section>`;

  return `<section class="hero"><h1>名片</h1><p>相似度在你自己的浏览器里算完，谁的机器都没上传过。</p></section>
    ${builder}${preview}${receive}${list}`;
}

function renderCardList(state) {
  const { cards, rankedCards } = state;
  if (!cards.length) return '<p class="muted">还没有导入任何名片。把朋友的名片贴进来试试。</p>';
  if (!state.myCard) return `<p class="muted">已导入 ${cards.length} 张名片，但你需要先生成自己的名片才能比对。</p>`;

  const blocked = rankedCards.filter((r) => r.usable === false).length;

  return (
    (blocked
      ? `<p class="muted small warn">有 ${blocked} 张名片的数据太薄（分区/标签覆盖率低于门槛），已标为"数据不足"，不参与排序。</p>`
      : '') +
    rankedCards
      .map((r) => {
        const usable = r.usable !== false;
        const b = usable ? r.band || band(r.score) : { level: 'low', label: '数据不足' };
        const shared = r.explanation.sharedTags.map((t) => `#${esc(t.name)}`).join(' ');
        const cats = r.explanation.sharedPartitions.map((t) => esc(t.name)).join(' · ');
        return `<div class="card-row">
        <div class="card-main">
          <div class="card-title">
            <b>${esc(r.nickname || r.card.n || '匿名名片')}</b>
            <span class="level ${b.level}">${esc(b.label)}</span>
          </div>
          <div class="muted small">${esc(describeCard(r.card))}</div>
          <div class="muted small">共同分区：${cats || '无'} ${shared ? '｜共同标签：' + shared : ''}</div>
          ${usable ? '' : `<div class="muted small warn">${esc(r.unusableReason || '')}</div>`}
        </div>
        <div class="card-score">${usable ? pct(r.score) : '—'}</div>
        <button class="btn tiny" data-action="delete-card" data-id="${esc(r.cardId)}">删除</button>
      </div>`;
      })
      .join('')
  );
}

// ---------------------------------------------------------------- 匹配池

export function poolView(state) {
  const pool = (state.settings && state.settings.pool) || {};
  const joined = Boolean(pool.token);
  const candidates = state.poolCandidates || [];
  const inbox = state.poolInbox || { items: [], sent: [] };

  const config = `<section class="panel">
    <h2>服务器</h2>
    <p class="muted small">匹配池需要一台你自己（或朋友）部署的服务端。留空则完全不会联网。</p>
    <div class="form">
      <label>服务端地址<input type="text" data-field="pool-server" placeholder="如 your-app.vercel.app，记得带 https 前缀" value="${esc(pool.server || '')}"></label>
      <label>愿意公开的联系方式（只在你和对方都点「想认识」后才交换）<input type="text" data-field="pool-contact" maxlength="120" placeholder="比如你的 B 站主页链接或昵称" value="${esc(pool.contact || '')}"></label>
      <div class="actions">
        <button class="btn primary" data-action="pool-join">${joined ? '重新入池' : '加入匹配池'}</button>
        <button class="btn danger" data-action="pool-leave" ${joined ? '' : 'disabled'}>退出并删除</button>
      </div>
    </div>
    ${
      joined
        ? `<p class="muted small">已入池 · token <code class="mono">${esc(String(pool.token).slice(0, 10))}…</code> · 服务器 <code class="mono">${esc(pool.server)}</code></p>`
        : '<p class="muted small">还没入池。入池只上传一张你预览过的兴趣名片和一个公钥。</p>'
    }
  </section>`;

  const candidateRows = candidates.length
    ? candidates
        .map(
          (c) => `<div class="card-row">
            <div class="card-main">
              <div class="card-title">
                <b>匿名同频者 ${esc(String(c.token).slice(0, 6))}</b>
                <span class="level ${c.band.level}">${esc(c.band.label)}</span>
              </div>
              <div class="muted small">共同分区 ${c.shared.partitions} 个 · 共同标签 ${c.shared.tags} 个</div>
              <div class="muted small">服务器只回了对方的公钥；名片内容要等双方都同意后才交换</div>
            </div>
            <div class="card-score">${pct(c.score)}</div>
            <button class="btn tiny" data-action="pool-interest" data-to="${esc(c.token)}" data-pub="${esc(c.pubkey)}">想认识</button>
          </div>`,
        )
        .join('')
    : `<p class="muted">${joined ? '服务器没匹配到人。池子还太小（低于 k-匿名下限 5 人），或者你还没点「刷新」。' : '先入池。'}</p>`;

  const inboxRows = (inbox.items || []).length
    ? inbox.items
        .map(
          (it) => `<div class="card-row">
            <div class="card-main">
              <div class="card-title"><b>${esc(it.nickname || '匿名')}</b>
                <span class="level ${it.mutual ? 'high' : 'low'}">${it.mutual ? '互相想认识' : '对方想认识你'}</span>
              </div>
              ${it.contact ? `<div class="muted small">对方留下的联系方式：<b>${esc(it.contact.contact || '（空）')}</b></div>` : '<div class="muted small">你还没回应，所以看不到对方留下的联系方式。</div>'}
            </div>
            <button class="btn tiny" data-action="pool-block" data-to="${esc(it.from)}">屏蔽</button>
          </div>`,
        )
        .join('')
    : '<p class="muted">没有收到请求。</p>';

  return `<section class="hero"><h1>匹配池</h1><p>主动入池的人才可能被找到；联系卡用对方公钥加密，服务器读不懂。</p></section>
    ${config}
    <section class="panel">
      <h2>候选</h2>
      <p class="muted small">服务器按你的名片在池子里排序，只回几个公钥和分档 —— 它不会把别人的名片发给你。点「想认识」后，双方都同意才会交换彼此的联系方式。</p>
      <div class="actions"><button class="btn" data-action="pool-refresh" ${joined ? '' : 'disabled'}>刷新候选与收件箱</button></div>
      <div class="cluster-list" style="margin-top:12px">${candidateRows}</div>
    </section>
    <section class="panel">
      <h2>收件箱</h2>
      <p class="muted small">双方都点过「想认识」后，才会把对方加密的联系方式解给你看。</p>
      <div class="cluster-list">${inboxRows}</div>
    </section>
    <section class="banner">
      <b>为什么服务器读不懂</b>
      <span>联系卡用「我的私钥 + 对方公钥」加密。同一个共享密钥对方也能算出来，但服务器两头都没有。</span>
    </section>`;
}

// ---------------------------------------------------------------- 隐私

export function privacyView(state) {
  return `<section class="hero"><h1>隐私</h1><p>这个页面可以把你从零开始还原。</p></section>
  <section class="panel">
    <h2>本机存了什么</h2>
    <table class="table">
      <thead><tr><th>数据</th><th>内容</th><th class="num">条数</th></tr></thead>
      <tbody>
        <tr><td>items</td><td>你看过的作品的标题、分区、标签、UP 主名</td><td class="num">${state.counts.items || 0}</td></tr>
        <tr><td>interactions</td><td>你对这些作品的收藏 / 点赞 / 历史行为</td><td class="num">${state.counts.interactions || 0}</td></tr>
        <tr><td>cards</td><td>你导入的他人名片</td><td class="num">${state.counts.cards || 0}</td></tr>
      </tbody>
    </table>
    <p class="muted small">全部存在本机 IndexedDB 里，键名 <code>mirror-db</code>。没有云端、没有账号、没有同步。</p>
  </section>
  <section class="panel">
    <h2>没有存什么</h2>
    <ul class="list plain">
      <li>任何他人的点赞 / 收藏 / 关注名单</li>
      <li>任何 Cookie、登录凭证、设备指纹</li>
      <li>任何真实姓名、住址、电话、工作单位</li>
    </ul>
  </section>
  <section class="panel">
    <h2>数据操作</h2>
    <div class="actions">
      <button class="btn" data-action="export-backup">导出备份</button>
      <label class="btn file">导入备份<input type="file" data-action="import-backup" accept=".json" hidden></label>
      <button class="btn danger" data-action="clear-data">清空全部数据</button>
      <button class="btn danger" data-action="drop-db">删除数据库</button>
    </div>
    <p class="muted small">清空 = 保留数据库结构但删除全部记录；删除数据库 = 连库一起删掉，下次打开重新创建。</p>
  </section>
  ${complianceBanner()}
  <section class="panel">
    <h2>合规自检清单</h2>
    <ul class="list plain checks">
      <li class="ok">不发起任何网络请求（源码中不存在 fetch 调用）</li>
      <li class="ok">不读取他人主页、不抓取点赞/收藏名单</li>
      <li class="ok">不破解任何签名 / 不处理验证码 / 不使用代理</li>
      <li class="ok">不把匿名行为还原成具体账号（不做重识别）</li>
      <li class="ok">名片内容由你亲手预览后才会离开本机</li>
      <li class="ok">可随时暂停采集、清空数据、删除数据库</li>
    </ul>
  </section>`;
}

function complianceBanner() {
  return `<section class="banner">
    <b>默认零联网</b>
    <span>扩展默认不发起任何网络请求。只有你在「匹配池」里填入自己的服务器地址并点"入池"之后，
    才会与那台服务器通信 —— 发出去的只有你预览过的兴趣名片、公钥和加密后的联系卡。
    源码中联网能力只允许出现在 <code>src/pool/client.js</code>，合规自检会强制这一点。</span>
  </section>`;
}
