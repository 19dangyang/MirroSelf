/**
 * 后台 service worker：解析入库 + 负责诊断。
 *
 * 安全边界（三重）：
 *   1. 只接受来自白名单标签页（www / space）的消息；
 *   2. 只接受四类白名单路径的响应；
 *   3. 单条消息有体积上限。
 *
 * 任何一条不满足都会丢弃，但**不再静默**：最近的丢弃样本会留在
 * ingestDrops 里，仪表盘"读写自检"可以直接展示给用户看。
 */

import { parsePayload, SOURCE } from '../content/parsers.js';
import { putItems, putInteractions, setMeta, getMeta, countAll } from '../storage/db.js';
import { LIMITS } from '../core/constants.js';
import { ALLOWED_ORIGINS, originOf } from '../core/origins.js';

const MAX_DROP_SAMPLES = 12;

let stats = null;
let drops = null;

async function getStats() {
  if (!stats) {
    stats = (await getMeta('ingestStats', null)) || {
      received: 0,
      accepted: 0,
      droppedByOrigin: 0,
      droppedBySize: 0,
      droppedByParse: 0,
      droppedByEmpty: 0,
      skippedProgress: 0,
      skippedIgnored: 0,
      bySource: {},
      lastAt: 0,
      lastAcceptedAt: 0,
    };
  }
  return stats;
}

async function getDrops() {
  if (!drops) drops = (await getMeta('ingestDrops', null)) || [];
  return drops;
}

async function recordDrop(reason, detail) {
  const list = await getDrops();
  list.unshift({ at: Date.now(), reason, ...detail });
  drops = list.slice(0, MAX_DROP_SAMPLES);
  await setMeta('ingestDrops', drops);
}

function bump(source, key = 'accepted') {
  if (!stats) return;
  stats[key] = (stats[key] || 0) + 1;
  if (source) stats.bySource[source] = (stats.bySource[source] || 0) + 1;
}

async function persistStats() {
  if (stats) await setMeta('ingestStats', stats);
}

async function handlePayload(msg, sender) {
  const s = await getStats();
  s.received += 1;

  const tabUrl = sender?.tab?.url || sender?.url || '';
  const origin = originOf(tabUrl);
  if (!ALLOWED_ORIGINS.includes(origin)) {
    bump(null, 'droppedByOrigin');
    await persistStats();
    await recordDrop('origin', { tabUrl: tabUrl.slice(0, 160), url: String(msg.url || '').slice(0, 160) });
    return { ok: false, reason: 'origin', tabUrl };
  }

  if (typeof msg.body !== 'string' || msg.body.length > LIMITS.maxBodyBytes) {
    bump(null, 'droppedBySize');
    await persistStats();
    await recordDrop('size', { url: String(msg.url || '').slice(0, 160), size: String(msg.body || '').length });
    return { ok: false, reason: 'size' };
  }

  const parsed = parsePayload(msg.url, msg.body);
  if (!parsed.source || parsed.error) {
    bump(null, 'droppedByParse');
    await persistStats();
    await recordDrop('parse', { url: String(msg.url || '').slice(0, 160), error: parsed.error || 'unsupported', diag: parsed.diag || null });
    return { ok: false, reason: parsed.error || 'unsupported' };
  }

  if (parsed.items.length === 0 && parsed.interactions.length === 0) {
    // 收藏夹的空响应是**正常**的：`media_id=0` 的"全部收藏"视图、空文件夹都会返回 0 条。
    // 以前一律记成"空结果"，害得用户以为收藏夹坏了。
    if (parsed.source === SOURCE.FAV) {
      await persistStats();
      return { ok: true, accepted: 0 };
    }

    // 这条以前是静默放行的 —— 结果就是"收到 13 条、接受 0 条、没有任何错误",
    // 用户完全无从判断。现在它有自己的计数器与样本。
    bump(null, 'droppedByEmpty');
    s.skippedProgress = (s.skippedProgress || 0) + (parsed.skippedProgress || 0);
    s.skippedIgnored = (s.skippedIgnored || 0) + (parsed.ignored || 0);
    await persistStats();
    await recordDrop('empty', {
      url: String(msg.url || '').slice(0, 160),
      source: parsed.source,
      ignored: parsed.ignored,
      skippedProgress: parsed.skippedProgress || 0,
    });
    return { ok: true, accepted: 0, reason: 'empty', skippedProgress: parsed.skippedProgress || 0 };
  }

  await putItems(parsed.items);
  await putInteractions(parsed.interactions);

  bump(parsed.source, 'accepted');
  s.lastAt = Date.now();
  s.lastAcceptedAt = s.lastAt;
  s.skippedProgress = (s.skippedProgress || 0) + (parsed.skippedProgress || 0);
  s.skippedIgnored = (s.skippedIgnored || 0) + (parsed.ignored || 0);
  await persistStats();
  await setMeta('lastIngest', {
    at: s.lastAt,
    source: parsed.source,
    items: parsed.items.length,
    interactions: parsed.interactions.length,
    ignored: parsed.ignored,
    skippedProgress: parsed.skippedProgress || 0,
  });

  return {
    ok: true,
    accepted: parsed.items.length,
    source: parsed.source,
    skippedProgress: parsed.skippedProgress || 0,
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg !== 'object') return false;

  if (msg.type === 'mirror:payload') {
    handlePayload(msg, sender)
      .then((r) => sendResponse(r))
      .catch((err) => sendResponse({ ok: false, reason: 'error', error: String((err && err.message) || err) }));
    return true;
  }

  if (msg.type === 'mirror:counts') {
    countAll()
      .then(async (counts) => {
        const s = await getStats();
        sendResponse({ ok: true, counts, stats: s });
      })
      .catch((err) => sendResponse({ ok: false, error: String((err && err.message) || err) }));
    return true;
  }

  if (msg.type === 'mirror:diag') {
    (async () => {
      const [counts, s, d, lastIngest, installedAt] = await Promise.all([
        countAll(),
        getStats(),
        getDrops(),
        getMeta('lastIngest', null),
        getMeta('installedAt', null),
      ]);
      sendResponse({ ok: true, counts, stats: s, drops: d, lastIngest, installedAt, allowedOrigins: [...ALLOWED_ORIGINS] });
    })().catch((err) => sendResponse({ ok: false, error: String((err && err.message) || err) }));
    return true;
  }

  if (msg.type === 'mirror:clear-drops') {
    (async () => {
      drops = [];
      await setMeta('ingestDrops', []);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (msg.type === 'mirror:ping') {
    sendResponse({ ok: true, at: Date.now() });
    return false;
  }

  return false;
});

chrome.runtime.onInstalled.addListener((details) => {
  setMeta('installedAt', Date.now()).catch(() => {});
  if (details.reason === 'install') {
    try {
      const p = chrome.tabs.create({ url: chrome.runtime.getURL('src/dashboard/index.html?welcome=1') });
      if (p && typeof p.catch === 'function') p.catch(() => {});
    } catch {
      /* 某些环境下 tabs.create 不可用，忽略 */
    }
  }
});
