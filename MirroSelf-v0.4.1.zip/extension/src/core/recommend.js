/**
 * 本地推荐与整理：全部只用"你自己的数据"，不依赖任何外部信息。
 *
 * 三件事：
 *   1. clusters     —— 把你的收藏自动聚成若干"兴趣簇"（这是名片标签的来源）
 *   2. hygiene      —— 收藏夹体检：重复、只看了就收、离主线最远的长尾
 *   3. recommendUps —— 与你的核心兴趣高度重合、但你还没重视的 UP 主
 *
 * 所有算法都是确定性的（同输入同输出），便于单测和"结果可复现"。
 */

import { ACTION_WEIGHT } from './constants.js';
import { cosine, l1Normalize, size } from './vector.js';

/** 单条作品的向量：分区 1.2、标签 1.0、UP 0.8 权重拼在同一空间里。 */
export function itemVector(item) {
  const v = {};
  if (!item) return v;
  if (item.category) v['c:' + item.category] = 1.2;
  for (const t of Array.isArray(item.tags) ? item.tags : []) {
    if (t) v['t:' + t] = (v['t:' + t] || 0) + 1;
  }
  if (item.upId !== undefined && item.upId !== null && item.upId !== '') {
    v['u:' + String(item.upId)] = 0.8;
  }
  return v;
}

function dedupeInteractions(interactions) {
  const best = new Map();
  for (const rec of interactions || []) {
    if (!rec || !rec.itemId) continue;
    // 权重可能没显式写入（采集器只记 action），此时按 ACTION_WEIGHT 兜底。
    const w = Number(rec.weight ?? ACTION_WEIGHT[rec.action] ?? 0);
    if (!(w > 0)) continue;
    const cur = best.get(rec.itemId);
    if (!cur || w > cur.weight) best.set(rec.itemId, { itemId: rec.itemId, weight: w, action: rec.action });
  }
  return best;
}

/** 加权质心：整个收藏夹在统一空间里的"中心"。 */
export function centroid(items, interactions) {
  const byId = new Map((items || []).map((i) => [i.itemId, i]));
  const best = dedupeInteractions(interactions);
  const acc = {};
  for (const rec of best.values()) {
    const item = byId.get(rec.itemId);
    if (!item) continue;
    const vec = itemVector(item);
    for (const k in vec) acc[k] = (acc[k] || 0) + vec[k] * rec.weight;
  }
  return l1Normalize(acc);
}

/**
 * 兴趣簇聚类：贪心选种子 + 最近质心分配。
 * 顶替 KMeans 的理由：样本几千条、维度上千，KMeans 要反复全量扫描；
 * 贪心版本一次扫描就能给出稳定结果，且"无法归类"的条目会被老实标出来。
 */
export function clusters({ items = [], interactions = [] }, opts = {}) {
  const { k = 5, minSize = 2, seedThreshold = 0.45, assignThreshold = 0.12 } = opts;

  const byId = new Map(items.map((i) => [i.itemId, i]));
  const best = dedupeInteractions(interactions);
  const rows = [];
  for (const rec of best.values()) {
    const item = byId.get(rec.itemId);
    if (!item) continue;
    const vec = itemVector(item);
    if (size(vec) === 0) continue;
    rows.push({ item, weight: rec.weight, vec });
  }
  if (rows.length === 0) {
    return { clusters: [], unassigned: [], total: 0 };
  }

  rows.sort((a, b) => b.weight - a.weight || String(a.item.itemId).localeCompare(String(b.item.itemId)));

  const seeds = [];
  for (const row of rows) {
    if (seeds.length >= k) break;
    const maxSim = seeds.reduce((m, s) => Math.max(m, cosine(row.vec, s.vec)), 0);
    if (seeds.length === 0 || maxSim < seedThreshold) seeds.push(row);
  }

  const buckets = seeds.map((seed, idx) => ({
    idx,
    seed: seed.item,
    rows: [],
    tagWeight: {},
    catWeight: {},
    upWeight: {},
  }));
  const unassigned = [];

  for (const row of rows) {
    let bestIdx = -1;
    let bestSim = assignThreshold;
    for (let i = 0; i < seeds.length; i += 1) {
      const sim = cosine(row.vec, seeds[i].vec);
      if (sim >= bestSim) {
        bestSim = sim;
        bestIdx = i;
      }
    }
    if (bestIdx < 0) {
      unassigned.push(row.item);
      continue;
    }
    const bucket = buckets[bestIdx];
    bucket.rows.push(row);
    for (const t of row.item.tags || []) bucket.tagWeight[t] = (bucket.tagWeight[t] || 0) + row.weight;
    if (row.item.category) bucket.catWeight[row.item.category] = (bucket.catWeight[row.item.category] || 0) + row.weight;
    if (row.item.upName) bucket.upWeight[row.item.upName] = (bucket.upWeight[row.item.upName] || 0) + row.weight;
  }

  const out = buckets
    .filter((b) => b.rows.length >= minSize)
    .map((b) => {
      const tags = topOf(b.tagWeight, 4);
      const cats = topOf(b.catWeight, 2);
      const ups = topOf(b.upWeight, 1);
      // 没有分区也标签很常见（历史接口不返回），此时用 UP 主当标签，
      // 总比一排"未命名簇"有用。
      const label = tags.length >= 2 ? tags.slice(0, 2).join(' · ') : cats[0] || ups[0] || tags[0] || '未命名簇';
      return {
        id: 'c' + b.idx,
        label,
        size: b.rows.length,
        tags,
        categories: cats,
        ups,
        sample: b.rows
          .slice()
          .sort((x, y) => y.weight - x.weight || String(x.item.itemId).localeCompare(String(y.item.itemId)))
          .slice(0, 6)
          .map((r) => ({ itemId: r.item.itemId, title: r.item.title || '', upName: r.item.upName || '' })),
      };
    })
    .sort((x, y) => y.size - x.size || x.label.localeCompare(y.label));

  return { clusters: out, unassigned: unassigned.slice(0, 12), total: rows.length };
}

function topOf(map, n) {
  return Object.entries(map)
    .sort((a, b) => b[1] - a[1] || (a[0] < b[0] ? -1 : 1))
    .slice(0, n)
    .map(([k]) => k);
}

/** 标题归一化：去空白与标点，用于发现"同一个视频收了两次"。 */
export function normalizeTitle(title) {
  return String(title || '')
    .replace(/\s+/g, '')
    .replace(/[【】\[\]（）()「」《》<>·,，.。!！?？:：;；'"“”‘’\-—_/\\|]/g, '')
    .toLowerCase();
}

/**
 * 收藏夹体检。
 * 返回的都是"你可以自己决定怎么处理"的建议，不做任何自动修改。
 */
export function hygiene({ items = [], interactions = [] }, opts = {}) {
  const { tailRatio = 0.08 } = opts;
  const byId = new Map(items.map((i) => [i.itemId, i]));
  const best = dedupeInteractions(interactions);

  const actionsByItem = new Map();
  for (const rec of interactions || []) {
    if (!rec || !rec.itemId) continue;
    if (!actionsByItem.has(rec.itemId)) actionsByItem.set(rec.itemId, new Set());
    actionsByItem.get(rec.itemId).add(rec.action);
  }

  const titleGroups = new Map();
  for (const item of items) {
    const key = normalizeTitle(item.title);
    if (!key) continue;
    if (!titleGroups.has(key)) titleGroups.set(key, []);
    titleGroups.get(key).push(item);
  }
  const duplicates = [...titleGroups.values()]
    .filter((g) => g.length > 1)
    .map((g) => ({
      title: g[0].title,
      items: g.map((i) => ({ itemId: i.itemId, upName: i.upName || '' })),
    }))
    .slice(0, 20);

  const oneShot = [];
  for (const item of items) {
    const acts = actionsByItem.get(item.itemId);
    if (!acts || !acts.has('fav')) continue;
    if (acts.has('like') || acts.has('coin')) continue;
    const histCount = (interactions || []).filter((r) => r.itemId === item.itemId && r.action === 'history').length;
    if (histCount <= 1) oneShot.push({ itemId: item.itemId, title: item.title || '', upName: item.upName || '' });
  }

  const center = centroid(items, interactions);
  const tail = [];
  for (const rec of best.values()) {
    const item = byId.get(rec.itemId);
    if (!item) continue;
    const sim = cosine(itemVector(item), center);
    if (sim > 0 && sim < tailRatio) tail.push({ itemId: item.itemId, title: item.title || '', sim });
  }
  tail.sort((a, b) => a.sim - b.sim);

  return {
    duplicates,
    oneShot: oneShot.slice(0, 20),
    oneShotCount: oneShot.length,
    tail: tail.slice(0, 20),
    tailCount: tail.length,
    totalItems: items.length,
  };
}

/**
 * 与你核心兴趣高度重合、但你还没有大量消费的 UP 主。
 * 这是纯本地、纯自己数据能给出的"发现"，也是最像"被推荐"的一次。
 */
export function recommendUps({ items = [], interactions = [] }, opts = {}) {
  const { limit = 8, minItems = 2 } = opts;
  const center = centroid(items, interactions);
  if (size(center) === 0) return [];

  const byId = new Map(items.map((i) => [i.itemId, i]));
  const best = dedupeInteractions(interactions);
  const stats = new Map();

  for (const rec of best.values()) {
    const item = byId.get(rec.itemId);
    if (!item || item.upId === undefined || item.upId === null) continue;
    const key = String(item.upId);
    const sim = cosine(itemVector(item), center);
    const cur = stats.get(key) || { upId: key, name: item.upName || key, count: 0, simSum: 0, weightSum: 0 };
    cur.count += 1;
    cur.simSum += sim;
    cur.weightSum += rec.weight;
    if (!cur.name || cur.name === key) cur.name = item.upName || key;
    stats.set(key, cur);
  }

  const rows = [...stats.values()]
    .filter((s) => s.count >= minItems)
    .map((s) => ({
      upId: s.upId,
      name: s.name,
      count: s.count,
      weight: s.weightSum,
      affinity: s.simSum / s.count,
      /** 亲和度高、但你消费得少 → 值得回头看 */
      score: (s.simSum / s.count) * Math.log2(1 + s.count) / (1 + Math.log2(1 + s.weightSum)),
    }))
    .filter((s) => Number.isFinite(s.score) && s.score > 0)
    .sort((a, b) => b.score - a.score || b.affinity - a.affinity || a.upId.localeCompare(b.upId));

  return rows.slice(0, limit);
}
