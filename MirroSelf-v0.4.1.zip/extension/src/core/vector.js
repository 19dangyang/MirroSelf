/**
 * 稀疏向量工具。
 *
 * 全项目所有向量都是 `Record<string, number>` 形式（分区名 → 权重、
 * 标签 → TF-IDF 等）。稀疏表示让一万条记录也只占几百 KB。
 */

import { laplace } from './random.js';

export function emptyVec() {
  return {};
}

export function addTo(vec, key, value) {
  if (!key || !Number.isFinite(value) || value === 0) return vec;
  vec[key] = (vec[key] || 0) + value;
  return vec;
}

export function l1Normalize(vec) {
  let sum = 0;
  for (const k in vec) sum += Math.abs(vec[k]);
  const out = {};
  if (!(sum > 0)) return out;
  for (const k in vec) {
    const v = vec[k] / sum;
    if (v !== 0) out[k] = v;
  }
  return out;
}

export function dot(a, b) {
  let s = 0;
  const small = Object.keys(a).length <= Object.keys(b).length ? a : b;
  const big = small === a ? b : a;
  for (const k in small) {
    if (Object.hasOwn(big, k)) s += small[k] * big[k];
  }
  return s;
}

export function norm(a) {
  let s = 0;
  for (const k in a) s += a[k] * a[k];
  return Math.sqrt(s);
}

export function cosine(a, b) {
  if (!a || !b) return 0;
  const na = norm(a);
  const nb = norm(b);
  if (!(na > 0) || !(nb > 0)) return 0;
  return dot(a, b) / (na * nb);
}

export function size(vec) {
  return vec ? Object.keys(vec).length : 0;
}

/** 取权重最高的 k 项，权重相同时按 key 字典序，保证输出稳定。 */
export function topEntries(vec, k = 10) {
  return Object.entries(vec || {})
    .filter(([, v]) => Number.isFinite(v) && v > 0)
    .sort((x, y) => (y[1] - x[1]) || (x[0] < y[0] ? -1 : x[0] > y[0] ? 1 : 0))
    .slice(0, k);
}

export function toObject(entries) {
  const out = {};
  for (const [k, v] of entries || []) out[k] = v;
  return out;
}

/**
 * 量化：把 [0,max] 的浮点权重压到 0..levels 的整数。
 * 量化本身就是一种粗化（降低指纹精度），noiseScale 再加一点抖动。
 */
export function quantize(vec, { levels = 15, max = 0, noiseScale = 0, rng = Math.random } = {}) {
  const entries = Object.entries(vec || {}).filter(([, v]) => v > 0);
  if (entries.length === 0) return {};
  const peak = max > 0 ? max : Math.max(...entries.map(([, v]) => v));
  if (!(peak > 0)) return {};
  const out = {};
  for (const [k, v] of entries) {
    const scaled = (v / peak) * levels;
    const jittered = scaled + (noiseScale > 0 ? laplace(noiseScale, rng) : 0);
    const q = Math.max(0, Math.min(levels, Math.round(jittered)));
    if (q > 0) out[k] = q;
  }
  return out;
}

/** 赫芬达尔指数：sum(p^2)，衡量兴趣集中度。0.3 以上算"非常聚焦"。 */
export function herfindahl(vec) {
  const p = l1Normalize(vec);
  let s = 0;
  for (const k in p) s += p[k] * p[k];
  return s;
}

/** 两个集合的 Jaccard（用于"共同收藏"这类解释性指标，不用于打分）。 */
export function jaccard(a, b) {
  const setA = a instanceof Set ? a : new Set(a || []);
  const setB = b instanceof Set ? b : new Set(b || []);
  if (setA.size === 0 && setB.size === 0) return 0;
  let inter = 0;
  for (const v of setA) if (setB.has(v)) inter += 1;
  return inter / (setA.size + setB.size - inter);
}
