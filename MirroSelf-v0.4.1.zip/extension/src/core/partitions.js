/**
 * 分区（类目）名称的唯一来源。
 *
 * 设计取舍：**不硬编码完整分区表**。B 站二级分区 id 有上千个且会调整，
 * 手写一张表只会制造"看起来权威其实是错的"数据。
 *
 * 因此：
 *  - 优先使用接口自带的 `tname`（页面返回什么就是什么）；
 *  - 只在 `tname` 缺失时，用下面这张"一级分区"表做兜底；
 *  - 再缺失才退化成 `分区#<tid>`。
 */

/** 一级分区 tid → 名称（仅收录确定项，用于兜底）。 */
export const L1_NAMES = Object.freeze({
  1: '动画',
  3: '音乐',
  4: '游戏',
  5: '娱乐',
  11: '电视剧',
  13: '番剧',
  23: '电影',
  36: '知识',
  119: '鬼畜',
  129: '舞蹈',
  138: '搞笑',
  155: '时尚',
  160: '生活',
  167: '国创',
  177: '纪录片',
  181: '影视',
  188: '科技',
  202: '资讯',
  211: '美食',
  217: '动物圈',
  223: '汽车',
  234: '运动',
  251: '三农',
  254: '军事',
});

/**
 * 得到一条记录的分区标签。
 * @param {{tname?: string, tid?: number, tagName?: string}} input
 * @returns {{label: string|null, confidence: number}}
 */
export function resolveCategory(input) {
  const tname = clean(input?.tname);
  if (tname) return { label: tname, confidence: 1 };
  const tagName = clean(input?.tagName);
  if (tagName) return { label: tagName, confidence: 0.6 };
  const tid = Number(input?.tid);
  if (Number.isFinite(tid) && tid > 0) {
    const l1 = L1_NAMES[tid];
    return { label: l1 ? `${l1}（一级）` : `分区#${tid}`, confidence: 0.4 };
  }
  return { label: null, confidence: 0 };
}

function clean(v) {
  if (typeof v !== 'string') return '';
  const s = v.trim().replace(/\s+/g, ' ');
  if (!s) return '';
  if (s === '全部分区' || s === '全部' || s === '其他') return '';
  return s.slice(0, 40);
}

export function listL1() {
  return Object.entries(L1_NAMES).map(([tid, name]) => ({ tid: Number(tid), name }));
}
