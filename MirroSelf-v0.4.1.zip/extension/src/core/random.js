/**
 * 可复现的伪随机数：测试与"加噪后仍可复现"都依赖它。
 */

/** mulberry32：32 位种子，返回 [0,1) 的确定性序列。 */
export function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * 密码学随机种子。
 *
 * 曾经用 Date.now() 当种子 —— 名片里的 ts 精确到秒，攻击者枚举那一秒内的
 * 1000 个毫秒就能复现同一串噪声、还原未加噪的原始分布。必须用真随机。
 */
export function randomSeed() {
  try {
    const b = new Uint32Array(1);
    globalThis.crypto.getRandomValues(b);
    return b[0] >>> 0;
  } catch {
    return (Math.random() * 0xffffffff) >>> 0;
  }
}

export function seedFromString(str) {  let h = 2166136261;
  for (let i = 0; i < str.length; i += 1) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h >>> 0;
}

/** 拉普拉斯噪声（对称）。量化前加一点点，避免分数出现可复现的指纹。 */
export function laplace(scale, rng = Math.random) {
  if (!(scale > 0)) return 0;
  const u = rng() - 0.5;
  if (u === 0) return 0;
  const sign = u < 0 ? -1 : 1;
  return -scale * sign * Math.log(1 - 2 * Math.abs(u));
}

/** 从数组中按种子做确定性洗牌（不改原数组）。 */
export function shuffle(array, rng = Math.random) {
  const out = array.slice();
  for (let i = out.length - 1; i > 0; i -= 1) {
    const j = Math.floor(rng() * (i + 1));
    const tmp = out[i];
    out[i] = out[j];
    out[j] = tmp;
  }
  return out;
}
