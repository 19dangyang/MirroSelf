/**
 * 作品记录的规范化与合并（纯函数，可单测）。
 *
 * 合并的难点在"分区"：同一个作品可能先由历史记录带来一个粗粒度分类
 * （置信度 0.6），之后又被视频详情页带来精确分区（1.0）。后到的粗粒度值
 * 绝不能覆盖已有的精确值 —— 否则画像会把"科技"和"猜的"混为一谈。
 */

import { LIMITS } from './constants.js';

export function normalizeItem(input) {
  if (!input || typeof input.itemId !== 'string' || !input.itemId) return null;
  return {
    itemId: input.itemId,
    platform: input.platform || 'bilibili',
    title: typeof input.title === 'string' ? input.title.slice(0, LIMITS.titleMax) : '',
    category: typeof input.category === 'string' && input.category ? input.category : null,
    categoryConfidence: Number.isFinite(Number(input.categoryConfidence)) ? Number(input.categoryConfidence) : 0,
    categoryId: Number.isFinite(Number(input.categoryId)) ? Number(input.categoryId) : null,
    tags: Array.isArray(input.tags)
      ? [...new Set(input.tags.filter((t) => typeof t === 'string' && t))].slice(0, LIMITS.tagsPerItem)
      : [],
    upId: input.upId ?? null,
    upName: typeof input.upName === 'string' ? input.upName.slice(0, LIMITS.upNameMax) : '',
    pubdate: Number.isFinite(Number(input.pubdate)) ? Number(input.pubdate) : null,
    /**
     * 是否允许"只有元数据没有行为"时按隐含观看计入画像。
     * 视频详情/内联状态 = true（你确实打开了那个页面）；
     * 合集/系列列表 = false（打开的是合集面板，不代表看了里面每个视频）。
     */
    implicitOk: input.implicitOk !== false,
    updatedAt: Date.now(),
  };
}

/**
 * 合并两条同 ID 的记录。规则：
 *  - 标题/UP 名：空值不覆盖已有值
 *  - 标签：取并集（收藏夹不带标签，详情页带，谁有就留谁）
 *  - 分区：置信度更高的一方获胜；相同置信度则用新值
 */
export function mergeItem(oldItem, newItem) {
  if (!oldItem) return newItem;
  const merged = { ...oldItem };

  if (newItem.title) merged.title = newItem.title;
  // implicitOk 一旦被某个来源标成 false，就不允许别的来源再翻回 true
  if (newItem.implicitOk === false) merged.implicitOk = false;
  if (newItem.upId !== null && newItem.upId !== undefined) merged.upId = newItem.upId;
  if (newItem.upName) merged.upName = newItem.upName;
  if (newItem.pubdate) merged.pubdate = newItem.pubdate;

  if (Array.isArray(newItem.tags) && newItem.tags.length > 0) {
    merged.tags = [...new Set([...(oldItem.tags || []), ...newItem.tags])].slice(0, LIMITS.tagsPerItem);
  }

  const oldConf = Number(oldItem.categoryConfidence) || 0;
  const newConf = Number(newItem.categoryConfidence) || 0;
  if (newItem.category && newConf >= oldConf) {
    merged.category = newItem.category;
    merged.categoryConfidence = newConf;
    if (newItem.categoryId !== null && newItem.categoryId !== undefined) merged.categoryId = newItem.categoryId;
  }

  merged.updatedAt = newItem.updatedAt || Date.now();
  return merged;
}
