/**
 * 全局常量与边界。
 *
 * 本文件是整个项目的"合规基线"：任何模块不得绕过这里的限制。
 */

export const SCHEMA_VERSION = 1;
export const CARD_VERSION = 2;
export const CARD_PREFIX = 'MS1.';
/** 旧版名片前缀，只用于兼容解码；新卡一律用 CARD_PREFIX。 */
export const CARD_PREFIX_LEGACY = Object.freeze(['MC1.']);

/** 行为权重：收藏/投币最重，看完（历史）最轻。 */
export const ACTION_WEIGHT = Object.freeze({
  fav: 1.0,
  coin: 1.0,
  /** 追番 / 追剧：主动订阅，强于"看过"，略弱于"收藏" */
  follow: 0.9,
  like: 0.8,
  watch: 0.3,
  history: 0.15,
});

/**
 * 采集器注册表 —— 唯一的"数据源"定义。
 *
 * 每个条目对应仪表盘上的一个独立开关：
 *   id       开关标识（设置里存的就是它）
 *   paths    该采集器负责的接口/通道（同时用来生成 OBSERVED_PATHS 白名单）
 *   defaultOn 首次安装时是否开启
 *   thirdParty 是否涉及他人的公开内容（UI 会额外警示）
 */
export const COLLECTORS = Object.freeze([
  {
    id: 'video',
    label: '视频页',
    desc: '打开视频时读取它的分区与标签，并记为一次观看',
    paths: ['mirroself://page-state/video', '/x/web-interface/view', '/x/web-interface/view/detail'],
    defaultOn: true,
    thirdParty: false,
  },
  {
    id: 'history',
    label: '历史记录',
    desc: '读取你自己的观看历史（只保留进度 ≥30% 的条目）',
    paths: ['/x/web-interface/history/cursor', '/x/v2/history'],
    defaultOn: true,
    thirdParty: false,
  },
  {
    id: 'favorites',
    label: '收藏夹',
    desc: '读取你自己的收藏列表，以及手动采集页面上可见的收藏',
    paths: ['/x/v3/fav/resource/list', 'mirroself://dom/favlist'],
    defaultOn: true,
    thirdParty: false,
  },
  {
    id: 'series',
    label: '合集 / 系列',
    desc: '打开视频的合集或系列时，读取其中作品的元数据（不记为观看）',
    paths: ['/x/polymer/web-space/seasons_archives_list'],
    defaultOn: true,
    thirdParty: false,
  },
  {
    id: 'bangumi',
    label: '番剧 / 国创',
    desc: '打开番剧播放页记一次观看；打开追番列表读你自己追的番（按"追番"记账）',
    paths: ['/pgc/view/web/season', '/x/space/bangumi/follow/list'],
    defaultOn: true,
    thirdParty: false,
  },
]);

/** 采集器 id → 是否默认开启 */
export function defaultCollectorSwitches() {
  const out = {};
  for (const c of COLLECTORS) out[c.id] = c.defaultOn;
  return out;
}

/** 采集器 id → 人话标签 */
export function collectorLabel(id) {
  const hit = COLLECTORS.find((c) => c.id === id);
  return hit ? hit.label : id;
}

/** 分区置信度：来自视频详情页的 tid 是精确的，来自历史记录的 tag_name 是粗粒度的。 */
export const CATEGORY_CONFIDENCE = Object.freeze({
  exact: 1.0,
  coarse: 0.6,
});

/**
 * 历史记录的最低观看进度（0..1）。
 *
 * 只看了一点点就划走的视频不构成兴趣证据，收进来只会稀释画像。
 * 进度取自历史接口的 `progress / duration`；任一字段缺失时**不过滤**——
 * 宁可多收几条，也不要因为字段改名把整批真实数据丢掉。
 */
export const MIN_WATCH_RATIO = 0.3;

/**
 * 元数据样本目标量。
 *
 * 覆盖率用"绝对样本数 / 目标"来算，而不是"有元数据的条目 / 总条目"。
 * 原因：收藏夹能采到几百上千条**没有分区标签**的条目，用总条目做分母的话，
 * 覆盖率会被瞬间稀释到 3%，可用性门槛反而把画像判死 —— 而那些条目本来
 * 就不参与向量计算，稀释它毫无意义。
 */
export const METADATA_TARGET = 100;

/**
 * 名片打分权重。
 *
 * 注意：缺失的信号**不再重新归一化**，缺失就当 0 计入分母 ——
 * 否则只有标签的人会拿到满分（旧实现里 68.6% 被标成"高度同频"）。
 * 所以这里的权重同时也是"你能拿到的最高分"。
 * UP 主分布刻意不进名片（它最接近身份指纹），只在本地自用。
 */
export const SCORE_WEIGHTS = Object.freeze({
  partition: 0.55,
  tag: 0.45,
});

/**
 * 相似度分档阈值。
 *
 * 归一化去掉之后，分数上限随信号数量下降（只有标签的人最高 0.45），
 * 阈值必须跟着下调：绝大多数只在分区上相近的人会落在 0.2~0.35。
 * 校准依据见 `node scripts/demo-match.mjs` 的矩阵。
 */
export const SCORE_BANDS = Object.freeze([
  { level: 'high', min: 0.45, label: '高度同频' },
  { level: 'mid', min: 0.2, label: '有交集' },
  { level: 'low', min: 0, label: '交集较少' },
]);

/**
 * 可用性阈值：低于这个覆盖率就**拒绝出分**，而不是给一个看起来很确定的档位。
 *
 * 起因：两个各自只点开过同样 3 个视频的用户，在旧实现里会拿到 100%「高度同频」。
 * 这种"碰巧撞上同一个热门视频"的匹配必须在数学上被挡住。
 */
export const USABILITY = Object.freeze({
  /** 分区覆盖率或标签覆盖率的较大者，低于它就不参与比较（0.12 ≈ 12%） */
  minSignal: 0.12,
  /** 作品数低于它不参与比较 */
  minItems: 30,
  /** 名片里写入的 q 值下限（0..100） */
  minCardQuality: 12,
});

/**
 * 卡片里允许出现的字段上限。
 * 卡片是"用户亲手预览并同意发布"的东西，所以宁少勿多。
 */
export const LIMITS = Object.freeze({
  titleMax: 200,
  tagsPerItem: 16,
  upNameMax: 60,
  cardPartitions: 12,
  cardTags: 24,
  cardHighlightTags: 8,
  cardNicknameMax: 32,
  itemsPerMessage: 500,
  maxBodyBytes: 400_000,
});

/**
 * 允许被"读取"的接口路径，由 COLLECTORS 自动派生。
 * 采集器增删路径时这里会自动跟着变，不需要手抄一遍。
 */
export const OBSERVED_PATHS = Object.freeze([...new Set(COLLECTORS.flatMap((c) => c.paths))]);

/** 明确禁止出现在本仓库源码中的字符串（合规定性不清的能力）。 */
export const FORBIDDEN_TOKENS = Object.freeze([
  'wbi',
  'X-Sign',
  'x-signature',
  '_signature',
  'X-Bili-',
  'proxy',
  'puppeteer',
  'playwright',
  'selenium',
  'like/user/list',
  'like/web/',
  'coins/user/list',
  'follow/user/list',
  'fans/list',
  // 他人空间的投稿列表 / 用户资料 —— 只碰自己数据的边界，永远不采
  'space/wbi/arc/search',
  'space/wbi/acc/info',
]);
