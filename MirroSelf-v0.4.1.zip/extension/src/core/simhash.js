/**
 * 64 位 SimHash + 4×16 位分桶。
 *
 * ⚠️ **当前不在运行时路径上**。v0.2 已把名片里的 `h` 移除（它是绕过打噪的旁路），
 * 而外部检测报告的实测又证明：FNV-1a 的位不独立、桶倾斜严重，
 * 中等相似召回 0%、极不相似误命中 13.8% —— 它不适合当 M4 的召回层。
 *
 * 因此本模块只保留作**离线实验工具**（`tests/simhash.test.mjs` 仍在验证它的性质）。
 * M4 的召回改用语义粗键倒排索引，见 docs/M4-vercel-部署方案.md 第 4 节。
 *
 * 保留原因：如果把未验证的算法删干净，后来的人会以为"没做过实验"。
 * 它是被证伪的记录，不是待办。
 */

import { fnv1a64, hex64, parseHex64 } from './hash.js';

export const SIMHASH_BITS = 64;
export const BAND_COUNT = 4;
export const BAND_WIDTH = 16;

/**
 * 由加权特征计算 SimHash。
 * @param {Array<{key: string, weight: number}>} features
 * @returns {bigint} 64 位无符号整数
 */
export function simhash(features) {
  const acc = new Float64Array(SIMHASH_BITS);

  // 先按 key 排序再累加：浮点加法不满足结合律，若顺序不同，
  // "正负权重刚好抵消"的那些位会翻转，导致同一份兴趣算出不同指纹。
  // 排序后输入顺序不再影响结果，可复现性优先于那点排序开销。
  const sorted = [];
  for (const f of features || []) {
    const w = Number(f?.weight);
    if (!f?.key || !(w > 0)) continue;
    sorted.push({ key: String(f.key), weight: w });
  }
  sorted.sort((a, b) => (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));

  for (const f of sorted) {
    const h = fnv1a64(f.key);
    for (let bit = 0; bit < SIMHASH_BITS; bit += 1) {
      const on = (h >> BigInt(bit)) & 1n;
      acc[bit] += on === 1n ? f.weight : -f.weight;
    }
  }
  let out = 0n;
  for (let bit = 0; bit < SIMHASH_BITS; bit += 1) {
    if (acc[bit] > 1e-12) out |= 1n << BigInt(bit);
  }
  return out;
}

/** 汉明距离（0..64）。 */
export function hamming(a, b) {
  let x = BigInt(a) ^ BigInt(b);
  let count = 0;
  while (x !== 0n) {
    x &= x - 1n;
    count += 1;
  }
  return count;
}

/**
 * 切成 4 段 16 位。鸽笼原理：汉明距离 ≤ 3 时，至少有一段完全相同，
 * 所以只要按单段建索引，召回就是有保证的。
 */
export function bands(hash) {
  const h = BigInt(hash);
  const out = [];
  for (let i = 0; i < BAND_COUNT; i += 1) {
    out.push(Number((h >> BigInt(i * BAND_WIDTH)) & 0xffffn));
  }
  return out;
}

/** 特征集 → 完整指纹对象。 */
export function fingerprint(features) {
  const h = simhash(features);
  return { hex: hex64(h), bands: bands(h) };
}

/** 两个十六进制指纹之间的汉明距离。 */
export function distanceHex(a, b) {
  return hamming(parseHex64(a), parseHex64(b));
}
