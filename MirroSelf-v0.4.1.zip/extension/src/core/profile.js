/**
 * 兴趣画像构建。
 *
 * 输入：**用户自己**的作品元数据 + 行为记录。
 * 输出：一份可比较、可解释的画像。全程本地，不涉及任何第三方数据。
 *
 * 三个信号：
 *   1. partitionVec —— 分区分布（用户原始设想里的"分区相似"）
 *   2. tagVec       —— 标签 TF-IDF（比分区细，且自带热门惩罚）
 *   3. upVec        —— UP 主分布（只在本地自用，**不进名片**）
 */

import { ACTION_WEIGHT, LIMITS, METADATA_TARGET, SCHEMA_VERSION, USABILITY } from './constants.js';
import { l1Normalize, herfindahl, topEntries } from './vector.js';

const HOURS = 24;

export function buildProfile({ items = [], interactions = [], now = Date.now() } = {}) {
  const byId = new Map();
  for (const it of items) {
    if (it && typeof it.itemId === 'string' && it.itemId) byId.set(it.itemId, it);
  }

  // 同一作品只计一次，取权重最高的那次行为。
  const best = new Map();
  for (const rec of interactions) {
    if (!rec || typeof rec.itemId !== 'string' || !rec.itemId) continue;
    const w = Number(rec.weight ?? ACTION_WEIGHT[rec.action] ?? 0);
    if (!(w > 0)) continue;
    const cur = best.get(rec.itemId);
    if (!cur || w > cur.weight) {
      best.set(rec.itemId, {
        itemId: rec.itemId,
        weight: w,
        action: rec.action || 'unknown',
        ts: toSeconds(rec.ts),
      });
    }
  }

  const realInteractions = best.size;

  // 隐式观看回填。
  //
  // 有些条目只有元数据、没有行为记录 —— 最典型的是"页面内联状态"通道：
  // 用户打开视频页，我们拿到分区和标签，但那一刻没有产生任何交互。
  // 如果直接忽略，会出现"采了 17 条、画像里 0 条"的荒谬结果。
  //
  // 只在 categoryConfidence === 1（精确分区，只可能来自视频详情页/内联状态）
  // 时才敢这样推断：那意味着用户确实打开过那个页面。权重取 watch 的一半。
  let implicitWatches = 0;
  for (const item of byId.values()) {
    if (best.has(item.itemId)) continue;
    const conf = Number(item.categoryConfidence) || 0;
    if (conf < 1) continue;
    if (item.implicitOk === false) continue; // 合集/系列列表：打开的是面板，不是看了视频
    best.set(item.itemId, {
      itemId: item.itemId,
      weight: ACTION_WEIGHT.watch * 0.5,
      action: 'watch',
      ts: null,
      implicit: true,
    });
    implicitWatches += 1;
  }

  const partitionRaw = {};
  const tagRaw = {};
  const tagDf = {};
  const upRaw = {};
  const upNames = {};
  const hour = new Array(HOURS).fill(0);
  const seen = new Set();

  let matched = 0;
  let withCategory = 0;
  let withTags = 0;
  let totalWeight = 0;

  for (const rec of best.values()) {
    const item = byId.get(rec.itemId);
    if (!item) continue;
    matched += 1;
    const w = rec.weight;
    totalWeight += w;

    const label = typeof item.category === 'string' ? item.category.trim() : '';
    if (label) {
      const conf = Number(item.categoryConfidence);
      const eff = Number.isFinite(conf) && conf > 0 ? conf : 1;
      partitionRaw[label] = (partitionRaw[label] || 0) + w * eff;
      withCategory += 1;
    }

    const tags = Array.isArray(item.tags) ? item.tags.slice(0, LIMITS.tagsPerItem) : [];
    if (tags.length > 0) {
      withTags += 1;
      for (const raw of tags) {
        const t = typeof raw === 'string' ? raw.trim() : '';
        if (!t || seen.has(rec.itemId + '\u0000' + t)) continue;
        seen.add(rec.itemId + '\u0000' + t);
        tagRaw[t] = (tagRaw[t] || 0) + w;
        tagDf[t] = (tagDf[t] || 0) + 1;
      }
    }

    if (item.upId !== undefined && item.upId !== null && item.upId !== '') {
      const key = String(item.upId);
      upRaw[key] = (upRaw[key] || 0) + w;
      if (item.upName && !upNames[key]) upNames[key] = String(item.upName).slice(0, LIMITS.upNameMax);
    }

    if (rec.ts) hour[new Date(rec.ts * 1000).getHours()] += 1;
  }

  return finalize({
    now,
    interactionCount: realInteractions,
    implicitWatches,
    matched,
    withCategory,
    withTags,
    totalWeight,
    partitionRaw,
    tagRaw,
    tagDf,
    upRaw,
    upNames,
    hour,
  });
}

function finalize(ctx) {
  const partitionVec = l1Normalize(ctx.partitionRaw);
  const upVec = l1Normalize(ctx.upRaw);
  const tagVec = buildTfIdf(ctx.tagRaw, ctx.tagDf, ctx.withTags);

  const topPartitions = topEntries(partitionVec, 10).map(([name, share]) => ({
    name,
    share,
    weight: ctx.partitionRaw[name] || 0,
  }));
  const topTags = topEntries(tagVec, 30).map(([name, w]) => ({ name, weight: w }));
  const topUps = topEntries(upVec, 20).map(([upId, share]) => ({
    upId,
    name: ctx.upNames[upId] || upId,
    share,
  }));

  const hourTotal = ctx.hour.reduce((a, b) => a + b, 0);
  const timeHist = hourTotal > 0 ? ctx.hour.map((v) => v / hourTotal) : new Array(HOURS).fill(0);

  const coverage = {
    // 绝对样本量归一化：采集到 100 条带分区/标签的记录就算"充足"，
    // 不会被几百条无元数据的收藏稀释（见 constants.js 的 METADATA_TARGET）。
    category: Math.min(1, ctx.withCategory / METADATA_TARGET),
    tags: Math.min(1, ctx.withTags / METADATA_TARGET),
  };

  return {
    schema: SCHEMA_VERSION,
    builtAt: ctx.now,
    interactionCount: ctx.interactionCount,
    /** 只有元数据、没有行为记录、按"打开过页面"推断出来的条数 */
    implicitWatches: ctx.implicitWatches || 0,
    itemCount: ctx.matched,
    totalWeight: ctx.totalWeight,
    partitionVec,
    tagVec,
    upVec,
    timeHist,
    topPartitions,
    topTags,
    topUps,
    coverage,
    /** 原始计数，UI 用来显示"54 / 100 条"这种具体数字 */
    metadata: { category: ctx.withCategory, tags: ctx.withTags, total: ctx.matched, target: METADATA_TARGET },
    concentration: herfindahl(partitionVec),
    /** 0..1 的综合可信度：数据量 + 字段覆盖度共同决定。 */
    confidence: computeConfidence(ctx, coverage),
  };
}

function buildTfIdf(tagRaw, tagDf, docCount) {
  const out = {};
  if (!(docCount > 0)) return out;
  let total = 0;
  for (const k in tagRaw) total += tagRaw[k];
  if (!(total > 0)) return out;
  for (const k in tagRaw) {
    const tf = tagRaw[k] / total;
    const df = tagDf[k] || 1;
    const idf = Math.log((docCount + 1) / (1 + df)) + 1;
    const v = tf * idf;
    if (v > 0) out[k] = v;
  }
  return out;
}

function computeConfidence(ctx, coverage) {
  const volume = Math.min(1, ctx.matched / 300); // 300 条基本够描述一个人
  const weight = Math.min(1, ctx.totalWeight / 400);
  const cover = (coverage.category * 0.5 + coverage.tags * 0.5);
  return Number((volume * 0.4 + weight * 0.2 + cover * 0.4).toFixed(3));
}

function toSeconds(ts) {
  const n = Number(ts);
  if (!Number.isFinite(n) || n <= 0) return null;
  return n > 1e12 ? Math.floor(n / 1000) : Math.floor(n);
}

/**
 * 这份画像够不够格参与"相似度比较"。
 *
 * 检测报告里最刺眼的实证：两个各自只点开过同样 3 个视频的人，旧实现给出
 * 100%「高度同频」。挡住这种匹配不能靠 UI 提示，必须在数学上拒绝出分。
 */
export function assessProfile(profile) {
  const itemCount = Number(profile?.itemCount) || 0;
  const signal = Math.max(Number(profile?.coverage?.category) || 0, Number(profile?.coverage?.tags) || 0);
  if (itemCount < USABILITY.minItems) {
    return { usable: false, signal, reason: `只有 ${itemCount} 条作品，少于 ${USABILITY.minItems} 条` };
  }
  if (signal < USABILITY.minSignal) {
    return {
      usable: false,
      signal,
      reason: `分区/标签覆盖率只有 ${Math.round(signal * 100)}%，低于 ${Math.round(USABILITY.minSignal * 100)}%`,
    };
  }
  return { usable: true, signal };
}

/** 空画像，UI 初始状态用。 */export function emptyProfile(now = Date.now()) {
  return finalize({
    now,
    interactionCount: 0,
    matched: 0,
    withCategory: 0,
    withTags: 0,
    totalWeight: 0,
    partitionRaw: {},
    tagRaw: {},
    tagDf: {},
    upRaw: {},
    upNames: {},
    hour: new Array(HOURS).fill(0),
  });
}

/** 把画像压成一句人话，用于概览页与名片说明。 */
export function describeProfile(profile) {
  if (!profile || !(profile.itemCount > 0)) return '还没有数据，先去"采集"页看看怎么积累。';
  const parts = profile.topPartitions.slice(0, 3).map((p) => p.name);
  const tags = profile.topTags.slice(0, 4).map((t) => '#' + t.name);
  const core = parts.length ? parts.join(' / ') : '分区信息不足';
  const tail = tags.length ? '，常出现 ' + tags.join(' ') : '';
  return `你的兴趣集中在 ${core}${tail}。`;
}
