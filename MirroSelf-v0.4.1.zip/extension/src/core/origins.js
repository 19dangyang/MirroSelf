/**
 * 允许的站点白名单（唯一事实来源）。
 *
 * 需要两个主机：
 *   www.bilibili.com    —— 视频页、历史记录页
 *   space.bilibili.com  —— 个人空间 / 收藏夹页（收藏请求由这个域发起）
 *
 * manifest 的 host_permissions / content_scripts 必须与这里一致，
 * `npm run check` 会逐项比对，改一处漏一处就报错。
 */

export const ALLOWED_ORIGINS = Object.freeze(['https://www.bilibili.com', 'https://space.bilibili.com']);

export function originOf(url) {
  try {
    return new URL(String(url)).origin;
  } catch {
    return '';
  }
}

/** 标签页 URL 是否属于允许范围。 */
export function isAllowedTabUrl(url) {
  const origin = originOf(url);
  return origin !== '' && ALLOWED_ORIGINS.includes(origin);
}

/** manifest 里应该写的匹配模式，例如 https://www.bilibili.com/* */
export function matchPatterns() {
  return ALLOWED_ORIGINS.map((o) => o + '/*');
}
