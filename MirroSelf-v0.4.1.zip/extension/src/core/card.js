/**
 * 兴趣名片：唯一一个"可以离开你设备"的数据结构。
 *
 * 设计原则：**透明即合规**。名片里的每一个字段都会在 UI 里原样预览，
 * 用户点头才导出。没有作品 ID、没有时间戳、没有关注列表、没有 UP 主分布。
 *
 * 字段（v2）：
 *   v  版本 / k 类型 / id 随机标识（可轮换）
 *   n  昵称（可空） / hl 用户亲手挑的亮点标签（明文，最多 8 个）
 *   p  分区分布（量化 0..15 并加噪，最多 12 项）
 *   g  标签分布（量化 0..15 并加噪，最多 24 项）
 *   q  信号质量 0..100（= 分区/标签覆盖率的较大者），用来挡住"数据太薄却算出高分"
 *   c  收藏量级（分桶） / ts 导出时间 / s 随机盐
 *
 * v1 里的 `h`（64 位 SimHash）已被**移除**：它由未量化、未加噪的原始画像算出，
 * 等于在名片里留了一条比可见字段更精确的旁路，而且不含盐、可跨卡链接。
 * M4 若需要召回指纹，应当由服务端基于这里公开的 p/g 计算，而不是让客户端夹带。
 */

import { CARD_PREFIX, CARD_PREFIX_LEGACY, CARD_VERSION, LIMITS } from './constants.js';
import { quantize, topEntries } from './vector.js';
import { toBase64Url, fromBase64Url, utf8ToBytes, bytesToUtf8, randomId } from './hash.js';
import { mulberry32, randomSeed } from './random.js';

/** 收藏量级分桶：只暴露数量级，不暴露精确条数。 */
export function countBucket(n) {
  const v = Math.max(0, Math.floor(Number(n) || 0));
  if (v <= 0) return 0;
  const ladder = [50, 100, 300, 500, 1000, 3000, 5000, 10000, 30000];
  const hit = ladder.find((x) => v <= x);
  return hit === undefined ? 30000 : hit;
}

/** 信号质量：分区/标签覆盖率的较大者，0..100。 */
export function qualityOf(profile) {
  const cov = profile?.coverage || {};
  const signal = Math.max(Number(cov.category) || 0, Number(cov.tags) || 0);
  return Math.max(0, Math.min(100, Math.round(signal * 100)));
}

/**
 * 由画像生成一张名片。
 * @param {object} profile buildProfile() 的结果
 * @param {{nickname?: string, highlightTags?: string[], noiseScale?: number, seed?: number, now?: number}} opts
 */
export function buildCard(profile, opts = {}) {
  if (!profile) throw new Error('缺少画像，无法生成名片');
  const { nickname = '', highlightTags = [], noiseScale = 0.35, now = Date.now() } = opts;
  // 种子必须是密码学随机的：时间戳派生的种子可被名片里的秒级 ts 复现。
  const seed = opts.seed !== undefined ? opts.seed : randomSeed();
  const rng = mulberry32(seed);

  const partitionEntries = Object.entries(quantize(profile.partitionVec || {}, { levels: 15, max: 0, noiseScale, rng }))
    .sort((x, y) => y[1] - x[1] || (x[0] < y[0] ? -1 : 1))
    .slice(0, LIMITS.cardPartitions);
  const partitions = Object.fromEntries(partitionEntries);

  const tagEntries = Object.entries(quantize(profile.tagVec || {}, { levels: 15, max: 0, noiseScale, rng }))
    .sort((x, y) => y[1] - x[1] || (x[0] < y[0] ? -1 : 1))
    .slice(0, LIMITS.cardTags);
  const tags = Object.fromEntries(tagEntries);

  return {
    v: CARD_VERSION,
    k: 'mirroself-card',
    id: randomId(8),
    n: String(nickname || '').trim().slice(0, LIMITS.cardNicknameMax),
    p: partitions,
    g: tags,
    q: qualityOf(profile),
    c: countBucket(profile.itemCount),
    hl: (Array.isArray(highlightTags) ? highlightTags : [])
      .map((t) => String(t || '').trim())
      .filter(Boolean)
      .slice(0, LIMITS.cardHighlightTags),
    ts: Math.floor(now / 1000),
    s: randomId(6),
  };
}

/** 名片 → 可复制的一段文本。 */
export function encodeCard(card) {
  return CARD_PREFIX + toBase64Url(utf8ToBytes(JSON.stringify(card)));
}

/** 文本 → 名片。容错：容忍空白、换行、旧前缀。 */
export function decodeCard(text) {
  if (typeof text !== 'string') throw new Error('名片内容不是文本');
  const cleaned = text.trim().replace(/\s+/g, '');
  if (!cleaned) throw new Error('名片内容为空');

  let body = null;
  if (cleaned.startsWith(CARD_PREFIX)) body = cleaned.slice(CARD_PREFIX.length);
  else {
    for (const legacy of CARD_PREFIX_LEGACY) {
      if (cleaned.startsWith(legacy)) throw new Error('这是旧版名片（v1），请让对方用当前版本重新导出');
    }
    body = cleaned;
  }

  let card;
  try {
    card = JSON.parse(bytesToUtf8(fromBase64Url(body)));
  } catch {
    throw new Error('名片格式无法解析，确认复制完整（应以 ' + CARD_PREFIX + ' 开头）');
  }
  const check = validateCard(card);
  if (!check.ok) throw new Error(check.reason);
  return card;
}

export function validateCard(card) {
  if (!card || typeof card !== 'object') return fail('名片不是对象');
  if (card.v === 1) return fail('这是旧版名片（v1），请让对方用当前版本重新导出');
  if (card.v !== CARD_VERSION) return fail(`名片版本不支持（收到 ${String(card.v)}）`);
  if (card.k !== 'mirroself-card') return fail('不是 MirroSelf 名片');
  if (typeof card.id !== 'string' || !card.id) return fail('缺少名片 ID');
  if (!isWeightMap(card.p, LIMITS.cardPartitions)) return fail('分区分布字段非法或过大');
  if (!isWeightMap(card.g, LIMITS.cardTags)) return fail('标签分布字段非法或过大');
  if (card.h !== undefined) return fail('名片里不应出现指纹字段 h');
  if (card.q !== undefined && (typeof card.q !== 'number' || card.q < 0 || card.q > 100)) return fail('质量字段非法');
  if (card.n !== undefined && (typeof card.n !== 'string' || card.n.length > LIMITS.cardNicknameMax)) {
    return fail('昵称过长');
  }
  if (card.hl !== undefined && (!Array.isArray(card.hl) || card.hl.length > LIMITS.cardHighlightTags)) {
    return fail('亮点标签过多');
  }
  return { ok: true };
}

function fail(reason) {
  return { ok: false, reason };
}

function isWeightMap(map, maxKeys) {
  if (map === undefined) return true;
  if (!map || typeof map !== 'object' || Array.isArray(map)) return false;
  const keys = Object.keys(map);
  if (keys.length > maxKeys) return false;
  for (const k of keys) {
    const v = map[k];
    if (typeof k !== 'string' || !k || k.length > 48) return false;
    if (typeof v !== 'number' || !Number.isFinite(v) || v < 0 || v > 15) return false;
  }
  return true;
}

/** 名片摘要，用于列表展示。 */
export function describeCard(card) {
  const parts = topEntries(card.p || {}, 3).map(([k]) => k);
  const tags = topEntries(card.g || {}, 4).map(([k]) => '#' + k);
  const head = parts.length ? parts.join(' · ') : '无分区信息';
  return tags.length ? `${head} ｜ ${tags.join(' ')}` : head;
}
