/**
 * 同构哈希与编码工具（Node 与浏览器通用，无外部依赖）。
 */

const B64URL = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
const B64URL_REV = (() => {
  const m = new Map();
  for (let i = 0; i < B64URL.length; i += 1) m.set(B64URL[i], i);
  return m;
})();

const MASK64 = 0xffffffffffffffffn;
const FNV_OFFSET = 0xcbf29ce484222325n;
const FNV_OFFSET_B = 0xcbf29ce484222325n ^ 0x5bd1e995n;
const FNV_PRIME = 0x100000001b3n;

export function utf8ToBytes(str) {
  return new TextEncoder().encode(String(str));
}

export function bytesToUtf8(bytes) {
  return new TextDecoder().decode(bytes);
}

/** 无填充 base64url 编码，输出可直接放进 URL / 剪贴板 / 二维码。 */
export function toBase64Url(bytes) {
  let out = '';
  for (let i = 0; i < bytes.length; i += 3) {
    const b0 = bytes[i];
    const b1 = bytes[i + 1];
    const b2 = bytes[i + 2];
    out += B64URL[b0 >> 2];
    out += B64URL[((b0 & 3) << 4) | ((b1 ?? 0) >> 4)];
    if (b1 === undefined) break;
    out += B64URL[((b1 & 15) << 2) | ((b2 ?? 0) >> 6)];
    if (b2 === undefined) break;
    out += B64URL[b2 & 63];
  }
  return out;
}

export function fromBase64Url(str) {
  const s = String(str).replace(/[\s=]+/g, '');
  const out = new Uint8Array(Math.floor((s.length * 3) / 4));
  let buf = 0;
  let bits = 0;
  let o = 0;
  for (const ch of s) {
    const v = B64URL_REV.get(ch);
    if (v === undefined) throw new Error('非法的 base64url 字符: ' + ch);
    buf = (buf << 6) | v;
    bits += 6;
    if (bits >= 8) {
      bits -= 8;
      out[o] = (buf >> bits) & 0xff;
      o += 1;
    }
  }
  return out.subarray(0, o);
}

/** FNV-1a 64 位。用于 SimHash 的特征哈希，稳定且无需依赖。 */
export function fnv1a64(str) {
  const bytes = utf8ToBytes(str);
  let h = FNV_OFFSET;
  for (let i = 0; i < bytes.length; i += 1) {
    h ^= BigInt(bytes[i]);
    h = (h * FNV_PRIME) & MASK64;
  }
  return h;
}

/** 换一个初始常量的变体，用来给同一段文本取第二个独立 64 位值。 */
export function fnv1a64b(str) {
  const bytes = utf8ToBytes(str);
  let h = FNV_OFFSET_B;
  for (let i = 0; i < bytes.length; i += 1) {
    h ^= BigInt(bytes[i]);
    h = (h * FNV_PRIME) & MASK64;
  }
  return h;
}

/** FNV-1a 32 位，返回无符号整数。 */
export function fnv1a32(str) {
  const bytes = utf8ToBytes(str);
  let h = 0x811c9dc5;
  for (let i = 0; i < bytes.length; i += 1) {
    h ^= bytes[i];
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

export function hex64(value) {
  return BigInt(value).toString(16).padStart(16, '0');
}

export function parseHex64(hex) {
  return BigInt('0x' + String(hex).replace(/[^0-9a-fA-F]/g, ''));
}

/** 生成随机字节串（用于卡片 ID / 匿名令牌）。 */
export function randomBytes(n = 12) {
  const out = new Uint8Array(n);
  const webcrypto = globalThis.crypto;
  if (webcrypto && typeof webcrypto.getRandomValues === 'function') {
    webcrypto.getRandomValues(out);
    return out;
  }
  for (let i = 0; i < n; i += 1) out[i] = Math.floor(Math.random() * 256);
  return out;
}

export function randomId(n = 12) {
  return toBase64Url(randomBytes(n));
}

/** 稳定的短哈希，用于列表去重键。 */
export function shortHash(str) {
  return fnv1a32(String(str)).toString(36);
}
