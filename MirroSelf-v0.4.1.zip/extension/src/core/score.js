/**
 * 名片之间的相似度打分与解释。
 *
 * 两个重要修正（都来自检测报告）：
 *
 * 1. **缺失信号不再重新归一化**。旧实现把缺失信号的权重剔除后按剩余权重
 *    重新归一化，结果"只有标签、没有分区"的人反而能拿 100% 满分 ——
 *    不同数据完整度的人根本不在同一把尺子上。现在分母固定为全部权重之和，
 *    缺一个信号就是真的少一截分。
 *
 * 2. **数据太薄时拒绝出分**。两个各自只点开过同样 3 个视频的人，旧实现会得到
 *    「高度同频 100%」。现在名片携带 q（信号覆盖率），任一方低于阈值就标记为
 *    "不可比较"，UI 显示"数据不足"而不是一个看起来很确定的档位。
 */

import { SCORE_WEIGHTS, SCORE_BANDS, USABILITY } from './constants.js';
import { cosine, size } from './vector.js';

/**
 * @param {{p?: object, g?: object, q?: number}} a 名片 A
 * @param {{p?: object, g?: object, q?: number}} b 名片 B
 * @returns {{score: number, parts: object, weights: object, signals: string[], signalCoverage: number}}
 */
export function scoreCards(a, b, weights = SCORE_WEIGHTS) {
  const parts = {};
  const used = {};
  const signals = [];

  if (size(a?.p) > 0 && size(b?.p) > 0) {
    parts.partition = cosine(a.p, b.p);
    used.partition = weights.partition;
    signals.push('partition');
  }
  if (size(a?.g) > 0 && size(b?.g) > 0) {
    parts.tag = cosine(a.g, b.g);
    used.tag = weights.tag;
    signals.push('tag');
  }

  const total = weights.partition + weights.tag;
  if (!(total > 0)) {
    return { score: 0, parts, weights: used, signals, signalCoverage: 0 };
  }

  let acc = 0;
  for (const key of signals) acc += used[key] * parts[key];
  const available = Object.values(used).reduce((s, w) => s + w, 0);

  return {
    score: clamp01(acc / total),
    parts,
    weights: used,
    signals,
    signalCoverage: available / total,
  };
}

/**
 * 这对名片值不值得比较。
 * @returns {{usable: boolean, reason?: string}}
 */
export function assessUsability(a, b) {
  const qa = Number.isFinite(a?.q) ? a.q : null;
  const qb = Number.isFinite(b?.q) ? b.q : null;
  if (qa === null || qb === null) {
    return { usable: false, reason: '名片缺少信号质量字段（可能是旧版名片）' };
  }
  const low = Math.min(qa, qb);
  if (low < USABILITY.minCardQuality) {
    return { usable: false, reason: `有一方的分区/标签覆盖率只有 ${low}%，低于 ${USABILITY.minCardQuality}% 的比较门槛` };
  }
  return { usable: true };
}

export function clamp01(x) {
  if (!Number.isFinite(x)) return 0;
  return x < 0 ? 0 : x > 1 ? 1 : x;
}

/** 分数 → 分档。给分档而不是伪精确百分比。 */
export function band(score, bands = SCORE_BANDS) {
  const s = clamp01(score);
  for (const b of bands) {
    if (s >= b.min) return b;
  }
  return bands[bands.length - 1];
}

/**
 * 解释"你们为什么像"。这是产品可信度的来源：
 * 没有解释的相似度分数，用户既不信也不敢用。
 */
export function explainPair(a, b, { maxPartitions = 4, maxTags = 5 } = {}) {
  const pA = a?.p || {};
  const pB = b?.p || {};
  const gA = a?.g || {};
  const gB = b?.g || {};

  const sharedPartitions = Object.keys(pA)
    .filter((k) => pB[k] !== undefined)
    .map((k) => ({ name: k, weight: Math.min(pA[k], pB[k]), a: pA[k], b: pB[k] }))
    .sort((x, y) => y.weight - x.weight || (x.name < y.name ? -1 : 1))
    .slice(0, maxPartitions);

  const sharedTags = Object.keys(gA)
    .filter((k) => gB[k] !== undefined)
    .map((k) => ({ name: k, weight: Math.min(gA[k], gB[k]), a: gA[k], b: gB[k] }))
    .sort((x, y) => y.weight - x.weight || (x.name < y.name ? -1 : 1))
    .slice(0, maxTags);

  const overlap = {
    partitions: ratio(Object.keys(pA).length, Object.keys(pB).length, sharedPartitions.length),
    tags: ratio(Object.keys(gA).length, Object.keys(gB).length, sharedTags.length),
  };

  return { sharedPartitions, sharedTags, overlap };
}

function ratio(nA, nB, shared) {
  const denom = Math.min(nA, nB);
  if (!(denom > 0)) return 0;
  return clamp01(shared / denom);
}

/**
 * 排序一组候选名片。
 * 可比较的排在前面；不可比较的保留在列表里但标记出来，不做静默丢弃。
 */
export function rankCards(self, candidates) {
  return (candidates || [])
    .filter((c) => c && c.card)
    .map((c) => {
      const usability = assessUsability(self, c.card);
      const s = scoreCards(self, c.card);
      const e = explainPair(self, c.card);
      return {
        ...c,
        usable: usability.usable,
        unusableReason: usability.reason,
        score: s.score,
        parts: s.parts,
        signalCoverage: s.signalCoverage,
        band: band(s.score),
        explanation: e,
        tiebreak: e.sharedPartitions.length * 2 + e.sharedTags.length,
      };
    })
    .sort(
      (a, b) =>
        Number(b.usable) - Number(a.usable) ||
        b.score - a.score ||
        b.tiebreak - a.tiebreak ||
        String(a.card.id).localeCompare(String(b.card.id)),
    );
}
