/**
 * 本地存储层（IndexedDB）。
 *
 * 只有三张业务表：items（作品元数据）、interactions（我自己的行为）、cards（收到的名片）。
 * 全部数据只存在于本机，没有任何上传路径。
 */

import { normalizeItem, mergeItem } from '../core/merge.js';

const DB_NAME = 'mirror-db';
const DB_VERSION = 1;

export const STORE = Object.freeze({
  items: 'items',
  interactions: 'interactions',
  cards: 'cards',
  meta: 'meta',
});

let dbPromise = null;

function requestToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE.items)) {
        const s = db.createObjectStore(STORE.items, { keyPath: 'itemId' });
        s.createIndex('byUpdatedAt', 'updatedAt');
      }
      if (!db.objectStoreNames.contains(STORE.interactions)) {
        const s = db.createObjectStore(STORE.interactions, { keyPath: 'key' });
        s.createIndex('byItemId', 'itemId');
        s.createIndex('byAction', 'action');
      }
      if (!db.objectStoreNames.contains(STORE.cards)) {
        const s = db.createObjectStore(STORE.cards, { keyPath: 'cardId' });
        s.createIndex('byImportedAt', 'importedAt');
      }
      if (!db.objectStoreNames.contains(STORE.meta)) {
        db.createObjectStore(STORE.meta, { keyPath: 'k' });
      }
    };
    req.onsuccess = () => {
      const db = req.result;
      db.onversionchange = () => db.close();
      resolve(db);
    };
    req.onerror = () => reject(req.error);
  });
  return dbPromise;
}

/** 串行写入队列：避免两个标签页同时采集时互相覆盖。 */
let writeChain = Promise.resolve();
export function serialize(task) {
  const run = writeChain.then(task, task);
  // 让队列在任务失败后仍能继续
  writeChain = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

async function withStore(names, mode, fn) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(names, mode);
    let result;
    tx.oncomplete = () => resolve(result);
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('事务被中止'));
    try {
      result = fn(tx);
    } catch (err) {
      try {
        tx.abort();
      } catch {
        /* ignore */
      }
      reject(err);
    }
  });
}

export async function getAll(storeName) {
  const db = await openDB();
  const tx = db.transaction(storeName, 'readonly');
  return requestToPromise(tx.objectStore(storeName).getAll());
}

export async function countAll() {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction([STORE.items, STORE.interactions, STORE.cards], 'readonly');
    const out = {};
    let pending = 3;
    const done = () => {
      pending -= 1;
      if (pending === 0) resolve(out);
    };
    for (const name of Object.values(STORE)) {
      if (name === STORE.meta) continue;
      const req = tx.objectStore(name).count();
      req.onsuccess = () => {
        out[name] = req.result;
        done();
      };
      req.onerror = () => reject(req.error);
    }
  });
}

export function putItems(items) {
  const cleaned = (items || []).map(normalizeItem).filter(Boolean);
  if (cleaned.length === 0) return Promise.resolve({ written: 0 });
  return serialize(async () => {
    const existing = await getAll(STORE.items);
    const map = new Map(existing.map((i) => [i.itemId, i]));
    for (const item of cleaned) map.set(item.itemId, mergeItem(map.get(item.itemId), item));
    await withStore([STORE.items], 'readwrite', (tx) => {
      const store = tx.objectStore(STORE.items);
      for (const item of cleaned) store.put(map.get(item.itemId));
    });
    return { written: cleaned.length };
  });
}

export function putInteractions(list) {
  const cleaned = [];
  for (const rec of list || []) {
    if (!rec || typeof rec.itemId !== 'string' || !rec.itemId || !rec.action) continue;
    cleaned.push({
      key: `${rec.itemId}|${rec.action}`,
      itemId: rec.itemId,
      action: rec.action,
      weight: Number.isFinite(rec.weight) ? rec.weight : null,
      ts: Number.isFinite(rec.ts) ? rec.ts : null,
      platform: rec.platform || 'bilibili',
      updatedAt: Date.now(),
    });
  }
  if (cleaned.length === 0) return Promise.resolve({ written: 0 });
  return serialize(async () =>
    withStore([STORE.interactions], 'readwrite', (tx) => {
      const store = tx.objectStore(STORE.interactions);
      for (const rec of cleaned) store.put(rec);
    }).then(() => ({ written: cleaned.length })),
  );
}

export function putCards(records) {
  const cleaned = (records || [])
    .filter((r) => r && r.cardId && r.card)
    .map((r) => ({
      cardId: r.cardId,
      card: r.card,
      nickname: r.nickname || r.card.n || '',
      importedAt: r.importedAt || Date.now(),
      note: r.note || '',
    }));
  if (cleaned.length === 0) return Promise.resolve({ written: 0 });
  return serialize(async () =>
    withStore([STORE.cards], 'readwrite', (tx) => {
      const store = tx.objectStore(STORE.cards);
      for (const rec of cleaned) store.put(rec);
    }).then(() => ({ written: cleaned.length })),
  );
}

export function deleteCard(cardId) {
  return serialize(async () =>
    withStore([STORE.cards], 'readwrite', (tx) => {
      tx.objectStore(STORE.cards).delete(cardId);
    }),
  );
}

export async function getMeta(key, fallback = null) {
  const db = await openDB();
  const tx = db.transaction(STORE.meta, 'readonly');
  const rec = await requestToPromise(tx.objectStore(STORE.meta).get(key));
  return rec ? rec.v : fallback;
}

export function setMeta(key, value) {
  return serialize(async () =>
    withStore([STORE.meta], 'readwrite', (tx) => {
      tx.objectStore(STORE.meta).put({ k: key, v: value, updatedAt: Date.now() });
    }),
  );
}

/** 清空业务数据（隐私中心的"一键清除"）。 */
export function clearAllData() {
  return serialize(async () =>
    withStore([STORE.items, STORE.interactions, STORE.cards, STORE.meta], 'readwrite', (tx) => {
      for (const name of Object.values(STORE)) tx.objectStore(name).clear();
    }),
  );
}

/**
 * 彻底删除数据库。
 *
 * 注意语义：IndexedDB 的删除是"浏览器层面移除"，不承诺磁盘扇区擦除。
 * 另外若其他标签页仍持有连接，`deleteDatabase` 会被 **blocked** ——
 * 此时数据库并没有被删掉，必须报错而不是假装成功。
 */
export async function dropDatabase() {
  if (dbPromise) {
    const db = await dbPromise;
    db.close();
    dbPromise = null;
  }
  await new Promise((resolve, reject) => {
    const req = indexedDB.deleteDatabase(DB_NAME);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
    req.onblocked = () => reject(new Error('还有别的标签页连着数据库，请关掉其他 Mirror 页面后重试'));
  });

  // 复核：真的空了才算成功
  const db = await openDB();
  const remaining = await new Promise((resolve, reject) => {
    const tx = db.transaction([STORE.items, STORE.cards], 'readonly');
    let total = 0;
    let pending = 2;
    for (const name of [STORE.items, STORE.cards]) {
      const r = tx.objectStore(name).count();
      r.onsuccess = () => {
        total += r.result;
        pending -= 1;
        if (pending === 0) resolve(total);
      };
      r.onerror = () => reject(r.error);
    }
  });
  if (remaining > 0) throw new Error(`删除未完成：数据库里仍有 ${remaining} 条记录`);
}

/**
 * 导出为可迁移的 JSON。
 *
 * 内容说明（曾经写错过）：包含你自己的 items / interactions，
 * **以及别人主动给你的名片 cards** —— 名片是对方同意发出来的，所以可以随备份走；
 * 除此之外没有任何他人数据。
 */
export async function exportAll() {
  const [items, interactions, cards] = await Promise.all([
    getAll(STORE.items),
    getAll(STORE.interactions),
    getAll(STORE.cards),
  ]);
  return {
    format: 'mirror-export',
    version: 1,
    exportedAt: Date.now(),
    items,
    interactions,
    cards,
  };
}

/** 导入备份。返回各类写入数量。 */
export function importAll(payload) {
  if (!payload || payload.format !== 'mirror-export') {
    throw new Error('不是 Mirror 的备份文件');
  }
  return (async () => {
    const i = await putItems(payload.items || []);
    const n = await putInteractions(payload.interactions || []);
    const c = await putCards(payload.cards || []);
    return { items: i.written, interactions: n.written, cards: c.written };
  })();
}
