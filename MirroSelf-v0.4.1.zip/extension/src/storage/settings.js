/**
 * 轻量设置（chrome.storage.local）。
 *
 * 大块数据放 IndexedDB，设置放这里 —— 因为内容脚本需要同步读取"是否开启采集"。
 */

import { defaultCollectorSwitches } from '../core/constants.js';

const KEY = 'mirrorSettings';

export const DEFAULT_SETTINGS = Object.freeze({
  collectEnabled: true,
  nickname: '',
  highlightTags: [],
  lastIngestAt: 0,
  seenConsent: false,
  /** 每个采集器一个开关，见 constants.js 的 COLLECTORS */
  collectors: defaultCollectorSwitches(),
  /**
   * 匹配池（M4）。默认完全关闭：server 为空时谁也不会联网。
   * privJwk 是一次性 ECDH 私钥，只在本机，用来解密对方发来的联系卡。
   */
  pool: {
    server: '',
    token: '',
    pubB64: '',
    privJwk: null,
    joinedAt: 0,
    contact: '',
  },
});

/** 老版本升级上来时，补齐缺失的采集器开关。 */
function withDefaults(raw) {
  const merged = { ...DEFAULT_SETTINGS, ...(raw || {}) };
  merged.collectors = { ...defaultCollectorSwitches(), ...((raw && raw.collectors) || {}) };
  merged.pool = { ...DEFAULT_SETTINGS.pool, ...((raw && raw.pool) || {}) };
  return merged;
}

export async function getSettings() {
  try {
    const got = await chrome.storage.local.get(KEY);
    return withDefaults(got && got[KEY]);
  } catch {
    return withDefaults(null);
  }
}

export async function updateSettings(patch) {
  const cur = await getSettings();
  const next = { ...cur, ...patch };
  if (patch && patch.collectors) next.collectors = { ...cur.collectors, ...patch.collectors };
  if (patch && patch.pool) next.pool = { ...cur.pool, ...patch.pool };
  await chrome.storage.local.set({ [KEY]: next });
  return next;
}

export function watchSettings(callback) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes[KEY]) return;
    callback(withDefaults(changes[KEY].newValue));
  });
}
