/**
 * 兴趣大屏：把"你自己的数据"画到一张图里。
 *
 * 数据来源只有三种，全部是本地文件或本机数据库：
 *   1. 本机扩展库（chrome-extension:// 下与仪表盘同一个 IndexedDB）
 *   2. 用户拖入/选择的文件（可多选、可整个文件夹）
 *   3. 用户粘贴的文本
 *
 * 没有网络请求，也没有"按 ID 批量拉人"的入口 —— 这是设计上的，不是遗漏。
 */

import { getAll, STORE } from '../storage/db.js';
import { buildProfile, assessProfile } from '../core/profile.js';
import { buildCard } from '../core/card.js';
import { scoreCards, band, explainPair, assessUsability } from '../core/score.js';
import { clusters, hygiene, recommendUps } from '../core/recommend.js';
import { mergeItem } from '../core/merge.js';
import { ingestFiles } from './ingest.js';
import { makeDemo } from './demo.js';
import { barChart, donut, ring, graphSvg, heatmap, scatter, columnChart, legend } from './charts.js';

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const pct = (v) => Math.round((Number(v) || 0) * 100) + '%';
const BAND_COLOR = { high: '#4ade80', mid: '#fbbf24', low: '#94a3b8' };

/** 只有以扩展页面打开时，才读得到 mirror 自己的 IndexedDB。 */
const IS_EXTENSION = location.protocol.endsWith('-extension:');

const state = {
  source: 'none',
  items: [],
  interactions: [],
  cards: [],
  profile: null,
  myCard: null,
  report: null,
  derived: null,
};

const panelsEl = document.getElementById('panels');
const statusEl = document.getElementById('status');
const reportEl = document.getElementById('report');
const dropEl = document.getElementById('drop');
const toastEl = document.getElementById('toast');

// ---------------------------------------------------------------- 数据

function mergeIncoming({ items = [], interactions = [], cards = [] }) {
  const itemMap = new Map(state.items.map((i) => [i.itemId, i]));
  for (const it of items) itemMap.set(it.itemId, mergeItem(itemMap.get(it.itemId), it));
  state.items = [...itemMap.values()];

  const interMap = new Map(state.interactions.map((r) => [`${r.itemId}|${r.action}`, r]));
  for (const rec of interactions) interMap.set(`${rec.itemId}|${rec.action}`, rec);
  state.interactions = [...interMap.values()];

  const cardMap = new Map(state.cards.map((c) => [c.id, c]));
  for (const c of cards) cardMap.set(c.id, c);
  state.cards = [...cardMap.values()];
}

function recompute() {
  state.profile = buildProfile({ items: state.items, interactions: state.interactions });
  state.myCard =
    state.profile.itemCount > 0
      ? buildCard(state.profile, {
          nickname: '我',
          highlightTags: state.profile.topTags.slice(0, 4).map((t) => t.name),
          seed: 20260101,
        })
      : null;
  state.derived = state.profile.itemCount > 0
    ? {
        clusters: clusters({ items: state.items, interactions: state.interactions }, { k: 4 }),
        hygiene: hygiene({ items: state.items, interactions: state.interactions }),
        ups: recommendUps({ items: state.items, interactions: state.interactions }, { limit: 6 }),
      }
    : null;
}

function tagGraph() {
  const p = state.profile;
  if (!p || p.itemCount === 0) return { nodes: [], links: [] };
  const top = p.topTags.slice(0, 18);
  const keys = new Set(top.map((t) => t.name));
  const idx = new Map(top.map((t, i) => [t.name, i]));
  const co = new Map();

  for (const item of state.items) {
    const ts = (item.tags || []).filter((t) => keys.has(t));
    for (let i = 0; i < ts.length; i += 1) {
      for (let j = i + 1; j < ts.length; j += 1) {
        const a = ts[i] < ts[j] ? ts[i] : ts[j];
        const b = ts[i] < ts[j] ? ts[j] : ts[i];
        const k = a + '\u0000' + b;
        co.set(k, (co.get(k) || 0) + 1);
      }
    }
  }

  const nodes = top.map((t) => ({ label: t.name, weight: t.weight * 12 }));
  const links = [...co.entries()]
    .filter(([, c]) => c >= 2)
    .map(([k, c]) => {
      const [a, b] = k.split('\u0000');
      return { source: idx.get(a), target: idx.get(b), weight: c };
    })
    .filter((e) => Number.isInteger(e.source) && Number.isInteger(e.target));
  return { nodes, links, pairs: co.size };
}

function similarityMatrix(cards) {
  const people = [];
  if (state.myCard) people.push({ name: '我', card: state.myCard });
  for (const c of cards) people.push({ name: c.n || '匿名', card: c });
  const n = people.length;
  const matrix = [];
  for (let i = 0; i < n; i += 1) {
    const row = [];
    for (let j = 0; j < n; j += 1) row.push(i === j ? 1 : scoreCards(people[i].card, people[j].card).score);
    matrix.push(row);
  }
  return { people, matrix, labels: people.map((p) => p.name) };
}

// ---------------------------------------------------------------- 渲染

function renderSources() {
  const label = { extension: '本机扩展库', files: '本地文件', demo: '演示数据', paste: '粘贴内容', none: '还没有数据' }[state.source] || '—';
  if (state.source === 'none' && !IS_EXTENSION) {
    statusEl.textContent = '普通网页模式 · 只能导入文件（要读本机库请从扩展打开）';
    return;
  }
  statusEl.textContent = `${label} · ${state.items.length} 作品 · ${state.interactions.length} 行为 · ${state.cards.length} 名片`;
}

function renderReport() {
  if (!state.report) {
    reportEl.innerHTML = '<p class="hint">还没有导入。</p>';
    return;
  }
  const rows = (state.report.perFile || [])
    .slice(0, 14)
    .map((f) => {
      const detail = [f.items ? `${f.items} 作品` : '', f.cards ? `${f.cards} 名片` : '', f.interactions && !f.items ? `${f.interactions} 行为` : '']
        .filter(Boolean)
        .join(' · ');
      return `<div class="report-row">
        <span class="tag-pill ${f.ok ? 'ok' : 'bad'}">${f.ok ? esc(f.format) : '跳过'}</span>
        <span class="report-name" title="${esc(f.name)}">${esc(f.name || '粘贴内容')}</span>
        <span class="report-meta">${esc(detail || '—')}</span>
      </div>`;
    })
    .join('');
  const more = state.report.perFile.length > 14 ? `<p class="hint">…另有 ${state.report.perFile.length - 14} 个文件</p>` : '';
  const warnCount = state.report.totalWarnings || 0;
  reportEl.innerHTML = rows + more + (warnCount ? `<p class="hint">${warnCount} 条提示：部分行/字段被跳过</p>` : '');
}

function emptyPanel(text) {
  return `<div class="empty">${esc(text)}</div>`;
}

function render() {
  renderSources();
  renderReport();

  const p = state.profile;
  if (!p || p.itemCount === 0) {
    panelsEl.innerHTML = `<section class="panel wide">
      <h2>还没有数据</h2>
      <p class="sub">左边选一个入口：从本机扩展库读取，或把导出的文件直接拖进这个页面。</p>
      ${emptyPanel('支持：mirror 备份 JSON（可多选/整个文件夹）、名片文本 MC1.、你自己的 CSV')}
    </section>`;
    return;
  }

  const partitions = p.topPartitions.slice(0, 8).map((x) => [x.name, x.share]);
  const ups = p.topUps.slice(0, 10).map((u) => [u.name, u.share]);
  const health = {
    total: state.items.length,
    withCategory: state.items.filter((i) => i.category).length,
    withTags: state.items.filter((i) => Array.isArray(i.tags) && i.tags.length > 0).length,
    withUp: state.items.filter((i) => i.upId !== null && i.upId !== undefined).length,
  };
  const graph = tagGraph();

  // 数据够不够格做比较：不够就明确说，不给一个看起来很确定的分数。
  const myUsable = assessProfile(p);
  const cardRows = state.cards.map((c) => {
    const u = assessUsability(state.myCard, c);
    const s = scoreCards(state.myCard, c);
    return {
      card: c,
      usable: u.usable,
      reason: u.reason,
      score: s.score,
      parts: s.parts,
      band: band(s.score),
      explain: explainPair(state.myCard, c),
    };
  });
  const comparable = cardRows.filter((r) => r.usable && myUsable.usable);
  const sim = similarityMatrix(comparable.map((r) => r.card));
  const scatterPoints = comparable.map((r) => ({
    x: r.parts.tag ?? 0,
    y: r.parts.partition ?? 0,
    r: 5 + Math.sqrt(Number(r.card.c) || 50) / 3.2,
    label: `${r.card.n || '匿名'} ${pct(r.score)}`,
    color: BAND_COLOR[r.band.level],
  }));

  const cardsTable = cardRows.length
    ? cardRows
        .map(
          (r) => `<div class="cluster-row">
            <div class="cluster-head">
              <b>${esc(r.card.n || '匿名')}</b>
              <span style="color:${r.usable && myUsable.usable ? BAND_COLOR[r.band.level] : 'var(--muted)'}">
                ${r.usable && myUsable.usable ? `${esc(r.band.label)} · ${pct(r.score)}` : '数据不足'}
              </span>
            </div>
            ${
              r.usable && myUsable.usable
                ? `<div class="chips">
                    ${r.explain.sharedTags.slice(0, 6).map((t) => `<span class="chip">#${esc(t.name)}</span>`).join('') || '<span class="hint">没有共同标签</span>'}
                  </div>
                  <p class="hint">共同分区：${esc(r.explain.sharedPartitions.map((x) => x.name).join(' · ') || '无')}</p>`
                : `<p class="hint">${esc(r.reason || myUsable.reason || '数据不足')}</p>`
            }
          </div>`,
        )
        .join('')
    : emptyPanel('还没有别人的名片。把朋友发来的 MS1. 文本粘到左边，或拖一个 txt 进来。');

  const clusterHtml = state.derived?.clusters?.clusters?.length
    ? state.derived.clusters.clusters
        .map(
          (c) => `<div class="cluster-row">
            <div class="cluster-head"><b>${esc(c.label)}</b><span class="report-meta">${c.size} 条</span></div>
            <div class="chips">${c.tags.map((t) => `<span class="chip">#${esc(t)}</span>`).join('')}</div>
          </div>`,
        )
        .join('')
    : emptyPanel('数据太少，还没形成簇。');

  const upsHtml = state.derived?.ups?.length
    ? state.derived.ups
        .map(
          (u) => `<div class="report-row">
            <span class="report-name">${esc(u.name)}</span>
            <span class="report-meta">${u.count} 条 · 亲和 ${pct(u.affinity)}</span>
          </div>`,
        )
        .join('')
    : emptyPanel('暂无推荐');

  panelsEl.innerHTML = `
    <section class="panel wide">
      <div class="kpis">
        <div class="kpi"><b>${state.items.length}</b><span>作品</span></div>
        <div class="kpi"><b>${state.interactions.length}</b><span>行为</span></div>
        <div class="kpi"><b>${state.cards.length}</b><span>他人名片</span></div>
        <div class="kpi"><b>${pct(p.confidence)}</b><span>画像可信度</span></div>
      </div>
    </section>

    <section class="panel wide">
      <h2>数据体检</h2>
      <p class="sub">分区和标签是画像的两个主信号。这里显示你的记录里到底有多少条真的带这两个字段。</p>
      <div class="kpis">
        <div class="kpi"><b>${health.withCategory}</b><span>带分区</span></div>
        <div class="kpi"><b>${health.withTags}</b><span>带标签</span></div>
        <div class="kpi"><b>${health.withUp}</b><span>带 UP 主</span></div>
        <div class="kpi"><b>${health.total}</b><span>记录总数</span></div>
      </div>
      ${
        health.withCategory === 0
          ? `<p class="alert">
              <b>0 条带分区。</b>历史记录接口的 <code>tag_name</code> 现在返回空串，收藏接口本身不返回分区，
              所以"边浏览边采集"这条路永远采不到分区。<br>
              补救：打开任意视频页，插件会读出该视频的分区与标签（一次一个）；要一次补全全部记录，
              需要插件按需查询公开视频元数据 —— 这会打破"零联网"的承诺，需要你点头。
            </p>`
          : ''
      }
      ${health.withTags === 0 && health.withCategory > 0 ? '<p class="alert">有分区但没有标签：视频页的 Tags 没取到，多数是页面还没加载完就关掉了。</p>' : ''}
      ${!myUsable.usable ? `<p class="alert"><b>当前画像不参与比较：</b>${esc(myUsable.reason)}。低于门槛时算出来的分数没有统计意义，所以这里直接不给。</p>` : ''}
    </section>

    <section class="panel">
      <h2>常看 UP 主</h2>
      <p class="sub">这条不需要分区就能算 —— 只要记录里有 UP 主，画像现在就有效。</p>
      ${ups.length ? barChart(ups, { label: 'UP 主分布' }) : emptyPanel('连 UP 主都没有，这批数据太薄了')}
    </section>

    <section class="panel">
      <h2>数据完整度</h2>
      <p class="sub">分区与标签的覆盖比例，直接决定画像能不能用。</p>
      ${ring(p.coverage.category * 0.5 + p.coverage.tags * 0.5, { size: 150, text: '分区/标签', label: '完整度' })}
      <p class="hint">分区 ${pct(p.coverage.category)} · 标签 ${pct(p.coverage.tags)} · 集中度 ${pct(p.concentration)}</p>
    </section>

    <section class="panel">
      <h2>分区分布</h2>
      <p class="sub">来自视频详情页的精确分区；越靠上说明你越常泡在这里。</p>
      ${partitions.length ? barChart(partitions, { label: '分区分布' }) : emptyPanel('这批记录没有分区字段')}
      ${partitions.length ? legend(partitions.map(([k, v]) => [k, pct(v)]), { maxItems: 6 }) : ''}
    </section>

    <section class="panel">
      <h2>分区构成</h2>
      <p class="sub">同一个数据换个形状看：各分区的占比。</p>
      ${partitions.length ? donut(partitions, { size: 200, label: '分区构成' }) : emptyPanel('这批记录没有分区字段')}
    </section>

    <section class="panel wide">
      <h2>标签共现网络</h2>
      <p class="sub">${graph.nodes.length} 个高频标签、${graph.links.length} 条共现关系。线越粗，两个标签越常在同一个视频里一起出现 —— 这是你兴趣的"骨架"。</p>
      ${graph.nodes.length ? graphSvg(graph.nodes, graph.links, { label: '标签共现网络', width: 900, height: 420 }) : emptyPanel('这批记录没有标签，共现网络无从谈起')}
    </section>

    <section class="panel wide">
      <h2>双人相似度矩阵</h2>
      <p class="sub">对角线为 1（自己与自己）。颜色越亮，兴趣越接近；鼠标悬停可看具体数值。</p>
      ${
        sim.people.length >= 2
          ? `<div style="display:flex;justify-content:center">${heatmap(sim.matrix, sim.labels, { label: '相似度矩阵', cell: 56 })}</div>`
          : emptyPanel(
              state.cards.length
                ? '有名片，但双方数据都不够厚，比较没有意义'
                : '还没有别人的名片。把朋友发来的 MS1. 文本粘到左边，这里就会出现矩阵。',
            )
      }
    </section>

    <section class="panel">
      <h2>谁和你同频</h2>
      <p class="sub">横轴：标签相似度。纵轴：分区相似度。气泡越大，对方收藏量级越大。</p>
      ${
        scatterPoints.length
          ? scatter(scatterPoints, { xLabel: '标签相似度', yLabel: '分区相似度', label: '相似度分布' })
          : emptyPanel('导入名片、且双方数据都够厚之后，这里会画出每个人的位置。')
      }
    </section>

    <section class="panel">
      <h2>名片明细</h2>
      <p class="sub">按相似度排序，并给出"为什么像"。</p>
      <div class="cluster-list">${cardsTable}</div>
    </section>

    <section class="panel">
      <h2>兴趣簇</h2>
      <p class="sub">自动聚出来的若干条兴趣线，也是名片标签的来源。</p>
      <div class="cluster-list">${clusterHtml}</div>
    </section>

    <section class="panel">
      <h2>活跃时段</h2>
      <p class="sub">按本地时间统计。</p>
      ${columnChart(p.timeHist, { label: '活跃时段' })}
    </section>

    <section class="panel">
      <h2>值得多看几眼</h2>
      <p class="sub">亲和度高、但你还没大量消费的 UP 主。</p>
      ${upsHtml}
    </section>
  `;
}

// ---------------------------------------------------------------- 动作

function toast(message, kind = 'ok') {
  toastEl.textContent = message;
  toastEl.className = `toast ${kind}`;
  toastEl.hidden = false;
  clearTimeout(toast._t);
  toast._t = setTimeout(() => {
    toastEl.hidden = true;
  }, 2800);
}

function applyReport(result, source) {
  mergeIncoming(result);
  state.report = result;
  state.source = source;
  recompute();
  render();
  const okCount = result.perFile.filter((f) => f.ok).length;
  toast(`已解析 ${okCount}/${result.perFile.length} 个文件`);
}

const SUPPORTED = /\.(json|txt|csv)$/i;
const MAX_FILES = 300;

async function ingestFileList(fileList) {
  const files = [...(fileList || [])].filter((f) => SUPPORTED.test(f.name));
  if (files.length === 0) {
    toast('没有可解析的文件（支持 .json / .txt / .csv）', 'warn');
    return;
  }
  const slice = files.slice(0, MAX_FILES);
  const payloads = [];
  for (const f of slice) {
    try {
      payloads.push({ name: f.name, text: await f.text() });
    } catch (err) {
      payloads.push({ name: f.name, text: '' });
    }
  }
  applyReport(ingestFiles(payloads), 'files');
  if (files.length > MAX_FILES) toast(`文件过多，只处理了前 ${MAX_FILES} 个`, 'warn');
}

async function loadFromDb() {
  try {
    const [items, interactions, cards] = await Promise.all([
      getAll(STORE.items),
      getAll(STORE.interactions),
      getAll(STORE.cards),
    ]);
    if (items.length === 0) {
      toast(
        IS_EXTENSION
          ? '本机库里还没有数据：先去 B 站正常浏览，或加载演示数据'
          : '普通网页读不到扩展的库：请从扩展里打开大屏，或把备份文件拖进来',
        'warn',
      );
      return;
    }
    mergeIncoming({ items, interactions, cards: cards.map((r) => r.card).filter(Boolean) });
    state.source = 'extension';
    state.report = {
      perFile: [{ name: '本机扩展库', format: 'indexeddb', ok: true, items: items.length, interactions: interactions.length, cards: cards.length }],
      totalWarnings: 0,
    };
    recompute();
    render();
    toast(`已读取 ${items.length} 条作品`);
  } catch (err) {
    toast('读取本机库失败：' + (err?.message || err), 'warn');
  }
}

function loadDemo() {
  const demo = makeDemo();
  mergeIncoming(demo);
  state.source = 'demo';
  state.report = {
    perFile: [{ name: '内置演示数据', format: 'demo', ok: true, items: demo.items.length, interactions: demo.interactions.length, cards: demo.cards.length }],
    totalWarnings: 0,
  };
  recompute();
  render();
  toast('已加载演示数据');
}

document.addEventListener('click', async (event) => {
  const el = event.target.closest('[data-action]');
  if (!el || el.tagName === 'INPUT') return;
  const action = el.dataset.action;
  if (action === 'pick-files') return; // 交给 change
  event.preventDefault();
  try {
    if (action === 'load-db') await loadFromDb();
    else if (action === 'load-demo') loadDemo();
    else if (action === 'paste') {
      const ta = document.querySelector('[data-role="paste"]');
      const text = ta?.value || '';
      if (!text.trim()) {
        toast('先粘贴点内容', 'warn');
        return;
      }
      applyReport(ingestFiles([{ name: '粘贴内容', text }]), 'paste');
      if (ta) ta.value = '';
    }
  } catch (err) {
    toast('出错了：' + (err?.message || err), 'warn');
  }
});

document.addEventListener('change', (event) => {
  const el = event.target;
  if (!el?.dataset?.action) return;
  if (el.dataset.action === 'pick-files') {
    ingestFileList(el.files).catch((err) => toast('解析失败：' + (err?.message || err), 'warn'));
    el.value = '';
  }
});

let dragDepth = 0;
window.addEventListener('dragenter', (e) => {
  if (!e.dataTransfer?.types?.includes('Files')) return;
  e.preventDefault();
  dragDepth += 1;
  dropEl.hidden = false;
});
window.addEventListener('dragover', (e) => {
  if (e.dataTransfer?.types?.includes('Files')) e.preventDefault();
});
window.addEventListener('dragleave', () => {
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) dropEl.hidden = true;
});
window.addEventListener('drop', (e) => {
  if (!e.dataTransfer?.files?.length) return;
  e.preventDefault();
  dragDepth = 0;
  dropEl.hidden = true;
  ingestFileList(e.dataTransfer.files).catch((err) => toast('解析失败：' + (err?.message || err), 'warn'));
});

// ---------------------------------------------------------------- 启动

(async function init() {
  recompute();
  render();
  // 扩展页面里同一个 IndexedDB 可以直接读；普通网页里读到的会是空库。
  try {
    const items = await getAll(STORE.items);
    if (items.length > 0) await loadFromDb();
  } catch {
    /* 独立打开时没有库，忽略 */
  }
})();
