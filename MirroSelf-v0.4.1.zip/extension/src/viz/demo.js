/**
 * 页面内置的演示数据生成器。
 *
 * 用途：让可视化大屏在"空手打开"时也有东西可看。生成的三个虚拟用户
 * 兴趣刻意设计成「装机 × 游戏」有交集、「装机 × 混音」几乎无关。
 * 全部是本地生成的假数据，不含任何真实用户信息。
 */

import { mulberry32, seedFromString } from '../core/random.js';
import { buildProfile } from '../core/profile.js';
import { buildCard } from '../core/card.js';

const SUFFIX = ['横评', '怎么选', '实测', '避坑', '入门', '拆解', '对比'];

const PERSONAS = [
  {
    key: 'hardware',
    nickname: '装机党',
    topics: [
      ['显卡', '科技', ['显卡', '装机', '硬件']],
      ['CPU', '科技', ['CPU', '装机', '硬件']],
      ['水冷', '科技', ['散热', '水冷', '装机']],
      ['机箱', '科技', ['机箱', '装机', '颜值']],
      ['超频', '科技', ['超频', '硬件', '折腾']],
      ['显示器', '科技', ['显示器', '装机', '色彩']],
      ['数码开箱', '生活', ['数码', '开箱', '生活']],
      ['行业资讯', '资讯', ['科技资讯', '行业', '数码']],
    ],
    ups: ['硬件茶谈', '老张装机', '超频实验室'],
    count: 26,
  },
  {
    key: 'game',
    nickname: '游戏人',
    topics: [
      ['显卡游戏实测', '科技', ['显卡', '游戏', '硬件']],
      ['游戏本', '科技', ['显卡', '游戏', '笔记本']],
      ['单机大作', '游戏', ['单机', '游戏', '实况']],
      ['独立游戏', '游戏', ['独立游戏', '游戏', '推荐']],
      ['电竞', '游戏', ['电竞', '游戏', '赛事']],
      ['帧数优化', '科技', ['优化', '游戏', '显卡']],
    ],
    ups: ['老番茄', '笔吧评测', '优化君'],
    count: 22,
  },
  {
    key: 'music',
    nickname: '混音师',
    topics: [
      ['人声混音', '音乐', ['混音', '人声', '音乐制作']],
      ['编曲', '音乐', ['编曲', '和声', '音乐制作']],
      ['母带', '音乐', ['母带', '响度', '音乐制作']],
      ['声卡', '音乐', ['声卡', '硬件', '录音']],
      ['监听耳机', '音乐', ['监听', '耳机', '录音']],
    ],
    ups: ['音频老炮', '编曲工坊'],
    count: 18,
  },
];

const ALNUM = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

function makeBvid(rng) {
  let s = 'BV1';
  for (let i = 0; i < 9; i += 1) s += ALNUM[Math.floor(rng() * ALNUM.length)];
  return s;
}

function generate(def) {
  const rng = mulberry32(seedFromString('viz-demo-' + def.key));
  const items = [];
  const interactions = [];
  for (let i = 0; i < def.count; i += 1) {
    const [name, category, tags] = def.topics[Math.floor(rng() * def.topics.length)];
    const suffix = SUFFIX[Math.floor(rng() * SUFFIX.length)];
    const up = def.ups[Math.floor(rng() * def.ups.length)];
    const itemId = makeBvid(rng);
    items.push({
      itemId,
      platform: 'bilibili',
      title: `${name}${suffix}`,
      category,
      categoryConfidence: 1,
      tags: tags.slice(),
      upId: 1000 + def.ups.indexOf(up),
      upName: up,
      pubdate: null,
      updatedAt: Date.now(),
    });
    const roll = rng();
    interactions.push({
      itemId,
      action: roll > 0.9 ? 'history' : roll > 0.8 ? 'like' : 'fav',
      ts: 1750000000 + Math.floor(rng() * 12000000),
    });
  }
  return { nickname: def.nickname, items, interactions };
}

export function makeDemo() {
  const people = PERSONAS.map(generate);
  const me = people[0];
  const cards = people.slice(1).map((p) => {
    const profile = buildProfile(p);
    return buildCard(profile, { nickname: p.nickname, highlightTags: profile.topTags.slice(0, 4).map((t) => t.name), seed: 20260101 });
  });
  return { items: me.items, interactions: me.interactions, cards, nickname: me.nickname };
}
