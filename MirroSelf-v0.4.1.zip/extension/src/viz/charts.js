/**
 * 手写 SVG 图表（纯函数，无依赖、无 Canvas、离线可用）。
 *
 * 为什么不用图表库：这个项目要能"打开就能跑"，引一个 100KB 的库只为了画几根柱子，
 * 代价是供应链与审核风险。这里每个图都是确定性的字符串拼接，还能被单测钉住。
 */

import { mulberry32 } from '../core/random.js';

export const PALETTE = ['#6ea8fe', '#a78bfa', '#f472b6', '#fbbf24', '#4ade80', '#22d3ee', '#fb923c', '#94a3b8'];

const esc = (s) =>
  String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

const num = (v, fallback = 0) => (Number.isFinite(Number(v)) ? Number(v) : fallback);

function truncate(s, n) {
  const str = String(s ?? '');
  return str.length > n ? str.slice(0, n - 1) + '…' : str;
}

function wrap(width, height, inner, label) {
  // 同时给 viewBox 与 width/height：前者保证缩放，后者给浏览器一个固有尺寸，
  // 否则在小 viewBox + CSS width:100% 的组合下会被拉伸成巨型图表。
  return `<svg viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" preserveAspectRatio="xMidYMid meet" role="img" aria-label="${esc(label || '图表')}">${inner}</svg>`;
}

function colorAt(i) {
  return PALETTE[i % PALETTE.length];
}

// ---------------------------------------------------------------- 条形图

export function barChart(entries, { width = 560, height = 240, maxItems = 10, label = '分布' } = {}) {
  const rows = (entries || []).slice(0, maxItems).map(([k, v]) => [String(k), num(v)]);
  if (rows.length === 0) return wrap(width, height, `<text x="12" y="24" fill="#8b95a7" font-size="12">暂无数据</text>`, label);

  const padLeft = 118;
  const padRight = 52;
  const rowH = Math.min(26, (height - 16) / rows.length);
  const max = Math.max(...rows.map(([, v]) => v), 1e-9);
  const barMax = width - padLeft - padRight;

  const inner = rows
    .map(([k, v], i) => {
      const y = 10 + i * rowH;
      const w = Math.max(2, (v / max) * barMax);
      return `<g>
        <text x="0" y="${y + rowH * 0.62}" fill="#aab3c2" font-size="11">${esc(truncate(k, 14))}</text>
        <rect x="${padLeft}" y="${y + 4}" width="${barMax}" height="${rowH - 10}" rx="4" fill="rgba(255,255,255,0.04)"/>
        <rect x="${padLeft}" y="${y + 4}" width="${w}" height="${rowH - 10}" rx="4" fill="${colorAt(i)}" opacity="0.85"/>
        <text x="${width - 6}" y="${y + rowH * 0.62}" fill="#8b95a7" font-size="10" text-anchor="end">${(v * 100).toFixed(0)}%</text>
      </g>`;
    })
    .join('');

  return wrap(width, height, inner, label);
}

// ---------------------------------------------------------------- 环形图

export function donut(entries, { size = 200, label = '占比' } = {}) {
  const rows = (entries || []).filter(([, v]) => num(v) > 0).slice(0, 8);
  const total = rows.reduce((s, [, v]) => s + num(v), 0);
  if (rows.length === 0 || total <= 0) {
    return wrap(size, size, `<text x="${size / 2}" y="${size / 2}" fill="#8b95a7" font-size="12" text-anchor="middle">暂无数据</text>`, label);
  }
  const r = size / 2 - 16;
  const c = 2 * Math.PI * r;
  let acc = 0;
  const segs = rows
    .map(([k, v], i) => {
      const frac = num(v) / total;
      // 只有一段时不要留缺口，否则看起来像渲染 bug
      if (rows.length === 1) {
        return `<circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="${colorAt(0)}" stroke-width="18">
          <title>${esc(k)} 100%</title></circle>`;
      }
      const dash = Math.max(0.5, frac * c - 2);
      const seg = `<circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="${colorAt(i)}"
        stroke-width="18" stroke-dasharray="${dash} ${c - dash}" stroke-dashoffset="${-acc * c}"
        transform="rotate(-90 ${size / 2} ${size / 2})" stroke-linecap="butt">
        <title>${esc(k)} ${(frac * 100).toFixed(1)}%</title></circle>`;
      acc += frac;
      return seg;
    })
    .join('');
  return wrap(size, size, segs, label);
}

/** 完成度圆环（0..1）。 */
export function ring(ratio, { size = 132, label = '完成度', text = '' } = {}) {
  const v = Math.max(0, Math.min(1, num(ratio)));
  const r = size / 2 - 10;
  const c = 2 * Math.PI * r;
  const dash = v * c;
  const inner = `<circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="rgba(255,255,255,0.08)" stroke-width="10"/>
    <circle cx="${size / 2}" cy="${size / 2}" r="${r}" fill="none" stroke="#6ea8fe" stroke-width="10"
      stroke-dasharray="${dash} ${c - dash}" stroke-linecap="round" transform="rotate(-90 ${size / 2} ${size / 2})"/>
    <text x="${size / 2}" y="${size / 2 + 2}" fill="#e6e9ef" font-size="20" font-weight="600" text-anchor="middle">${(v * 100).toFixed(0)}%</text>
    <text x="${size / 2}" y="${size / 2 + 20}" fill="#8b95a7" font-size="10" text-anchor="middle">${esc(text)}</text>`;
  return wrap(size, size, inner, label);
}

// ---------------------------------------------------------------- 力导向图

/**
 * Fruchterman-Reingold 布局。确定性：同一个 seed 得到同一张图，便于测试与截图比对。
 */
export function forceLayout(nodes, links, { width = 620, height = 380, iterations = 260, seed = 7 } = {}) {
  const list = nodes || [];
  const n = list.length;
  if (n === 0) return [];
  const rng = mulberry32(seed);
  const pos = list.map(() => ({
    x: width / 2 + (rng() - 0.5) * width * 0.6,
    y: height / 2 + (rng() - 0.5) * height * 0.6,
  }));
  if (n === 1) return [{ x: width / 2, y: height / 2 }];

  const k = Math.sqrt((width * height) / n);
  const edges = (links || [])
    .filter((e) => e && typeof e === 'object')
    .map((e) => ({ s: Number(e.source), t: Number(e.target), w: num(e.weight, 1) }))
    .filter((e) => Number.isInteger(e.s) && Number.isInteger(e.t) && e.s !== e.t && e.s >= 0 && e.t >= 0 && e.s < n && e.t < n);

  for (let it = 0; it < iterations; it += 1) {
    const temp = ((1 - it / iterations) * Math.min(width, height)) / 8 + 0.4;
    const disp = new Array(n).fill(0).map(() => ({ x: 0, y: 0 }));

    for (let i = 0; i < n; i += 1) {
      for (let j = i + 1; j < n; j += 1) {
        let dx = pos[i].x - pos[j].x;
        let dy = pos[i].y - pos[j].y;
        let d2 = dx * dx + dy * dy;
        if (d2 < 0.01) {
          dx = (rng() - 0.5) * 0.5;
          dy = (rng() - 0.5) * 0.5;
          d2 = dx * dx + dy * dy + 0.01;
        }
        const f = (k * k) / d2;
        disp[i].x += dx * f;
        disp[i].y += dy * f;
        disp[j].x -= dx * f;
        disp[j].y -= dy * f;
      }
    }

    for (const e of edges) {
      const dx = pos[e.s].x - pos[e.t].x;
      const dy = pos[e.s].y - pos[e.t].y;
      const d = Math.sqrt(dx * dx + dy * dy) || 0.01;
      const f = (d * d) / k / Math.max(0.2, e.w);
      const ux = dx / d;
      const uy = dy / d;
      disp[e.s].x -= ux * f;
      disp[e.s].y -= uy * f;
      disp[e.t].x += ux * f;
      disp[e.t].y += uy * f;
    }

    for (let i = 0; i < n; i += 1) {
      const d = Math.sqrt(disp[i].x * disp[i].x + disp[i].y * disp[i].y) || 0.01;
      const lim = Math.min(d, temp) / d;
      pos[i].x = Math.max(14, Math.min(width - 14, pos[i].x + disp[i].x * lim));
      pos[i].y = Math.max(14, Math.min(height - 14, pos[i].y + disp[i].y * lim));
    }
  }
  return pos;
}

export function graphSvg(nodes, links, opts = {}) {
  const { width = 620, height = 380, seed = 7, label = '关系图' } = opts;
  const list = nodes || [];
  if (list.length === 0) return wrap(width, height, `<text x="16" y="28" fill="#8b95a7" font-size="12">暂无数据</text>`, label);

  const pos = forceLayout(list, links, { width, height, seed });
  const maxW = Math.max(...list.map((nd) => num(nd.weight, 1)), 1e-9);

  const edgeSvg = (links || [])
    .map((e) => {
      const a = pos[Number(e.source)];
      const b = pos[Number(e.target)];
      if (!a || !b) return '';
      const op = Math.max(0.06, Math.min(0.5, num(e.weight, 1) / 10));
      return `<line x1="${a.x.toFixed(1)}" y1="${a.y.toFixed(1)}" x2="${b.x.toFixed(1)}" y2="${b.y.toFixed(1)}" stroke="#6ea8fe" stroke-width="${(0.6 + num(e.weight, 1) * 0.25).toFixed(1)}" opacity="${op.toFixed(2)}"/>`;
    })
    .join('');

  const nodeSvg = list
    .map((nd, i) => {
      const p = pos[i];
      const r = 5 + (num(nd.weight, 1) / maxW) * 11;
      return `<g><circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="${r.toFixed(1)}" fill="${colorAt(i)}" opacity="0.82">
        <title>${esc(nd.label)}（权重 ${num(nd.weight).toFixed(1)}）</title></circle>
        <text x="${p.x.toFixed(1)}" y="${(p.y + r + 11).toFixed(1)}" fill="#aab3c2" font-size="10" text-anchor="middle">${esc(truncate(nd.label, 10))}</text></g>`;
    })
    .join('');

  return wrap(width, height, edgeSvg + nodeSvg, label);
}

// ---------------------------------------------------------------- 热力图

function lerpColor(a, b, t) {
  const pa = [parseInt(a.slice(1, 3), 16), parseInt(a.slice(3, 5), 16), parseInt(a.slice(5, 7), 16)];
  const pb = [parseInt(b.slice(1, 3), 16), parseInt(b.slice(3, 5), 16), parseInt(b.slice(5, 7), 16)];
  const mix = pa.map((v, i) => Math.round(v + (pb[i] - v) * Math.max(0, Math.min(1, t))));
  return `#${mix.map((v) => v.toString(16).padStart(2, '0')).join('')}`;
}

/** 相似度矩阵。matrix[i][j] ∈ 0..1，diagonal 为 1。 */
export function heatmap(matrix, labels, { cell = 34, gap = 2, label = '相似度矩阵' } = {}) {
  const n = (labels || []).length;
  const pad = 76;
  const width = pad + n * (cell + gap) + 8;
  const height = pad + n * (cell + gap) + 8;
  if (n === 0) return wrap(320, 120, `<text x="16" y="28" fill="#8b95a7" font-size="12">暂无数据</text>`, label);

  let inner = '';
  for (let j = 0; j < n; j += 1) {
    inner += `<text x="${pad - 8}" y="${pad + j * (cell + gap) + cell * 0.68}" fill="#8b95a7" font-size="10" text-anchor="end">${esc(truncate(labels[j], 6))}</text>`;
    inner += `<text x="${pad + j * (cell + gap) + cell / 2}" y="${pad - 10}" fill="#8b95a7" font-size="10" text-anchor="middle">${esc(truncate(labels[j], 4))}</text>`;
  }
  for (let i = 0; i < n; i += 1) {
    for (let j = 0; j < n; j += 1) {
      const v = Math.max(0, Math.min(1, num(matrix?.[i]?.[j], 0)));
      const fill = i === j ? '#334155' : lerpColor('#131a24', '#6ea8fe', v);
      inner += `<rect x="${pad + j * (cell + gap)}" y="${pad + i * (cell + gap)}" width="${cell}" height="${cell}" rx="4" fill="${fill}">
        <title>${esc(labels[i])} × ${esc(labels[j])} = ${(v * 100).toFixed(1)}%</title></rect>`;
      if (i !== j && v > 0.01) {
        inner += `<text x="${pad + j * (cell + gap) + cell / 2}" y="${pad + i * (cell + gap) + cell * 0.64}" fill="#0b1020" font-size="9" text-anchor="middle" font-weight="600">${(v * 100).toFixed(0)}</text>`;
      }
    }
  }
  return wrap(width, height, inner, label);
}

// ---------------------------------------------------------------- 散点图

/** points: [{x, y, r, label, color}]，x/y ∈ 0..1 */
export function scatter(points, { width = 560, height = 300, xLabel = 'X', yLabel = 'Y', label = '散点图' } = {}) {
  const pts = (points || []).filter((p) => Number.isFinite(p.x) && Number.isFinite(p.y));
  const padL = 40;
  const padB = 26;
  const padT = 12;
  const padR = 12;
  const w = width - padL - padR;
  const h = height - padB - padT;

  let inner = `<rect x="${padL}" y="${padT}" width="${w}" height="${h}" fill="rgba(255,255,255,0.02)" rx="8"/>`;

  for (const t of [0, 0.25, 0.5, 0.75, 1]) {
    const y = padT + h * (1 - t);
    const x = padL + w * t;
    inner += `<line x1="${padL}" y1="${y.toFixed(1)}" x2="${padL + w}" y2="${y.toFixed(1)}" stroke="rgba(255,255,255,${t === 0 ? 0.12 : 0.05})"/>`;
    inner += `<line x1="${x.toFixed(1)}" y1="${padT}" x2="${x.toFixed(1)}" y2="${padT + h}" stroke="rgba(255,255,255,${t === 0 ? 0.12 : 0.05})"/>`;
    if (t % 0.5 === 0) {
      inner += `<text x="${(x - 6).toFixed(1)}" y="${height - 12}" fill="#6b7688" font-size="9" text-anchor="end">${Math.round(t * 100)}%</text>`;
      inner += `<text x="${padL - 6}" y="${(y + 3).toFixed(1)}" fill="#6b7688" font-size="9" text-anchor="end">${Math.round(t * 100)}%</text>`;
    }
  }

  inner += pts
    .map((p) => {
      const cx = padL + Math.max(0, Math.min(1, p.x)) * w;
      const cy = padT + (1 - Math.max(0, Math.min(1, p.y))) * h;
      const r = Math.max(6, Math.min(20, num(p.r, 8)));
      return `<g><circle cx="${cx.toFixed(1)}" cy="${cy.toFixed(1)}" r="${r.toFixed(1)}" fill="${p.color || '#6ea8fe'}" opacity="0.8" stroke="rgba(255,255,255,0.35)">
        <title>${esc(p.label)}</title></circle>
        <text x="${cx.toFixed(1)}" y="${(cy - r - 6).toFixed(1)}" fill="#cbd5e1" font-size="10" text-anchor="middle">${esc(truncate(p.label, 9))}</text></g>`;
    })
    .join('');

  return wrap(width, height, inner, label || `${xLabel} / ${yLabel}`);
}

// ---------------------------------------------------------------- 柱状（时段）

export function columnChart(values, { width = 560, height = 140, label = '时段分布' } = {}) {
  const list = (values || []).map((v) => Math.max(0, num(v)));
  if (list.length === 0) return wrap(width, height, `<text x="12" y="24" fill="#8b95a7" font-size="12">暂无数据</text>`, label);
  const max = Math.max(...list, 1e-9);
  const n = list.length;
  const gap = 3;
  const bw = (width - gap * (n - 1)) / n;
  const inner = list
    .map((v, i) => {
      const hgt = Math.max(2, (v / max) * (height - 26));
      const x = i * (bw + gap);
      const y = height - 18 - hgt;
      return `<g><rect x="${x.toFixed(1)}" y="${y.toFixed(1)}" width="${bw.toFixed(1)}" height="${hgt.toFixed(1)}" rx="2" fill="#6ea8fe" opacity="${(0.35 + (v / max) * 0.6).toFixed(2)}">
        <title>${i}:00 — ${(v * 100).toFixed(1)}%</title></rect>
        ${i % 6 === 0 ? `<text x="${(x + bw / 2).toFixed(1)}" y="${height - 4}" fill="#8b95a7" font-size="9" text-anchor="middle">${i}</text>` : ''}</g>`;
    })
    .join('');
  return wrap(width, height, inner, label);
}

// ---------------------------------------------------------------- 图例

export function legend(entries, { maxItems = 8 } = {}) {
  return `<div class="legend">${(entries || [])
    .slice(0, maxItems)
    .map(([k, v], i) => `<span class="legend-item"><i style="background:${colorAt(i)}"></i>${esc(k)}<b>${esc(v)}</b></span>`)
    .join('')}</div>`;
}
