/**
 * 批量导入解析（纯函数，可在 Node 中单测）。
 *
 * ── 允许读什么，不允许读什么 ─────────────────────────────
 * 允许（批量）：
 *   · 用户自己导出的备份文件（mirror-export JSON，可多个/整个文件夹）
 *   · 用户本机扩展库里自己的数据
 *   · 他人**主动**给过来的兴趣名片（MS1. 文本，可一次多张）
 *   · 用户自己整理的 CSV（自己平台的历史/收藏导出）
 * 不允许：
 *   · 按 UID / 昵称批量拉取任何人的资料
 *   · 抓取他人的点赞、收藏、关注名单
 *
 * 本文件不含任何网络能力，只吃字符串。
 */

import { normalizeItem, mergeItem } from '../core/merge.js';
import { decodeCard } from '../core/card.js';

export const FORMATS = Object.freeze({
  BACKUP: 'backup',
  CARDS: 'cards',
  CSV: 'csv',
  UNKNOWN: 'unknown',
});

/** 名片是一段无空白的 base64url，因此可以直接用正则从任意文本里捞出来。 */
const CARD_BODY_RE = /^(?:MS1|MC1)\.[A-Za-z0-9_-]+/;
const CARD_PREFIXES = ['MS1.', 'MC1.'];

export function extractCards(text) {
  const cards = [];
  const warnings = [];
  const seen = new Set();
  const raw = String(text || '');

  // 不能用全局贪婪正则：两张卡片首尾相接时，"MS1" 这几个字符本身也在
  // base64 字符集里，贪婪匹配会把下一张的开头一起吞掉。所以先按出现位置切片。
  const starts = [];
  for (const prefix of CARD_PREFIXES) {
    let cursor = raw.indexOf(prefix);
    while (cursor !== -1) {
      starts.push(cursor);
      cursor = raw.indexOf(prefix, cursor + 1);
    }
  }
  starts.sort((a, b) => a - b);

  for (let i = 0; i < starts.length; i += 1) {
    const end = i + 1 < starts.length ? starts[i + 1] : raw.length;
    const segment = raw.slice(starts[i], end).trim();
    const m = segment.match(CARD_BODY_RE);
    if (!m) continue;
    try {
      const card = decodeCard(m[0]);
      if (!seen.has(card.id)) {
        seen.add(card.id);
        cards.push(card);
      }
    } catch (err) {
      warnings.push('名片解析失败：' + (err?.message || err));
    }
  }
  return { cards, warnings };
}

export function parseBackup(json) {
  const out = { items: [], interactions: [], cards: [], warnings: [] };
  const list = Array.isArray(json) ? json : [json];
  for (const doc of list) {
    if (!doc || typeof doc !== 'object') {
      out.warnings.push('备份里有一项不是对象，已跳过');
      continue;
    }
    if (Array.isArray(doc.items)) {
      for (const raw of doc.items) {
        const item = normalizeItem(raw);
        if (item) out.items.push(item);
        else out.warnings.push('作品缺少 itemId，已跳过');
      }
    }
    if (Array.isArray(doc.interactions)) {
      for (const raw of doc.interactions) {
        if (!raw || typeof raw.itemId !== 'string' || !raw.itemId) continue;
        out.interactions.push({
          itemId: raw.itemId,
          action: raw.action || 'fav',
          weight: Number.isFinite(Number(raw.weight)) ? Number(raw.weight) : null,
          ts: Number.isFinite(Number(raw.ts)) ? Number(raw.ts) : null,
        });
      }
    }
    if (Array.isArray(doc.cards)) {
      for (const raw of doc.cards) {
        const card = raw?.card || raw;
        if (card && typeof card === 'object' && typeof card.id === 'string') out.cards.push(card);
      }
    }
    if (typeof doc.format === 'string' && doc.format !== 'mirror-export') {
      out.warnings.push(`未知的备份格式 ${doc.format}，已尽力解析`);
    }
  }
  return out;
}

const HEADER_ALIASES = {
  itemId: ['itemid', 'item_id', 'bvid', 'bv', 'id', 'aid', '视频id'],
  title: ['title', 'name', '标题', '名称'],
  category: ['category', 'tname', 'partition', '分区', '分类'],
  tags: ['tags', 'tag', '标签'],
  action: ['action', '行为', 'type'],
  upId: ['upid', 'mid', 'author_mid', 'up主id'],
  upName: ['upname', 'author_name', 'author', 'up主', 'up'],
  ts: ['ts', 'time', 'view_at', 'fav_time', '时间'],
};

function splitLine(line, delim) {
  const out = [];
  let cur = '';
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i];
    if (ch === '"') {
      if (quoted && line[i + 1] === '"') {
        cur += '"';
        i += 1;
      } else {
        quoted = !quoted;
      }
      continue;
    }
    if (!quoted && ch === delim) {
      out.push(cur);
      cur = '';
      continue;
    }
    cur += ch;
  }
  out.push(cur);
  return out.map((s) => s.trim());
}

export function parseCsv(text) {
  const out = { items: [], interactions: [], warnings: [] };
  const lines = String(text || '')
    .split(/\r?\n/)
    .filter((l) => l.trim());
  if (lines.length < 2) {
    out.warnings.push('CSV 至少需要表头 + 一行数据');
    return out;
  }
  const delim = lines[0].includes('\t') ? '\t' : ',';
  const header = splitLine(lines[0], delim).map((h) => h.toLowerCase().trim());

  const index = {};
  for (const [field, aliases] of Object.entries(HEADER_ALIASES)) {
    const at = header.findIndex((h) => aliases.includes(h));
    if (at >= 0) index[field] = at;
  }
  if (index.itemId === undefined) {
    out.warnings.push('CSV 缺少 itemId / bvid 列');
    return out;
  }

  let skipped = 0;
  for (const line of lines.slice(1)) {
    const cols = splitLine(line, delim);
    const itemId = (cols[index.itemId] || '').trim();
    if (!itemId) {
      skipped += 1;
      continue;
    }
    const tagsRaw = index.tags !== undefined ? cols[index.tags] || '' : '';
    const item = normalizeItem({
      itemId,
      title: index.title !== undefined ? cols[index.title] : '',
      category: index.category !== undefined ? cols[index.category] : null,
      categoryConfidence: index.category !== undefined ? 0.6 : 0,
      tags: tagsRaw ? tagsRaw.split(/[|;、,，/\s]+/).filter(Boolean) : [],
      upId: index.upId !== undefined ? Number(cols[index.upId]) || null : null,
      upName: index.upName !== undefined ? cols[index.upName] : '',
    });
    if (item) out.items.push(item);

    const action = index.action !== undefined ? (cols[index.action] || '').toLowerCase() : '';
    out.interactions.push({
      itemId,
      action: ['fav', 'like', 'coin', 'history', 'watch'].includes(action) ? action : 'history',
      weight: null,
      ts: index.ts !== undefined ? Number(cols[index.ts]) || null : null,
    });
  }
  if (skipped > 0) out.warnings.push(`有 ${skipped} 行缺少 itemId，已跳过`);
  return out;
}

/**
 * 解析单个文件。
 * @param {{name?: string, text?: string}} file
 */
export function parseFile({ name = '', text = '' } = {}) {
  const report = {
    name,
    format: FORMATS.UNKNOWN,
    items: [],
    interactions: [],
    cards: [],
    warnings: [],
    ok: false,
  };
  const raw = String(text || '');
  const trimmed = raw.trim();
  if (!trimmed) {
    report.warnings.push('文件为空');
    return report;
  }

  if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
    let json = null;
    try {
      json = JSON.parse(trimmed);
    } catch {
      report.warnings.push('JSON 解析失败，内容可能被截断');
    }
    if (json) {
      const parsed = parseBackup(json);
      if (parsed.items.length || parsed.interactions.length || parsed.cards.length) {
        report.format = FORMATS.BACKUP;
        report.items = parsed.items;
        report.interactions = parsed.interactions;
        report.cards = parsed.cards;
        report.ok = true;
        report.warnings.push(...parsed.warnings);
        return report;
      }
      report.warnings.push(...parsed.warnings);
    }
  }

  const cardRes = extractCards(raw);
  if (cardRes.cards.length > 0) {
    report.format = FORMATS.CARDS;
    report.cards = cardRes.cards;
    report.ok = true;
    report.warnings.push(...cardRes.warnings);
    return report;
  }

  if (trimmed.includes(',') && /\n/.test(trimmed)) {
    const csv = parseCsv(trimmed);
    if (csv.items.length > 0) {
      report.format = FORMATS.CSV;
      report.items = csv.items;
      report.interactions = csv.interactions;
      report.ok = true;
      report.warnings.push(...csv.warnings);
      return report;
    }
    report.warnings.push(...csv.warnings);
  }

  report.warnings.push('无法识别的格式（支持 mirror 备份 JSON / 名片文本 MS1. / CSV）');
  return report;
}

/** 把多个文件的解析结果合并成一份，并给出逐文件报告。 */
export function mergeReports(reports) {
  const itemMap = new Map();
  const interMap = new Map();
  const cardMap = new Map();
  const perFile = [];

  for (const r of reports || []) {
    for (const item of r.items || []) {
      itemMap.set(item.itemId, mergeItem(itemMap.get(item.itemId), item));
    }
    for (const rec of r.interactions || []) {
      const key = `${rec.itemId}|${rec.action}`;
      const prev = interMap.get(key);
      const w = Number(rec.weight ?? 0);
      if (!prev || w > Number(prev.weight ?? 0)) interMap.set(key, rec);
    }
    for (const card of r.cards || []) {
      if (card && typeof card.id === 'string') cardMap.set(card.id, card);
    }
    perFile.push({
      name: r.name,
      format: r.format,
      ok: r.ok,
      items: (r.items || []).length,
      interactions: (r.interactions || []).length,
      cards: (r.cards || []).length,
      warnings: r.warnings || [],
    });
  }

  return {
    items: [...itemMap.values()],
    interactions: [...interMap.values()],
    cards: [...cardMap.values()],
    perFile,
    totalWarnings: perFile.reduce((n, f) => n + f.warnings.length, 0),
  };
}

/** 批量：多个 {name, text} → 一份合并结果。 */
export function ingestFiles(files) {
  return mergeReports((files || []).map((f) => parseFile(f)));
}
