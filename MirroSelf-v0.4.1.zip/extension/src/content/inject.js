/**
 * 页面主世界观察器（MAIN world，`document_start` 注入）。
 *
 * 它做的事只有一件：**旁听页面自己已经发出的请求**。
 * 不构造请求、不改请求头、不读写 Cookie、不调用任何签名接口。
 * 这也是本项目和"爬虫"的分界线，请勿在此文件里加任何网络能力。
 *
 * 与 isolate 世界的 collector.js 通过 window.postMessage 通信。
 */

(() => {
  'use strict';

  const MARK = 'mirroself-v1';
  const MAX_BUFFER = 200;
  const MAX_BODY = 400000;
  const MAX_EVENTS_REPLAY = 60;

  /**
   * 每次页面加载生成一个随机 nonce，写进 DOM 属性共享给隔离世界。
   * 它抬高了"页面脚本随手 postMessage 一段伪造响应"的门槛；
   * 但挡不住同页面里的恶意脚本（同一份 DOM 它也能读）—— 这一残余风险
   * 记录在 docs/合规说明.md，不假装已经解决。
   */
  const NONCE = (() => {
    try {
      const b = new Uint8Array(8);
      crypto.getRandomValues(b);
      return Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('');
    } catch {
      return String(Math.random()).slice(2, 12);
    }
  })();
  try {
    document.documentElement.setAttribute('data-mirroself-n', NONCE);
  } catch {
    /* ignore */
  }

  // 与 constants.js 的 COLLECTORS 保持一致（compliance-check 会校验路径集合）。
  // kind 用来做"每个采集器一个开关"：事件带上来源类型，隔离世界据此决定要不要转发。
  const PATHS = [
    { path: '/x/v3/fav/resource/list', kind: 'favorites' },
    { path: '/x/web-interface/history/cursor', kind: 'history' },
    { path: '/x/v2/history', kind: 'history' },
    { path: '/x/web-interface/view/detail', kind: 'video' },
    { path: '/x/web-interface/view', kind: 'video' },
    { path: '/x/polymer/web-space/seasons_archives_list', kind: 'series' },
    { path: '/pgc/view/web/season', kind: 'bangumi' },
    { path: '/x/space/bangumi/follow/list', kind: 'bangumi' },
  ];
  const PATH_KINDS = new Map(PATHS.map((p) => [p.path, p.kind]));

  // 视频页是 SSR 的，分区与标签写在内联的 __INITIAL_STATE__ 里，
  // 页面不会去请求 /x/web-interface/view。所以这里补一条"页面状态"通道，
  // 用一个私有协议名发出，解析层把它当详情接口处理。
  const PAGE_STATE_URL = 'mirroself://page-state/video';
  const PAGE_DIAG_URL = 'mirroself://diag/video-page';
  // 另有一条 'mirroself://dom/favlist' 由隔离世界产生（用户手动的收藏夹 DOM 采集），
  // 主世界不参与，这里只登记路径以保持三处白名单一致。

  const buffer = [];
  let seq = 0;

  function kindOf(url) {
    if (typeof url !== 'string' || !url) return '';
    // 必须按 pathname 精确比对：观看心跳 POST /x/v2/history/report 里含有
    // /x/v2/history，用子串判断会把每一帧心跳都转发上去。
    let pathname;
    try {
      pathname = new URL(url, location.href).pathname;
    } catch {
      return '';
    }
    return PATH_KINDS.get(pathname) || '';
  }

  /**
   * 统一成绝对地址再往外发。
   *
   * space.bilibili.com 的页面会用 `/x/v3/fav/resource/list?...` 这种相对路径
   * 发请求；如果原样转发，隔离世界的域名白名单会把它当"非法来源"拒掉。
   * 解析只在这里做一次，后面所有比较和发送都用绝对地址。
   */
  function toAbsolute(url) {
    try {
      return new URL(url, location.href).href;
    } catch {
      return typeof url === 'string' ? url : '';
    }
  }

  function post(payload) {
    try {
      payload.__mirror = MARK;
      payload.n = NONCE;
      // 只用本页 origin；一旦失败就丢弃。
      // 曾经这里会退化成 '*'，那会把包含完整响应体的消息广播给跨域 iframe。
      window.postMessage(payload, location.origin);
    } catch {
      /* 丢弃，不退化 */
    }
  }

  function emit(url, text, kind) {
    if (typeof text !== 'string' || !text) return;
    if (text.length > MAX_BODY) text = text.slice(0, MAX_BODY);
    const event = { seq: (seq += 1), url: String(url), body: text };
    if (kind) event.kind = kind;
    buffer.push(event);
    if (buffer.length > MAX_BUFFER) buffer.shift();
    post({ type: 'response', event });
  }

  // ---- 目击记录：只记"这个页面请求过哪些 B 站接口"，不记内容 ----
  //
  // 存在的理由：当"收藏夹/历史采不到"时，光靠白名单猜是没用的。
  // 这份名单让自检能直接显示"页面确实请求了 X，但我们没采"，
  // 一眼看出是路径变了、还是旁听没生效。
  const sightings = new Map();
  const SIGHT_LIMIT = 300;

  function noteSighting(url) {
    try {
      const u = new URL(url, location.href);
      if (!/(^|\.)bilibili\.com$/i.test(u.hostname)) return;
      const key = u.pathname;
      sightings.set(key, (sightings.get(key) || 0) + 1);
      if (sightings.size > SIGHT_LIMIT) sightings.delete(sightings.keys().next().value);
    } catch {
      /* ignore */
    }
  }

  // ---- fetch 旁听 ----
  try {
    const originalFetch = window.fetch;
    if (typeof originalFetch === 'function') {
      window.fetch = function mirrorObservedFetch(input) {
        const promise = originalFetch.apply(this, arguments);
        try {
          const raw = typeof input === 'string' ? input : input && input.url ? input.url : '';
          const url = toAbsolute(raw);
          noteSighting(url);
          const kind = kindOf(url);
          if (kind) {
            promise
              .then((res) => {
                try {
                  const clone = res.clone();
                  clone
                    .text()
                    .then((text) => emit(url, text, kind))
                    .catch(() => {});
                } catch {
                  /* clone 失败就算了 */
                }
              })
              .catch(() => {});
          }
        } catch {
          /* 绝不影响页面自身请求 */
        }
        return promise;
      };
    }
  } catch {
    /* ignore */
  }

  // ---- XMLHttpRequest 旁听 ----
  try {
    const proto = XMLHttpRequest.prototype;
    const originalOpen = proto.open;
    const originalSend = proto.send;
    proto.open = function mirrorObservedOpen(method, url) {
      try {
        this.__mirrorUrl = toAbsolute(url);
        this.__mirrorKind = kindOf(this.__mirrorUrl);
        noteSighting(this.__mirrorUrl);
      } catch {
        /* ignore */
      }
      return originalOpen.apply(this, arguments);
    };
    proto.send = function mirrorObservedSend() {
      try {
        const kind = this.__mirrorKind;
        if (kind) {
          this.addEventListener('load', () => {
            try {
              // responseType 不是 '' / 'text' 时，读 responseText 会抛
              // InvalidStateError，结果就是"页面拿到了数据、我们一条没收到"。
              const rt = this.responseType;
              let text = null;
              if (!rt || rt === 'text') text = this.responseText;
              else if (rt === 'json') text = JSON.stringify(this.response);
              else if (rt === 'document') text = this.responseXML ? new XMLSerializer().serializeToString(this.responseXML) : null;
              // arraybuffer / blob 无法转成 JSON，直接放弃（这些也不是我们要的接口）
              if (typeof text === 'string' && text) emit(this.__mirrorUrl, text, kind);
            } catch {
              /* ignore */
            }
          });
        }
      } catch {
        /* ignore */
      }
      return originalSend.apply(this, arguments);
    };
  } catch {
    /* ignore */
  }

  // ---- 页面内联状态：视频页的分区与标签 ----
  const seenStates = new Set();

  function emitPageState() {
    try {
      const st = window.__INITIAL_STATE__;
      const vd = (st && (st.videoData || st.videoInfo || st.video)) || null;
      if (!vd || !vd.bvid) return false;
      if (seenStates.has(vd.bvid)) return false;

      const rawTags =
        (Array.isArray(st.tags) && st.tags) ||
        (Array.isArray(vd.tags) && vd.tags) ||
        (Array.isArray(st.videoTags) && st.videoTags) ||
        [];
      const Tags = [];
      for (const t of rawTags) {
        const name = typeof t === 'string' ? t : t && (t.tag_name || t.name);
        if (name) Tags.push({ tag_name: String(name) });
        if (Tags.length >= 16) break;
      }

      const payload = {
        code: 0,
        data: {
          View: {
            bvid: vd.bvid,
            aid: vd.aid,
            title: vd.title,
            tid: vd.tid,
            tname: vd.tname,
            pubdate: vd.pubdate,
            owner: vd.owner ? { mid: vd.owner.mid, name: vd.owner.name } : null,
          },
          Tags,
        },
      };
      emit(PAGE_STATE_URL, JSON.stringify(payload), 'video');
      seenStates.add(vd.bvid);
      return true;
    } catch {
      return false;
    }
  }

  function schedulePageState() {
    emitPageState();
    setTimeout(emitPageState, 1200);
    setTimeout(emitPageState, 4000);
    setTimeout(reportMissingState, 7000);
    setTimeout(reportMissingState, 12000);
  }

  /**
   * 诊断上报：页面里找不到可用的内联状态时，把线索发出去一次。
   *
   * 覆盖两类页面：
   *   /video/**       —— 视频页（分区/标签来源）
   *   /favlist        —— 收藏夹页（如果它也是 SSR，列表就不会走 XHR，
   *                      光看"未被采集的接口"是看不出来的）
   *
   * 只在"这个页面一条都没转发出去"时才报，避免正常页面刷噪音。
   */
  let diagSent = false;
  function reportMissingState() {
    if (diagSent || seenStates.size > 0) return;

    const path = location.pathname;
    const isVideo = /^\/video\//.test(path);
    const isFav = /\/favlist\/?$/.test(path);
    if (!isVideo && !isFav) return;
    if (isFav && buffer.length > 0) return; // 收藏页已经有数据在走，不用报

    diagSent = true;
    try {
      const st = window.__INITIAL_STATE__;
      const keys = st ? Object.keys(st).slice(0, 16) : [];
      emit(
        PAGE_DIAG_URL,
        JSON.stringify({
          code: 0,
          data: {
            kind: isVideo ? 'video' : 'favlist',
            href: location.href.slice(0, 120),
            hasState: !!st,
            keys,
            videoKeys: st && st.videoData ? Object.keys(st.videoData).slice(0, 16) : [],
            // 收藏页的内联状态通常挂在别的键上，把"像列表的键"一起带回去
            listishKeys: keys.filter((k) => /media|fav|list|archive|item/i.test(k)),
            forwarded: buffer.length,
          },
        }),
        'video',
      );
    } catch {
      /* ignore */
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', schedulePageState, { once: true });
  } else {
    schedulePageState();
  }
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') emitPageState();
  });

  // ---- 握手：isolate 世界可能先于或晚于本脚本就绪 ----
  window.addEventListener('message', (event) => {
    // 不要写 event.source !== window：隔离世界里的 Window 代理与主世界不是同一个对象，
    // 一旦不相等就会把所有消息静默丢掉。只在"明确来自别的窗口"时拒绝。
    if (event.source && event.source !== window) return;
    const data = event.data;
    if (!data || data.__mirror !== MARK) return;
    if (data.n !== NONCE) return;
    if (data.type === 'hello') {
      post({ type: 'replay', events: buffer.slice(-MAX_EVENTS_REPLAY) });
      return;
    }
    if (data.type === 'ask-sightings') {
      const list = [...sightings.entries()].sort((a, b) => b[1] - a[1]).slice(0, 24);
      post({ type: 'sightings', id: data.id, list });
    }
  });

  post({ type: 'ready' });
})();
