/**
 * 内容脚本（ISOLATED world）：把观察到的响应原样转交给后台。
 *
 * 它不做任何解析（解析在后台，可单测），也不做任何请求。
 * 唯一职责：校验来源 → 去重 → 转发。
 *
 * 校验来源有三层：
 *   1. 消息带本次页面加载的随机 nonce（由主世界写入 DOM 属性）；
 *   2. event.source 若明确指向别的窗口则拒绝；
 *   3. 负载形状 + 域名白名单的粗筛（后台还会再严格校验一次）。
 */

(() => {
  'use strict';

  const MARK = 'mirroself-v1';
  const INJECTED_AT = Date.now();
  const seen = new Set();
  let enabled = true;
  /** 每个采集器一个开关，默认全开；主开关 collectEnabled 仍然是否决项。 */
  let switches = {};
  let forwarded = 0;
  let lastForwardAt = 0;
  let sawInject = false;
  let rejected = 0;
  /** 最近被拒收的几条，供自检显示（原因比计数有用得多） */
  const recentRejects = [];

  function nonce() {
    try {
      return document.documentElement.getAttribute('data-mirroself-n') || '';
    } catch {
      return '';
    }
  }

  function applySettings(s) {
    const next = s || {};
    enabled = next.collectEnabled !== false;
    switches = next.collectors && typeof next.collectors === 'object' ? next.collectors : {};
  }

  function loadSetting() {
    try {
      const getting = chrome.storage.local.get('mirrorSettings');
      if (getting && typeof getting.then === 'function') {
        getting.then((got) => applySettings((got && got.mirrorSettings) || {})).catch(() => {});
      }
    } catch {
      /* ignore */
    }
  }

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.mirrorSettings) return;
      applySettings(changes.mirrorSettings.newValue || {});
    });
  } catch {
    /* ignore */
  }

  /** 主开关 + 单个采集器开关，两个都要开。 */
  function enabledFor(kind) {
    if (!enabled) return false;
    if (!kind) return true;
    return switches[kind] !== false;
  }

  // 自检探针：仪表盘可以用 chrome.tabs.sendMessage 问"你在吗"
  // 自检探针：问"你在吗"，顺带向主世界要一份"这个页面请求过哪些接口"的目击名单。
  let pendingSightings = null;

  /**
   * 手动采集：扫描当前页面上渲染出来的视频链接。
   *
   * 只在用户点「从当前标签页采集可见列表」时执行，不自动跑 ——
   * 页面上的链接可能混着推荐位，自动采集会造假数据。
   */
  function harvestBvids() {
    const out = [];
    const seen = new Set();
    let nodes = [];
    try {
      nodes = document.querySelectorAll('a[href*="/video/BV"]');
    } catch {
      return out;
    }
    for (const a of nodes) {
      let href = '';
      try {
        href = a.getAttribute('href') || '';
      } catch {
        continue;
      }
      const m = href.match(/\/video\/(BV[0-9A-Za-z]{8,12})/);
      if (!m || seen.has(m[1])) continue;
      seen.add(m[1]);
      out.push(m[1]);
      if (out.length >= 400) break;
    }
    return out;
  }

  function handleHarvest(sendResponse) {
    if (!enabledFor('favorites')) {
      sendResponse({ ok: false, reason: 'disabled', count: 0 });
      return;
    }
    const bvids = harvestBvids();
    if (bvids.length === 0) {
      sendResponse({ ok: false, reason: 'empty', count: 0 });
      return;
    }
    send({
      type: 'mirror:payload',
      url: 'mirroself://dom/favlist',
      body: JSON.stringify({ code: 0, data: { bvids } }),
    });
    sendResponse({ ok: true, count: bvids.length, href: location.href });
  }

  try {
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (!msg) return false;
      if (msg.type === 'mirror:harvest') {
        handleHarvest(sendResponse);
        return false;
      }
      if (msg.type !== 'mirror:probe') return false;

      const base = {
        ok: true,
        href: location.href,
        origin: location.origin,
        enabled,
        forwarded,
        rejected,
        recentRejects: recentRejects.slice(),
        lastForwardAt,
        sawInject,
        injectedAt: INJECTED_AT,
      };

      if (!sawInject) {
        sendResponse(base);
        return false;
      }

      const id = String(Date.now()) + Math.random().toString(36).slice(2, 8);
      pendingSightings = { id, done: (list) => sendResponse({ ...base, sightings: list }) };

      try {
        window.postMessage({ __mirror: MARK, type: 'ask-sightings', id, n: nonce() }, location.origin);
      } catch {
        pendingSightings = null;
        sendResponse({ ...base, sightings: [] });
        return false;
      }

      setTimeout(() => {
        if (!pendingSightings || pendingSightings.id !== id) return;
        const p = pendingSightings;
        pendingSightings = null;
        p.done([]);
      }, 250);

      return true; // 异步回复
    });
  } catch {
    /* ignore */
  }

  function send(payload) {
    try {
      const p = chrome.runtime.sendMessage(payload);
      if (p && typeof p.then === 'function') p.catch(() => {});
    } catch {
      /* 后台未就绪（比如插件刚更新），下一次再说 */
    }
  }

  /**
   * 粗筛。返回空字符串表示通过，否则返回拒收原因（便于自检显示）。
   *
   * 注意：**必须接受相对路径**。space.bilibili.com 的页面会用
   * `/x/v3/fav/resource/list?media_id=...` 这种相对地址发请求，
   * 旧版本只认"https 协议 + bilibili.com 域名"开头的绝对地址，于是收藏夹的
   * 每一条响应都在这里被静默拒收（自检里表现为 forwarded:0 / rejected:N）。
   * 后台解析时会用 new URL(url, base) 再解析一次，所以放行是安全的。
   */
  function rejectReason(event) {
    if (!event || typeof event.url !== 'string' || typeof event.body !== 'string') return 'shape';
    if (event.body.length === 0) return 'empty-body';
    if (event.body.length > 400000) return 'too-big';
    const u = event.url;
    if (u.startsWith('mirroself://')) return '';
    if (u.startsWith('/x/') || u.startsWith('/v3/')) return '';
    if (/^https:\/\/[a-z0-9.-]*bilibili\.com\//i.test(u)) return '';
    return 'url';
  }

  function forward(event) {
    if (!enabledFor(event && event.kind)) {
      rejected += 1;
      recentRejects.unshift({ url: String((event && event.url) || '').slice(0, 80), reason: 'off:' + String((event && event.kind) || '') });
      if (recentRejects.length > 5) recentRejects.length = 5;
      return;
    }
    const reason = rejectReason(event);
    if (reason) {
      rejected += 1;
      recentRejects.unshift({ url: String((event && event.url) || '').slice(0, 80), reason });
      if (recentRejects.length > 5) recentRejects.length = 5;
      return;
    }
    const key = event.seq + '|' + event.url;
    if (seen.has(key)) return;
    seen.add(key);
    if (seen.size > 1500) seen.clear();
    forwarded += 1;
    lastForwardAt = Date.now();
    send({ type: 'mirror:payload', url: event.url, body: event.body });
  }

  function hello() {
    try {
      window.postMessage({ __mirror: MARK, type: 'hello', n: nonce() }, location.origin);
    } catch {
      /* 丢弃，不退化到 '*' */
    }
  }

  window.addEventListener('message', (event) => {
    // 与 inject.js 同理：不能要求 event.source === window，
    // 隔离世界拿到的 Window 代理与主世界不是同一个对象。
    if (event.source && event.source !== window) return;
    const data = event.data;
    if (!data || data.__mirror !== MARK) return;

    const expected = nonce();
    if (!expected || data.n !== expected) {
      rejected += 1;
      return;
    }

    if (data.type === 'ready') {
      sawInject = true;
      hello();
      return;
    }
    if (data.type === 'sightings' && pendingSightings && data.id === pendingSightings.id) {
      const p = pendingSightings;
      pendingSightings = null;
      p.done(Array.isArray(data.list) ? data.list : []);
      return;
    }
    if (data.type === 'replay' && Array.isArray(data.events)) {
      sawInject = true;
      if (!enabled) return;
      for (const ev of data.events) forward(ev);
      return;
    }
    if (data.type === 'response') {
      sawInject = true;
      if (!enabled) return;
      forward(data.event);
    }
  });

  loadSetting();
  setTimeout(hello, 0);
})();
