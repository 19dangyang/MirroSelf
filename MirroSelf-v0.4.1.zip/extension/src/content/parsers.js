/**
 * B 站页面响应的解析器（纯函数，可在 Node 中单测）。
 *
 * 这些函数只处理"页面自己已经请求回来的 JSON"，从不构造请求。
 * 所有字段都做防御式读取：接口随时会变，解析失败应当安静地降级，
 * 而不是把脏数据写进画像。
 */

import { ACTION_WEIGHT, LIMITS, MIN_WATCH_RATIO } from '../core/constants.js';
import { resolveCategory } from '../core/partitions.js';

export const SOURCE = Object.freeze({
  FAV: 'fav-resource-list',
  HISTORY: 'history',
  VIEW: 'view',
  VIEW_DETAIL: 'view-detail',
  /** 不是网络响应，而是视频页内联的 __INITIAL_STATE__（见 inject.js） */
  PAGE_STATE: 'page-state',
  /** 视频页里连 __INITIAL_STATE__ 都没找到时的诊断上报 */
  PAGE_DIAG: 'page-diag',
  /** 用户手动触发的"从收藏夹页可见列表采集"，只产生交互，不产生条目 */
  DOM_FAV: 'dom-fav',
  /** 视频的合集 / 系列里的作品列表 */
  SERIES: 'series',
  /** 番剧 / 国创 / 电影 / 纪录片的季度详情 */
  BANGUMI: 'bangumi',
  /** 我自己的追番 / 追剧列表 */
  BANGUMI_FOLLOW: 'bangumi-follow',
});

/**
 * 手动采集：把当前收藏夹页上渲染出来的视频 BV 号收集起来。
 *
 * **只产生 fav 行为，不产生条目** —— 这是刻意的：
 * 收藏夹页的卡片没有分区和标签，如果凭空造出 888 条"无元数据条目"，
 * 覆盖率会被稀释到 2%，可用性门槛反而把画像判死。
 * 只记行为的话：已知视频权重会升级为收藏，未知视频留着等它哪天被视频页补上元数据。
 */
export const DOM_FAV_URL = 'mirroself://dom/favlist';

/**
 * 视频页是 SSR 的：分区与标签直接写在内联的 __INITIAL_STATE__ 里，
 * 页面根本不会去调 /x/web-interface/view。所以主世界脚本会把它整理成
 * "和详情接口一样的形状"发过来，这里用一个私有协议名区分。
 */
export const PAGE_STATE_URL = 'mirroself://page-state/video';
/** 找不到内联状态时的诊断标记，走解析失败通道，便于在自检里看见。 */
export const PAGE_DIAG_URL = 'mirroself://diag/video-page';

const PATHS = [
  { source: SOURCE.VIEW_DETAIL, path: '/x/web-interface/view/detail' },
  { source: SOURCE.VIEW, path: '/x/web-interface/view' },
  { source: SOURCE.FAV, path: '/x/v3/fav/resource/list' },
  // 现行历史接口（{cursor, list[]}）
  { source: SOURCE.HISTORY, path: '/x/web-interface/history/cursor' },
  // 旧接口（data 为数组），保留兼容
  { source: SOURCE.HISTORY, path: '/x/v2/history' },
  // 合集 / 系列里的作品列表
  { source: SOURCE.SERIES, path: '/x/polymer/web-space/seasons_archives_list' },
  // 番剧 / 国创 / 电影 / 纪录片
  { source: SOURCE.BANGUMI, path: '/pgc/view/web/season' },
  // 我自己的追番列表（space 域的"番剧"页）
  { source: SOURCE.BANGUMI_FOLLOW, path: '/x/space/bangumi/follow/list' },
];

/**
 * 匹配必须用 pathname **完全相等**，不能用子串包含。
 *
 * 反例：`POST /x/v2/history/report` 是观看心跳，URL 里含 `/x/v2/history`，
 * 但响应是 `{code:0, data:{}}`。用 indexOf 会把它当成历史接口收下，
 * 解析出 0 条又不报错，最终表现为"收到了 13 条、接受 0 条、没有任何错误"。
 */
export function matchSource(url) {
  if (typeof url !== 'string' || !url) return null;
  if (url === PAGE_STATE_URL) return SOURCE.PAGE_STATE;
  if (url === PAGE_DIAG_URL) return SOURCE.PAGE_DIAG;
  if (url === DOM_FAV_URL) return SOURCE.DOM_FAV;
  let pathname;
  try {
    pathname = new URL(url, 'https://www.bilibili.com').pathname;
  } catch {
    return null;
  }
  for (const m of PATHS) {
    if (pathname === m.path) return m.source;
  }
  return null;
}

/**
 * @param {string} url 页面发出的请求地址
 * @param {string|object} payload 响应体（字符串或已解析对象）
 * @returns {{source: string|null, items: Array, interactions: Array, ignored: number, skippedProgress: number, error?: string}}
 */
export function parsePayload(url, payload) {
  const source = matchSource(url);
  const out = { source, items: [], interactions: [], ignored: 0, skippedProgress: 0 };
  if (!source) return out;

  let json = payload;
  if (typeof payload === 'string') {
    if (!payload) return { ...out, error: 'empty' };
    try {
      json = JSON.parse(payload);
    } catch {
      return { ...out, error: 'json' };
    }
  }
  if (!json || typeof json !== 'object') return { ...out, error: 'shape' };
  if (json.code !== undefined && Number(json.code) !== 0) {
    return { ...out, error: 'code:' + String(json.code) };
  }

  try {
    if (source === SOURCE.FAV) parseFavList(json, out);
    else if (source === SOURCE.HISTORY) parseHistory(json, out);
    else if (source === SOURCE.VIEW) parseView(json, out);
    else if (source === SOURCE.VIEW_DETAIL) parseViewDetail(json, out);
    else if (source === SOURCE.PAGE_STATE) {
      // 内联状态只有在"你真的打开了这个视频页"时才会被读到，
      // 所以它本身就是一次观看证据 —— 必须记一条 watch 行为。
      //
      // 之前这里只 push item 不产生 interaction，而 buildProfile 只遍历
      // "有行为的作品"，于是采了 17 条、画像里 0 条。ACTION_WEIGHT.watch
      // 定了权重却从没被生产过，就是这个 bug 的墓碑。
      const before = out.items.length;
      parseViewDetail(json, out);
      for (let i = before; i < out.items.length; i += 1) {
        out.interactions.push({
          itemId: out.items[i].itemId,
          action: 'watch',
          weight: ACTION_WEIGHT.watch,
          ts: null,
          platform: 'bilibili',
        });
      }
    }
    else if (source === SOURCE.PAGE_DIAG) {
      out.error = 'page-state-missing';
      out.diag = (json && json.data) || null;
    } else if (source === SOURCE.DOM_FAV) {
      const bvids = json && json.data && Array.isArray(json.data.bvids) ? json.data.bvids : [];
      for (const raw of bvids) {
        const itemId = pickBvid({ bvid: raw });
        if (!itemId) continue;
        out.interactions.push({
          itemId,
          action: 'fav',
          weight: ACTION_WEIGHT.fav,
          ts: null,
          platform: 'bilibili',
        });
      }
    } else if (source === SOURCE.SERIES) {
      parseSeries(json, out);
    } else if (source === SOURCE.BANGUMI) {
      parseBangumi(json, out);
    } else if (source === SOURCE.BANGUMI_FOLLOW) {
      parseBangumiFollow(json, out);
    }
  } catch (err) {
    return { ...out, items: [], interactions: [], error: 'parse:' + (err && err.message ? err.message : 'unknown') };
  }

  out.items = out.items.slice(0, LIMITS.itemsPerMessage);
  out.interactions = out.interactions.slice(0, LIMITS.itemsPerMessage);
  return out;
}

function parseFavList(json, out) {  const medias = json?.data?.medias;
  if (!Array.isArray(medias)) return;
  for (const m of medias) {
    if (!m || typeof m !== 'object') {
      out.ignored += 1;
      continue;
    }
    if (m.type !== undefined && Number(m.type) !== 2) {
      out.ignored += 1; // 只收视频（type === 2）
      continue;
    }
    if (Number.isFinite(Number(m.attr)) && (Number(m.attr) & 1) === 1) {
      out.ignored += 1; // 已失效
      continue;
    }
    const itemId = pickBvid(m);
    if (!itemId) {
      out.ignored += 1;
      continue;
    }
    out.items.push({
      itemId,
      platform: 'bilibili',
      title: cleanText(m.title),
      category: null,
      categoryConfidence: 0,
      tags: [],
      upId: toId(m.upper?.mid),
      upName: cleanText(m.upper?.name),
      pubdate: toTs(m.pubtime),
    });
    out.interactions.push({
      itemId,
      action: 'fav',
      weight: ACTION_WEIGHT.fav,
      ts: toTs(m.fav_time),
      platform: 'bilibili',
    });
  }
}

/**
 * 观看进度 = progress / duration，返回 0..1；任一字段缺失或非法时返回 null
 * （null 表示"判断不了"，此时不过滤，避免因为字段改名丢掉整批数据）。
 */
export function watchRatio(h) {
  const progress = Number(h?.progress);
  const duration = Number(h?.duration);
  if (!Number.isFinite(progress) || !Number.isFinite(duration) || duration <= 0) return null;
  if (progress < 0) return null;
  return Math.min(1, progress / duration);
}

function parseHistory(json, out) {  const data = json?.data;
  // 现行 /x/web-interface/history/cursor 返回 { cursor, list[] }；
  // 老接口 /x/v2/history 直接把数组放在 data 上。两种都吃。
  const list = Array.isArray(data) ? data : Array.isArray(data?.list) ? data.list : null;
  if (!list) return;
  for (const h of list) {
    if (!h || typeof h !== 'object') {
      out.ignored += 1;
      continue;
    }
    const hist = h.history || {};
    const business = hist.business || h.business;
    if (business && business !== 'archive') {
      out.ignored += 1; // 直播、番剧、课程等不进画像
      continue;
    }
    const itemId = pickBvid({ bvid: hist.bvid || h.bvid, aid: hist.oid || h.oid });
    if (!itemId) {
      out.ignored += 1;
      continue;
    }

    // 只看了一点点就划走的视频不算兴趣证据：progress / duration < 30% 直接跳过。
    const ratio = watchRatio(h);
    if (ratio !== null && ratio < MIN_WATCH_RATIO) {
      out.skippedProgress += 1;
      continue;
    }
    const { label, confidence } = resolveCategory({ tagName: h.tag_name });
    out.items.push({
      itemId,
      platform: 'bilibili',
      title: cleanText(h.title || h.long_title),
      category: label,
      categoryConfidence: confidence,
      tags: [],
      upId: toId(h.author_mid),
      upName: cleanText(h.author_name),
      pubdate: null,
    });
    out.interactions.push({
      itemId,
      action: 'history',
      weight: ACTION_WEIGHT.history,
      ts: toTs(h.view_at),
      platform: 'bilibili',
    });
  }
}

function parseView(json, out) {
  const d = json?.data;
  if (!d || typeof d !== 'object') return;
  const item = itemFromView(d, []);
  if (!item) {
    out.ignored += 1;
    return;
  }
  out.items.push(item);
}

function parseViewDetail(json, out) {
  const d = json?.data;
  if (!d || typeof d !== 'object') return;
  const view = d.View || d.view || d;
  const rawTags = d.Tags || d.tags || [];
  const tags = [];
  if (Array.isArray(rawTags)) {
    for (const t of rawTags) {
      const name = cleanText(t && (t.tag_name || t.name));
      if (name && !tags.includes(name)) tags.push(name);
      if (tags.length >= LIMITS.tagsPerItem) break;
    }
  }
  const item = itemFromView(view, tags);
  if (!item) {
    out.ignored += 1;
    return;
  }
  out.items.push(item);
}

/**
 * 合集 / 系列里的作品列表。
 *
 * 这些作品**不记为观看**：你只是打开了某个视频的合集面板，不代表你把里面
 * 每个视频都看了。所以 implicitOk: false —— 画像也不会把它们当成
 * "打开过页面"来补隐式观看。
 */
function parseSeries(json, out) {
  const d = json?.data || {};
  const list = Array.isArray(d.archives)
    ? d.archives
    : Array.isArray(d.items)
      ? d.items
      : Array.isArray(d.medias)
        ? d.medias
        : null;
  if (!list) return;
  for (const raw of list) pushArchiveMeta(raw, out);
}

/**
 * 番剧 / 国创 / 电影 / 纪录片：一个季度页 = 一条作品 + 一次观看。
 *
 * 这里的 itemId 是 `season<season_id>` —— 它不是稿件，没有 bvid。
 * 分区取 B 站自己的 season_type_name（番剧/国创/电影/纪录片），
 * 标签取 styles（题材），这两样都是页面本来就展示给用户的公开信息。
 */
function parseBangumi(json, out) {
  const r = json?.data?.result;
  if (!r || typeof r !== 'object') return;
  const seasonId = Number(r.season_id);
  const title = cleanText(r.season_title || r.title);
  if (!Number.isFinite(seasonId) || seasonId <= 0 || !title) {
    out.ignored += 1;
    return;
  }
  const category = cleanText(r.season_type_name) || '番剧';
  const tags = [];
  if (Array.isArray(r.styles)) {
    for (const s of r.styles) {
      const t = cleanText(typeof s === 'string' ? s : s && s.name);
      if (t && !tags.includes(t)) tags.push(t);
      if (tags.length >= LIMITS.tagsPerItem) break;
    }
  }
  const itemId = 'season' + seasonId;
  out.items.push({
    itemId,
    platform: 'bilibili',
    title,
    category,
    categoryConfidence: 1,
    categoryId: null,
    tags,
    upId: null,
    upName: '',
    pubdate: null,
    implicitOk: true,
  });
  out.interactions.push({
    itemId,
    action: 'watch',
    weight: ACTION_WEIGHT.watch,
    ts: null,
    platform: 'bilibili',
  });
}

/**
 * 我自己的追番列表（space 域的"番剧"页）。
 *
 * 追番是主动订阅 —— 比"看过"强，比"收藏"略弱，所以单独给一个 follow 权重。
 * 这里的 itemId 和播放页的 `season<id>` 是同一个键，两边会合并成一条记录：
 * 追了 + 看了 = 两个行为，画像取最大权重。
 */
function parseBangumiFollow(json, out) {
  const list = json?.data?.list;
  if (!Array.isArray(list)) return;

  for (const raw of list) {
    if (!raw || typeof raw !== 'object') {
      out.ignored += 1;
      continue;
    }
    const seasonId = Number(raw.season_id);
    const title = cleanText(raw.title);
    if (!Number.isFinite(seasonId) || seasonId <= 0 || !title) {
      out.ignored += 1;
      continue;
    }

    const tags = [];
    for (const s of Array.isArray(raw.styles) ? raw.styles : []) {
      const t = cleanText(typeof s === 'string' ? s : s && s.name);
      if (t && !tags.includes(t)) tags.push(t);
      if (tags.length >= LIMITS.tagsPerItem) break;
    }

    const itemId = 'season' + seasonId;
    out.items.push({
      itemId,
      platform: 'bilibili',
      title,
      category: cleanText(raw.season_type_name) || '番剧',
      categoryConfidence: 1,
      categoryId: null,
      tags,
      upId: null,
      upName: '',
      pubdate: null,
      implicitOk: true,
    });
    out.interactions.push({
      itemId,
      action: 'follow',
      weight: ACTION_WEIGHT.follow,
      ts: null,
      platform: 'bilibili',
    });
  }
}

/** 归档条目的公共映射：带 tid/tname 的作品元数据。 */
function pushArchiveMeta(raw, out) {  if (!raw || typeof raw !== 'object') {
    out.ignored += 1;
    return;
  }
  const itemId = pickBvid(raw);
  if (!itemId) {
    out.ignored += 1;
    return;
  }
  const { label, confidence } = resolveCategory({ tname: raw.tname, tid: raw.tid });
  out.items.push({
    itemId,
    platform: 'bilibili',
    title: cleanText(raw.title),
    category: label,
    categoryConfidence: confidence,
    categoryId: Number.isFinite(Number(raw.tid)) ? Number(raw.tid) : null,
    tags: [],
    upId: toId(raw.owner?.mid ?? raw.mid ?? raw.author_mid),
    upName: cleanText(raw.owner?.name ?? raw.author ?? raw.author_name),
    pubdate: toTs(raw.pubdate ?? raw.created),
    implicitOk: false,
  });
}

function itemFromView(view, tags) {
  if (!view || typeof view !== 'object') return null;
  const itemId = pickBvid(view);
  if (!itemId) return null;
  const { label, confidence } = resolveCategory({ tname: view.tname, tid: view.tid });
  return {
    itemId,
    platform: 'bilibili',
    title: cleanText(view.title),
    category: label,
    categoryConfidence: confidence,
    categoryId: Number.isFinite(Number(view.tid)) ? Number(view.tid) : null,
    tags,
    upId: toId(view.owner?.mid ?? view.mid ?? view.uid),
    upName: cleanText(view.owner?.name ?? view.author),
    pubdate: toTs(view.pubdate),
  };
}

function pickBvid(obj) {
  if (!obj || typeof obj !== 'object') return '';
  const candidates = [obj.bvid, obj.bv_id, obj.bvId];
  for (const c of candidates) {
    if (typeof c === 'string' && /^BV[0-9A-Za-z]{8,12}$/.test(c.trim())) return c.trim();
  }
  const aid = obj.aid ?? obj.id ?? obj.oid;
  if (Number.isFinite(Number(aid)) && Number(aid) > 0) return 'av' + Number(aid);
  return '';
}

function toId(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return null;
  return n;
}

function toTs(v) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return null;
  return n > 1e12 ? Math.floor(n / 1000) : Math.floor(n);
}

const ENTITIES = { '&amp;': '&', '&lt;': '<', '&gt;': '>', '&quot;': '"', '&#39;': "'", '&nbsp;': ' ' };

/**
 * 标题净化。
 *
 * 顺序是**先解码实体、再剥标签**，并且重复到收敛。
 * 反过来（先剥标签、后解码）会把 `&lt;img onerror=...&gt;` "净化"成可执行标签 ——
 * 净化函数本身变成注入点，这是被检测报告点出来的实际缺陷。
 */
export function cleanText(v) {
  if (typeof v !== 'string') return '';
  let s = v;
  for (let i = 0; i < 3; i += 1) {
    const decoded = s.replace(/&(amp|lt|gt|quot|#39|nbsp);/g, (m) => ENTITIES[m] || m);
    const stripped = decoded.replace(/<[^>]*>/g, '');
    if (stripped === s) break;
    s = stripped;
  }
  return s.replace(/\s+/g, ' ').trim().slice(0, LIMITS.titleMax);
}
