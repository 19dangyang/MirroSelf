import { getSettings, updateSettings } from '../src/storage/settings.js';

const itemsEl = document.getElementById('items');
const interactionsEl = document.getElementById('interactions');
const cardsEl = document.getElementById('cards');
const toggleEl = document.getElementById('toggle');
const toggleText = document.getElementById('toggleText');
const openEl = document.getElementById('open');

function renderToggle(enabled) {
  toggleEl.checked = enabled;
  toggleText.textContent = enabled ? '正在采集' : '已暂停';
}

async function loadCounts() {
  try {
    const res = await chrome.runtime.sendMessage({ type: 'mirror:counts' });
    if (res && res.ok && res.counts) {
      itemsEl.textContent = res.counts.items ?? 0;
      interactionsEl.textContent = res.counts.interactions ?? 0;
      cardsEl.textContent = res.counts.cards ?? 0;
      return;
    }
  } catch {
    /* 后台可能刚重启，忽略 */
  }
  itemsEl.textContent = '0';
  interactionsEl.textContent = '0';
  cardsEl.textContent = '0';
}

toggleEl.addEventListener('change', async () => {
  const enabled = toggleEl.checked;
  await updateSettings({ collectEnabled: enabled });
  renderToggle(enabled);
});

openEl.addEventListener('click', () => {
  chrome.runtime.openOptionsPage();
  window.close();
});

(async () => {
  const settings = await getSettings();
  renderToggle(settings.collectEnabled !== false);
  await loadCounts();
})();
